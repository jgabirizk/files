(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_TechReport2025_Demandbase_728x90_atlas_1", frames: [[0,0,1518,188]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v11_TechReport2025_staticlayered_72890 = function() {
	this.initialize(ss["v1_TechReport2025_Demandbase_728x90_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgsAsg/AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAiIgHgPIgYAAIgHAPIgMAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.2,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.425,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQgFgGgBgIQAAgLAOgHQgHgIAAgIQAAgGAGgFQAFgFAIABQAIAAAFADQAGAFgBAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgIAIgKAAQgJAAgHgEgAgIAEQgKAEAAAHQAAALAMAAQAHAAAEgGIgNgRgAgMgRQAAAFAHAGQAKgFAAgHQAAgHgIAAQgJgBAAAJg");
	this.shape_3.setTransform(-47.05,11.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQBAgBAAAtQAAAMgGAKQgHAKgKAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAOAAQAkAAAAgXQAAgYgkAAIgOAAgAgZgMIAHAAQAiAAAAgYQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.575,-4.5761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.9,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBWIAAirIAfAAIAACrg");
	this.shape_6.setTransform(-12.625,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhCIAYArIAXgrIASBCIgNAAIgIgjIgUAkg");
	this.shape_8.setTransform(-20.5,11.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIARAAQAaAAAAAVQgBAKgHAFQgHAEgLAAIgEAAIAAAZgAgIgBIAEAAQANAAAAgKQAAgLgNAAIgEAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIARgbIANAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.725,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgOAKgJQAKgKAOAAQARAAAKAMIAAABIgKAHIAAAAQgGgJgLAAQgIAAgHAGQgGAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIAAABQgKAMgRAAQgPAAgJgJg");
	this.shape_11.setTransform(-37.35,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgKQALgKANAAQAPAAAKAJQAJAKABAOQgBAOgJAKQgLAKgOAAQgNAAgLgJgAgPgPQgGAHAAAIQAAAKAGAHQAHAGAIAAQAJABAHgIQAFgGAAgKQAAgJgFgHQgHgGgJAAQgIAAgHAHg");
	this.shape_12.setTransform(-29.4,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_72890();
	this.instance.setTransform(-379.5,-47,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-379.5,-47,759,94);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_72890();
	this.instance.setTransform(-379.5,-47,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-379.5,-47,759,94);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("Eg43AAyIAAhjMBxvAAAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-5,728,10);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("Eg43AAyIAAhjMBxvAAAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-364,-5,728,10);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.35,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(46.275,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(38.625,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgFgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQADAHAGADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_3.setTransform(28.75,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19.75,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.775,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(3.675,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-7.875,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-16.85,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-25.625,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-36.625,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.125,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFANAAQAJAAAJADQAHADAGAGQAGAHABALIgTAAQgCgIgFgEQgEgDgIAAQgGAAgGADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgKAEQgJAFgMAAQgNAAgKgGg");
	this.shape_12.setTransform(-53.2,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.1,-10.1,120.30000000000001,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.35,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(46.275,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(38.625,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgFgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQADAHAGADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_3.setTransform(28.75,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19.75,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.775,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(3.675,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-7.875,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-16.85,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-25.625,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-36.625,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.125,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFANAAQAJAAAJADQAHADAGAGQAGAHABALIgTAAQgCgIgFgEQgEgDgIAAQgGAAgGADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgKAEQgJAFgMAAQgNAAgKgGg");
	this.shape_12.setTransform(-53.2,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.1,-10.1,120.30000000000001,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJA/QgDgEAAgFQAAgFADgDQAEgDAEAAQAFAAADADQADADAAAFQAAAFgDAEQgEADgEAAQgEAAgEgDgAgDAdQgDgKACgHQACgGADgGIAJgKIAIgNQAEgHAAgHQAAgLgGgGQgGgFgJgBQgFAAgFAFQgFADgDAHQgEAHgBAHIgQgEQABgIAGgHQAFgGAIgFQAJgEAKAAQASAAAKAIQAKAIAAAOQAAAJgEAHQgFAHgGAFIgMAKQgGAGgEAGQgDAFAAAJg");
	this.shape.setTransform(-133.925,1.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAXAyIgBgVQgHAKgJAGQgHAFgKAAQgMAAgIgHQgGgIAAgNIAAgzQAAgFgDgDQgCgCgFgBIgEAAIAAgCIAbgIIACAAIAABHQABAIAEAFQAFAFAIAAQAGABAHgEQAGgEAHgJIAAg0QAAgFgCgDQgCgCgGgBIgEAAIAAgCIAbgIIADAAIAABQQAAAFACACQADACAFAAIAEABIAAACIgbAIg");
	this.shape_1.setTransform(-143.45,3.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAsQgJgGgGgLQgFgLgBgOQABgOAGgMQAFgMALgHQAJgGANAAQANAAAKAGQAJAGAGALQAFALAAAOQAAAPgFALQgGAMgKAHQgKAGgNAAQgNAAgKgGgAgPgnQgFAFgEAJQgDAJAAALIACAQQACAJAEAIQADAHAGAFQAGAFAGAAQAJAAAFgFQAGgFADgJQADgJAAgMIgCgQQgCgIgDgIQgEgHgFgFQgGgFgHAAQgIAAgGAFg");
	this.shape_2.setTransform(-154.3,3.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnBDIgFgCIAFgPIAGADIAHABQAHAAAFgEQAGgFACgJIAFgJIgihRQgDgFgDgDQgDgCgFAAIAAgDIApAAIAAADQgHAAgCADQgDACACAFIAXA9IAag9QACgFgDgCQgCgDgGAAIAAgDIAbAAIAAADQgEAAgDACQgDADgCAFIglBbQgGAOgIAIQgIAIgLABIgGgBg");
	this.shape_3.setTransform(-164.4,5.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAsQgKgGgFgLQgFgLgBgOQABgPAFgLQAGgMAKgHQAKgGANAAQALAAAIAFQAIAFAFAKQAEAJAAAMIhAAAIAAACIAAACQgBAMAEAJQAFAKAIAFQAHAFALAAQAKAAAHgFQAHgFAEgGIACABQgCAIgGAGQgFAHgIAEQgHADgKAAQgNAAgJgGgAAYgNQgBgIgCgHQgDgHgFgEQgFgFgGAAQgGAAgFAEQgGAEgDAHQgDAHgCAJIAvAAIAAAAg");
	this.shape_4.setTransform(-178.925,3.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgfAxIAAgDQAGgBAEgCQAEgCAAgGIAAg+QAAgFgDgDQgCgCgFAAIgFAAIAAgEIAcgHIADAAIAAAaQAEgNAHgHQAHgGAIAAIAEABIAEABIgBAPIgFgCIgFgBQgHABgHAEQgGAEgDAJIAAAzQAAAGADACQAFACAJABIAAADg");
	this.shape_5.setTransform(-187.375,3.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBBIAAgDQAKAAACgDQACgEgEgJIgKgXIg1AAIgKAXQgEAJACAEQADADAJAAIAAADIgjAAIAAgDQAHAAAFgDQAEgEADgJIAwhuIACAAIAxBuQADAJAEAEQAEADAIAAIAAADgAASASIgYg6IgZA6IAxAAg");
	this.shape_6.setTransform(-198.3,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-207.3,-14.6,414.70000000000005,29.299999999999997);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJA/QgDgEAAgFQAAgFADgDQAEgDAEAAQAFAAADADQADADAAAFQAAAFgDAEQgEADgEAAQgEAAgEgDgAgDAdQgDgKACgHQACgGADgGIAJgKIAIgNQAEgHAAgHQAAgLgGgGQgGgFgJgBQgFAAgFAFQgFADgDAHQgEAHgBAHIgQgEQABgIAGgHQAFgGAIgFQAJgEAKAAQASAAAKAIQAKAIAAAOQAAAJgEAHQgFAHgGAFIgMAKQgGAGgEAGQgDAFAAAJg");
	this.shape.setTransform(-133.925,1.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAXAyIgBgVQgHAKgJAGQgHAFgKAAQgMAAgIgHQgGgIAAgNIAAgzQAAgFgDgDQgCgCgFgBIgEAAIAAgCIAbgIIACAAIAABHQABAIAEAFQAFAFAIAAQAGABAHgEQAGgEAHgJIAAg0QAAgFgCgDQgCgCgGgBIgEAAIAAgCIAbgIIADAAIAABQQAAAFACACQADACAFAAIAEABIAAACIgbAIg");
	this.shape_1.setTransform(-143.45,3.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAsQgJgGgGgLQgFgLgBgOQABgOAGgMQAFgMALgHQAJgGANAAQANAAAKAGQAJAGAGALQAFALAAAOQAAAPgFALQgGAMgKAHQgKAGgNAAQgNAAgKgGgAgPgnQgFAFgEAJQgDAJAAALIACAQQACAJAEAIQADAHAGAFQAGAFAGAAQAJAAAFgFQAGgFADgJQADgJAAgMIgCgQQgCgIgDgIQgEgHgFgFQgGgFgHAAQgIAAgGAFg");
	this.shape_2.setTransform(-154.3,3.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnBDIgFgCIAFgPIAGADIAHABQAHAAAFgEQAGgFACgJIAFgJIgihRQgDgFgDgDQgDgCgFAAIAAgDIApAAIAAADQgHAAgCADQgDACACAFIAXA9IAag9QACgFgDgCQgCgDgGAAIAAgDIAbAAIAAADQgEAAgDACQgDADgCAFIglBbQgGAOgIAIQgIAIgLABIgGgBg");
	this.shape_3.setTransform(-164.4,5.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAsQgKgGgFgLQgFgLgBgOQABgPAFgLQAGgMAKgHQAKgGANAAQALAAAIAFQAIAFAFAKQAEAJAAAMIhAAAIAAACIAAACQgBAMAEAJQAFAKAIAFQAHAFALAAQAKAAAHgFQAHgFAEgGIACABQgCAIgGAGQgFAHgIAEQgHADgKAAQgNAAgJgGgAAYgNQgBgIgCgHQgDgHgFgEQgFgFgGAAQgGAAgFAEQgGAEgDAHQgDAHgCAJIAvAAIAAAAg");
	this.shape_4.setTransform(-178.925,3.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgfAxIAAgDQAGgBAEgCQAEgCAAgGIAAg+QAAgFgDgDQgCgCgFAAIgFAAIAAgEIAcgHIADAAIAAAaQAEgNAHgHQAHgGAIAAIAEABIAEABIgBAPIgFgCIgFgBQgHABgHAEQgGAEgDAJIAAAzQAAAGADACQAFACAJABIAAADg");
	this.shape_5.setTransform(-187.375,3.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBBIAAgDQAKAAACgDQACgEgEgJIgKgXIg1AAIgKAXQgEAJACAEQADADAJAAIAAADIgjAAIAAgDQAHAAAFgDQAEgEADgJIAwhuIACAAIAxBuQADAJAEAEQAEADAIAAIAAADgAASASIgYg6IgZA6IAxAAg");
	this.shape_6.setTransform(-198.3,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-207.3,-14.6,414.70000000000005,29.299999999999997);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape.setTransform(103.925,3.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmA8QgNgKgCgRIAjAAQABAFADAEQAFADAJAAQAJAAAGgGQAEgFAAgJIAAgQQgCAFgFAEQgDAEgHADQgEACgIAAQgMAAgKgFQgJgGgFgKQgGgKgBgPIAAgBQABgQAGgKQAFgLAJgFQAKgHAMAAQALABAHAEQAIAFADAHIAAgOIAiAAIAABaQAAAXgOALQgOALgZABQgagBgMgJgAgMglQgGAGABALIAAABQgBAKAGAHQAEAEAJAAQAJAAAGgEQAEgHAAgKIAAgBQAAgLgEgGQgGgGgJAAQgJAAgEAGg");
	this.shape_1.setTransform(91.85,5.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggBDQgJgGgFgLQgGgLgBgRIAAgCQAAgRAHgKQAFgMAJgGQAKgGAMAAQAKAAAIAFQAHAEAEAIIAAg6IAiAAIAACOIgiAAIAAgQQgEAIgHAFQgIAFgKABQgMAAgKgGgAgNAAQgFAHAAANIAAABQAAANAGAGQAEAHAIAAQAKAAAFgHQAFgGAAgNIAAgBQAAgNgEgHQgGgFgJAAQgJAAgFAFg");
	this.shape_2.setTransform(79.7,1.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_3.setTransform(68.175,3.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAIgFQAJgFALgBIAAAhQgPgBgIAFQgJAFAAALIAAAwg");
	this.shape_4.setTransform(54.9,3.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQBIIAAhjIAhAAIAABjgAgNgpQgFgEAAgJQAAgHAFgFQAGgFAHAAQAIAAAFAFQAFAFABAHQgBAJgFAEQgFAFgIAAQgHAAgGgFg");
	this.shape_5.setTransform(47.825,1.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_6.setTransform(39.325,3.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAPBIIAAg7QABgHgEgFQgDgDgIAAQgGAAgFAEQgFAEAAAKIAAA4IgiAAIAAiOIAiAAIAAA7QAEgIAIgFQAIgFAMgBQAPABAIAIQAJAKABASIAABBg");
	this.shape_7.setTransform(27.775,1.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLA1QgJgJAAgRIAAgrIgMAAIAAgYIAMAAIAAgUIAhAAIAAAUIAUAAIAAAYIgUAAIAAAoQAAAFADADQADACAEAAIAFAAIAFgCIAAAaIgIACIgLABQgQAAgJgIg");
	this.shape_8.setTransform(17.95,2.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgmA8QgNgKgBgRIAiAAQABAFADAEQAEADAKAAQAJAAAFgGQAGgFAAgJIAAgQQgDAFgFAEQgEAEgFADQgFACgIAAQgMAAgKgFQgJgGgGgKQgFgKAAgPIAAgBQAAgQAFgKQAGgLAJgFQAKgHAMAAQALABAHAEQAIAFAEAHIAAgOIAiAAIAABaQAAAXgPALQgNALgaABQgZgBgNgJgAgNglQgEAGAAALIAAABQAAAKAEAHQAGAEAIAAQAJAAAFgEQAGgHgBgKIAAgBQABgLgGgGQgEgGgKAAQgIAAgGAGg");
	this.shape_9.setTransform(4.25,5.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAPAzIAAg5QABgIgEgFQgDgDgIAAQgGgBgFAFQgFAFAAAKIAAA2IgiAAIAAhjIAiAAIAAARQAEgIAIgGQAIgFAMAAQAPAAAIAJQAJAJABAUIAAA/g");
	this.shape_10.setTransform(-7.425,3.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQBIIAAhjIAhAAIAABjgAgNgpQgFgEAAgJQAAgHAFgFQAGgFAHAAQAIAAAFAFQAFAFABAHQgBAJgFAEQgFAFgIAAQgHAAgGgFg");
	this.shape_11.setTransform(-16.175,1.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggBDQgJgGgFgLQgGgLAAgRIAAgCQgBgRAHgKQAFgMAJgGQAKgGAMAAQAKAAAIAFQAHAEAEAIIAAg6IAjAAIAACOIgjAAIAAgQQgEAIgHAFQgIAFgKABQgMAAgKgGgAgNAAQgFAHAAANIAAABQAAANAFAGQAGAHAIAAQAJAAAFgHQAFgGAAgNIAAgBQAAgNgEgHQgGgFgJAAQgJAAgFAFg");
	this.shape_12.setTransform(-25.35,1.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPAzIAAg5QABgIgEgFQgDgDgIAAQgGgBgFAFQgFAFAAAKIAAA2IgiAAIAAhjIAiAAIAAARQAEgIAIgGQAIgFAMAAQAPAAAIAJQAJAJABAUIAAA/g");
	this.shape_13.setTransform(-37.075,3.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_14.setTransform(-48.725,3.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLA1QgJgJAAgRIAAgrIgMAAIAAgYIAMAAIAAgUIAhAAIAAAUIAUAAIAAAYIgUAAIAAAoQAAAFACADQADACAFAAIAFAAIAFgCIAAAaIgIACIgLABQgQAAgJgIg");
	this.shape_15.setTransform(-58.25,2.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAQAyIgRgeIgSAeIgjAAIAhgyIgfgxIAoAAIAOAbIAPgbIAjAAIgfAvIAiA0g");
	this.shape_16.setTransform(-67.375,3.625);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_17.setTransform(-78.175,3.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_18.setTransform(-93.275,3.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAJgFQAHgFAMgBIAAAhQgQgBgIAFQgIAFAAALIAAAwg");
	this.shape_19.setTransform(-102.7,3.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgeAxQgIgDgEgHQgFgGAAgLQAAgRAOgHQANgHAYAAIAKAAIAAgDQAAgHgDgEQgCgEgIAAQgGAAgDADQgDAEgBAEIgfAAQAAgMAHgHQAFgIALgEQALgEAMAAQAOAAAKAEQAKADAFAJQAGAIAAANIAABAIghAAIAAgMQgDAGgIAEQgFAEgNAAQgJAAgHgDgAgJALQgEADgBAGQAAAEADADQADACAGAAQAGAAAGgEQAEgEAAgGIAAgGIgJAAQgJAAgFACg");
	this.shape_20.setTransform(-112.75,3.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AggArQgMgIAAgRIAfAAQABAGADADQADACAGAAQAGAAADgCQADgCAAgEQAAgDgEgCQgEgCgJgCQgNgBgJgEQgIgDgEgGQgEgGAAgLQAAgLAGgHQAGgHAJgEQAKgDAMAAQARAAAMAHQALAHACASIgeAAQgBgFgDgDQgDgCgFAAQgGAAgCACQgDACAAAEQAAADAEACQADACAJABQANABAJAEQAJADAFAGQAEAGAAALQAAARgMAJQgMAIgVAAQgUAAgMgJg");
	this.shape_21.setTransform(-126.625,3.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAJgFQAHgFAMgBIAAAhQgPgBgJAFQgIAFAAALIAAAwg");
	this.shape_22.setTransform(-135.4,3.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_23.setTransform(-145.375,3.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggBDQgJgGgGgLQgFgLAAgRIAAgCQAAgRAFgKQAGgMAJgGQAKgGAMAAQALAAAGAFQAIAEAFAIIAAg6IAiAAIAACOIgiAAIAAgQQgFAIgIAFQgHAFgLABQgLAAgKgGgAgNAAQgFAHAAANIAAABQABANAEAGQAFAHAJAAQAIAAAGgHQAFgGABgNIAAgBQAAgNgGgHQgFgFgJAAQgJAAgFAFg");
	this.shape_24.setTransform(-157.4,1.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgeAxQgIgDgEgHQgFgGAAgLQAAgRAOgHQANgHAYAAIAKAAIAAgDQAAgHgDgEQgCgEgIAAQgGAAgDADQgDAEgBAEIgfAAQAAgMAHgHQAFgIALgEQALgEAMAAQAOAAAKAEQAKADAFAJQAGAIAAANIAABAIghAAIAAgMQgDAGgIAEQgFAEgNAAQgJAAgHgDgAgJALQgEADgBAGQAAAEADADQADACAGAAQAGAAAGgEQAEgEAAgGIAAgGIgJAAQgJAAgFACg");
	this.shape_25.setTransform(-169,3.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_26.setTransform(-180.025,3.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgQBIIAAiOIAhAAIAACOg");
	this.shape_27.setTransform(-188.5,1.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSBEIAAiHIAlAAIAACHg");
	this.shape_28.setTransform(-198.4,1.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAbBEIgHgZIgsAAIgIAZIgkAAIAsiHIAyAAIArCHgAAMAQIgNg0IgQA0IAdAAg");
	this.shape_29.setTransform(-208.85,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-217.9,-15,435.9,30);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape.setTransform(103.925,3.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmA8QgNgKgCgRIAjAAQABAFADAEQAFADAJAAQAJAAAGgGQAEgFAAgJIAAgQQgCAFgFAEQgDAEgHADQgEACgIAAQgMAAgKgFQgJgGgFgKQgGgKgBgPIAAgBQABgQAGgKQAFgLAJgFQAKgHAMAAQALABAHAEQAIAFADAHIAAgOIAiAAIAABaQAAAXgOALQgOALgZABQgagBgMgJgAgMglQgGAGABALIAAABQgBAKAGAHQAEAEAJAAQAJAAAGgEQAEgHAAgKIAAgBQAAgLgEgGQgGgGgJAAQgJAAgEAGg");
	this.shape_1.setTransform(91.85,5.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggBDQgJgGgFgLQgGgLgBgRIAAgCQAAgRAHgKQAFgMAJgGQAKgGAMAAQAKAAAIAFQAHAEAEAIIAAg6IAiAAIAACOIgiAAIAAgQQgEAIgHAFQgIAFgKABQgMAAgKgGgAgNAAQgFAHAAANIAAABQAAANAGAGQAEAHAIAAQAKAAAFgHQAFgGAAgNIAAgBQAAgNgEgHQgGgFgJAAQgJAAgFAFg");
	this.shape_2.setTransform(79.7,1.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_3.setTransform(68.175,3.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAIgFQAJgFALgBIAAAhQgPgBgIAFQgJAFAAALIAAAwg");
	this.shape_4.setTransform(54.9,3.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQBIIAAhjIAhAAIAABjgAgNgpQgFgEAAgJQAAgHAFgFQAGgFAHAAQAIAAAFAFQAFAFABAHQgBAJgFAEQgFAFgIAAQgHAAgGgFg");
	this.shape_5.setTransform(47.825,1.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_6.setTransform(39.325,3.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAPBIIAAg7QABgHgEgFQgDgDgIAAQgGAAgFAEQgFAEAAAKIAAA4IgiAAIAAiOIAiAAIAAA7QAEgIAIgFQAIgFAMgBQAPABAIAIQAJAKABASIAABBg");
	this.shape_7.setTransform(27.775,1.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLA1QgJgJAAgRIAAgrIgMAAIAAgYIAMAAIAAgUIAhAAIAAAUIAUAAIAAAYIgUAAIAAAoQAAAFADADQADACAEAAIAFAAIAFgCIAAAaIgIACIgLABQgQAAgJgIg");
	this.shape_8.setTransform(17.95,2.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgmA8QgNgKgBgRIAiAAQABAFADAEQAEADAKAAQAJAAAFgGQAGgFAAgJIAAgQQgDAFgFAEQgEAEgFADQgFACgIAAQgMAAgKgFQgJgGgGgKQgFgKAAgPIAAgBQAAgQAFgKQAGgLAJgFQAKgHAMAAQALABAHAEQAIAFAEAHIAAgOIAiAAIAABaQAAAXgPALQgNALgaABQgZgBgNgJgAgNglQgEAGAAALIAAABQAAAKAEAHQAGAEAIAAQAJAAAFgEQAGgHgBgKIAAgBQABgLgGgGQgEgGgKAAQgIAAgGAGg");
	this.shape_9.setTransform(4.25,5.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAPAzIAAg5QABgIgEgFQgDgDgIAAQgGgBgFAFQgFAFAAAKIAAA2IgiAAIAAhjIAiAAIAAARQAEgIAIgGQAIgFAMAAQAPAAAIAJQAJAJABAUIAAA/g");
	this.shape_10.setTransform(-7.425,3.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQBIIAAhjIAhAAIAABjgAgNgpQgFgEAAgJQAAgHAFgFQAGgFAHAAQAIAAAFAFQAFAFABAHQgBAJgFAEQgFAFgIAAQgHAAgGgFg");
	this.shape_11.setTransform(-16.175,1.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggBDQgJgGgFgLQgGgLAAgRIAAgCQgBgRAHgKQAFgMAJgGQAKgGAMAAQAKAAAIAFQAHAEAEAIIAAg6IAjAAIAACOIgjAAIAAgQQgEAIgHAFQgIAFgKABQgMAAgKgGgAgNAAQgFAHAAANIAAABQAAANAFAGQAGAHAIAAQAJAAAFgHQAFgGAAgNIAAgBQAAgNgEgHQgGgFgJAAQgJAAgFAFg");
	this.shape_12.setTransform(-25.35,1.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPAzIAAg5QABgIgEgFQgDgDgIAAQgGgBgFAFQgFAFAAAKIAAA2IgiAAIAAhjIAiAAIAAARQAEgIAIgGQAIgFAMAAQAPAAAIAJQAJAJABAUIAAA/g");
	this.shape_13.setTransform(-37.075,3.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_14.setTransform(-48.725,3.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLA1QgJgJAAgRIAAgrIgMAAIAAgYIAMAAIAAgUIAhAAIAAAUIAUAAIAAAYIgUAAIAAAoQAAAFACADQADACAFAAIAFAAIAFgCIAAAaIgIACIgLABQgQAAgJgIg");
	this.shape_15.setTransform(-58.25,2.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAQAyIgRgeIgSAeIgjAAIAhgyIgfgxIAoAAIAOAbIAPgbIAjAAIgfAvIAiA0g");
	this.shape_16.setTransform(-67.375,3.625);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_17.setTransform(-78.175,3.625);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_18.setTransform(-93.275,3.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAJgFQAHgFAMgBIAAAhQgQgBgIAFQgIAFAAALIAAAwg");
	this.shape_19.setTransform(-102.7,3.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgeAxQgIgDgEgHQgFgGAAgLQAAgRAOgHQANgHAYAAIAKAAIAAgDQAAgHgDgEQgCgEgIAAQgGAAgDADQgDAEgBAEIgfAAQAAgMAHgHQAFgIALgEQALgEAMAAQAOAAAKAEQAKADAFAJQAGAIAAANIAABAIghAAIAAgMQgDAGgIAEQgFAEgNAAQgJAAgHgDgAgJALQgEADgBAGQAAAEADADQADACAGAAQAGAAAGgEQAEgEAAgGIAAgGIgJAAQgJAAgFACg");
	this.shape_20.setTransform(-112.75,3.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AggArQgMgIAAgRIAfAAQABAGADADQADACAGAAQAGAAADgCQADgCAAgEQAAgDgEgCQgEgCgJgCQgNgBgJgEQgIgDgEgGQgEgGAAgLQAAgLAGgHQAGgHAJgEQAKgDAMAAQARAAAMAHQALAHACASIgeAAQgBgFgDgDQgDgCgFAAQgGAAgCACQgDACAAAEQAAADAEACQADACAJABQANABAJAEQAJADAFAGQAEAGAAALQAAARgMAJQgMAIgVAAQgUAAgMgJg");
	this.shape_21.setTransform(-126.625,3.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AggAzIAAhjIAhAAIAAAUQAEgLAJgFQAHgFAMgBIAAAhQgPgBgJAFQgIAFAAALIAAAwg");
	this.shape_22.setTransform(-135.4,3.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_23.setTransform(-145.375,3.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggBDQgJgGgGgLQgFgLAAgRIAAgCQAAgRAFgKQAGgMAJgGQAKgGAMAAQALAAAGAFQAIAEAFAIIAAg6IAiAAIAACOIgiAAIAAgQQgFAIgIAFQgHAFgLABQgLAAgKgGgAgNAAQgFAHAAANIAAABQABANAEAGQAFAHAJAAQAIAAAGgHQAFgGABgNIAAgBQAAgNgGgHQgFgFgJAAQgJAAgFAFg");
	this.shape_24.setTransform(-157.4,1.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgeAxQgIgDgEgHQgFgGAAgLQAAgRAOgHQANgHAYAAIAKAAIAAgDQAAgHgDgEQgCgEgIAAQgGAAgDADQgDAEgBAEIgfAAQAAgMAHgHQAFgIALgEQALgEAMAAQAOAAAKAEQAKADAFAJQAGAIAAANIAABAIghAAIAAgMQgDAGgIAEQgFAEgNAAQgJAAgHgDgAgJALQgEADgBAGQAAAEADADQADACAGAAQAGAAAGgEQAEgEAAgGIAAgGIgJAAQgJAAgFACg");
	this.shape_25.setTransform(-169,3.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAuQgMgGgHgLQgHgLAAgRIAAgBQAAgPAHgMQAHgMANgGQAMgGAOAAQAOAAALAFQALAFAHAMQAHALAAASIAAAIIhFAAQABAKAGAFQAFAGAIAAQAIAAAEgEQAFgDAAgFIAgAAQgCARgNAJQgMAJgXAAQgPAAgMgGgAATgKQAAgJgFgFQgEgFgIAAQgHAAgFAFQgFAFgBAJIAjAAIAAAAg");
	this.shape_26.setTransform(-180.025,3.625);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgQBIIAAiOIAhAAIAACOg");
	this.shape_27.setTransform(-188.5,1.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSBEIAAiHIAlAAIAACHg");
	this.shape_28.setTransform(-198.4,1.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAbBEIgHgZIgsAAIgIAZIgkAAIAsiHIAyAAIArCHgAAMAQIgNg0IgQA0IAdAAg");
	this.shape_29.setTransform(-208.85,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-217.9,-15,435.9,30);


// stage content:
(lib.v1TechReport2025Demandbase728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(340.35,61.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(340.35,30.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).to({state:[{t:this.instance_1}]},15).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,y:30.9,alpha:1},15,cjs.Ease.cubicInOut).wait(92));

	// SUBTITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(329.75,75.35);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(329.75,54.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},69).to({state:[{t:this.instance_3}]},15).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({_off:true,y:54.8,alpha:1},15,cjs.Ease.cubicInOut).wait(42));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(647.85,69.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(647.85,43.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},99).to({state:[{t:this.instance_5}]},15).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({_off:true,y:43.35,alpha:1},15,cjs.Ease.cubicInOut).wait(12));

	// LOGO
	this.Logo__728x90_ = new lib.StackedWhiteRGB();
	this.Logo__728x90_.name = "Logo__728x90_";
	this.Logo__728x90_.setTransform(62.05,45,0.85,0.85);

	this.timeline.addTween(cjs.Tween.get(this.Logo__728x90_).wait(126));

	// RED_BAR
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(-415.5,85);

	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(364,85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},14).wait(112));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true,x:364},14,cjs.Ease.cubicInOut).wait(112));

	// BACKGROUND
	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(356.25,40.5,1.39,1.3899,0,0,0,-0.3,-1.2);

	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(358.5,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},125).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:358.5,y:45},125).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-415.5,21.9,1299.7,85.6);
// library properties:
lib.properties = {
	id: 'E54B2FD6976A244F87CBAED45CE68564',
	width: 728,
	height: 90,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_TechReport2025_Demandbase_728x90_atlas_1.jpg", id:"v1_TechReport2025_Demandbase_728x90_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['E54B2FD6976A244F87CBAED45CE68564'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;