(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_TechReport2025_Demandbase_970x250_atlas_1", frames: [[0,0,2022,522]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v11_TechReport2025_staticlayered_970250 = function() {
	this.initialize(ss["v1_TechReport2025_Demandbase_970x250_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_970250();
	this.instance.setTransform(-491.95,-127,0.4866,0.4866);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491.9,-127,983.8,254);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_970250();
	this.instance.setTransform(-491.95,-127,0.4866,0.4866);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491.9,-127,983.8,254);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AhjTiMAAAgnDIDHAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-125,20,250);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AhjTiMAAAgnDIDHAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-125,20,250);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgBCGIAAAuIgOAAIAAhQIAzAwIAAgvIAOAAIAABRgAkOCJIgKArIgOAAIAThQIAdA1IAdg1IAWBQIgRAAIgJgrIgZAtgAl+CrQgMgMABgSQgBgSAMgMQANgMARAAQASAAAMALQALAMAAATQABARgMAMQgNAMgRAAQgRAAgNgLgAlzB5QgHAIAAAMQAAAMAHAIQAHAIAMAAQALAAAIgJQAHgIAAgLQAAgNgHgIQgHgIgMAAQgMAAgHAJgApPCwQgIgGAAgKQAAgOARgJQgJgLAAgHQAAgJAGgFQAHgGAKAAQAKAAAGAFQAHAFAAAJQAAAMgTAJIAOAQIAIgMIANAAIgOAUIAPARIgQAAIgHgIQgJAKgNAAQgMAAgGgGgApKCfQAAAFAEAEQAEAEAGAAQAKAAAFgIIgRgUIgBAAQgLAGAAAJgApDB3QAAAFAIAIQAOgGAAgIQAAgJgLAAQgLAAAAAKgAnZCqQgLgLAAgTQAAgRAMgMQANgMAQAAQAUAAANAPIAAABIgLAJIgBAAQgHgMgOAAQgKAAgIAIQgIAJAAALQABANAGAIQAHAIAMAAQAPAAAGgMIABgBIALAKIAAAAQgMAQgVAAQgSAAgMgMgAEjB/Qg2g1AAhKQAAhLA2g1QA1g1BKAAQANAAAQACIgPAUIgNAAQhAAAgsArQgtAsAAA+QAAA9AtArQAsAsBAAAQA/AAAtgsQAtgrAAg9QAAgvgcgmQgbgmgrgQIgFgZQA5AQAlAwQAlAxAAA9QAABKg1A1Qg1A1hMAAQhKAAg1g1gABhC0IAAghIgdguIARAAIAUAgIAUggIAQAAIgdAuIAAAhgAgzC0IgIgRIgeAAIgHARIgQAAIAnhQIAnBQgAhUCXIAUAAIgJgXgAiqC0IAAhPIATAAQAgAAAAAZQAAAMgJAGQgJAHgOAAIgFAAIAAAdgAicCKIAFABQARAAAAgNQAAgNgRAAIgFAAgAgDhIIAAB5IgmAAIAAjSICIB+IAAh7IAmAAIAADUgAiqAxIAAjPIAnAAIAADPgAkIAxIgTgsIhQAAIgUAsIgnAAIBljSIBkDSgAlcgcIAzAAIgYg8gApQAxIAAjPIAyAAQAmAAAUAOQAUAOAAAaQAAAPgIALQgIALgMAGQAoAOAAAlQAAAcgVAPQgVAQgnAAgAopARIARAAQArAAABgaQAAgQgMgHQgKgGgWAAIgRAAgAophGIAJAAQAVAAAJgGQALgHAAgPQAAgPgLgHQgJgGgXAAIgHAAgAFmgUIBch3IAgCTg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agng1IBPA1IhPA3g");
	this.shape.setTransform(86.375,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_1.setTransform(67.225,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQAKAAAGgFQAGgEAAgKIAAAAQAAgKgGgEQgGgEgKAAIgQAAg");
	this.shape_2.setTransform(55.75,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_3.setTransform(40.975,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_4.setTransform(27.625,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_5.setTransform(15.725,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAuAAQAPAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgIADIAiA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_6.setTransform(3.65,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_7.setTransform(-13.575,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_8.setTransform(-27,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-40.125,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_10.setTransform(-56.575,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_11.setTransform(-67.775,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgHgPgBgTIAAgBQAAgTAIgPQAJgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgIgGgLABQgKAAgIAFQgIAFgEAKQgFAJAAANIAAABQABANAEAJQADAKAIAFQAIAGALAAQALAAAHgEQAGgEAEgGQADgGABgHIgdAAIAAgVIA5AAIAAANQAAARgHANQgHANgOAHQgNAHgTAAQgVAAgOgIg");
	this.shape_12.setTransform(-81.4,1.6727);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.4,-14.2,180.8,28.4);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agng1IBPA1IhPA3g");
	this.shape.setTransform(86.375,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_1.setTransform(67.225,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQAKAAAGgFQAGgEAAgKIAAAAQAAgKgGgEQgGgEgKAAIgQAAg");
	this.shape_2.setTransform(55.75,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_3.setTransform(40.975,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_4.setTransform(27.625,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_5.setTransform(15.725,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAuAAQAPAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgIADIAiA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_6.setTransform(3.65,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_7.setTransform(-13.575,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_8.setTransform(-27,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-40.125,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_10.setTransform(-56.575,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_11.setTransform(-67.775,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgHgPgBgTIAAgBQAAgTAIgPQAJgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgIgGgLABQgKAAgIAFQgIAFgEAKQgFAJAAANIAAABQABANAEAJQADAKAIAFQAIAGALAAQALAAAHgEQAGgEAEgGQADgGABgHIgdAAIAAgVIA5AAIAAANQAAARgHANQgHANgOAHQgNAHgTAAQgVAAgOgIg");
	this.shape_12.setTransform(-81.4,1.6727);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.4,-14.2,180.8,28.4);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPBjQgEgFgBgIQABgIAEgFQAGgGAIAAQAHAAAFAGQAFAFAAAIQgBAIgFAFQgEAFgHAAQgIAAgGgFgAgGAtQgEgOADgLQADgLAFgJIAPgRQAIgJAFgKQAFgLABgNQgBgQgIgKQgKgIgOgBQgJAAgIAHQgIAGgFALQgFAKgBANIgbgHQACgNAJgLQAIgKAOgIQANgGARAAQAcAAAQANQAQAMAAAWQgBAPgGAKQgHALgKAKIgTAPQgKAJgGAJQgFAKABAMg");
	this.shape.setTransform(-155.85,2.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAkBQIAAgjQgNARgNAJQgLAJgQAAQgUAAgLgMQgLgMAAgWIAAhRQAAgHgEgEQgDgEgJAAIgHAAIAAgFIAsgMIAEAAIAABvQAAAOAHAIQAIAIANAAQAKABAKgGQAKgGAMgOIAAhUQAAgHgEgEQgEgEgIAAIgHAAIAAgFIArgMIAEAAIAAB+QAAAIAEAEQAEAEAIAAIAHAAIAAAEIgqANg");
	this.shape_1.setTransform(-170.925,5.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkBGQgQgKgJgRQgIgRAAgWQAAgYAJgTQAJgTAQgKQAQgKAUAAQAVAAAPAKQAQAJAIARQAJASAAAWQAAAYgJASQgJATgQAKQgQALgUgBQgVABgPgKgAgYg+QgJAIgFAOQgFAOAAATQAAAMADANQACAOAGAMQAGAMAJAIQAJAHAMABQAMgBAJgIQAJgIAFgOQAFgOAAgSQAAgMgDgOQgCgNgGgMQgGgMgJgIQgJgHgMgBQgMAAgJAIg");
	this.shape_2.setTransform(-187.975,5.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BqQgFgBgDgBIAIgZQAEAEAFABQAFACAGAAQAMAAAIgHQAIgIAFgOIAGgOIg2iAQgDgJgFgEQgFgDgHAAIAAgFIBAAAIAAAFQgLAAgEAEQgFAEADAIIAnBgIAohgQADgIgEgEQgDgEgLAAIAAgFIAsAAIAAAFQgHAAgFADQgEAEgEAJIg7CQQgJAWgMAOQgMAMgTAAIgJgBg");
	this.shape_3.setTransform(-203.95,8.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggBFQgPgJgIgSQgIgRAAgVQAAgZAJgSQAJgTAQgKQAQgKAUAAQASAAANAIQANAJAGAOQAHAPAAATIhmAAIAAADIAAADQAAAUAGAPQAHAOANAIQAMAIARAAQAQAAALgIQALgGAGgLIADABQgDANgIALQgJAJgMAHQgMAFgQAAQgUAAgQgKgAAlgVQAAgNgFgKQgEgMgHgHQgIgHgKAAQgKAAgJAGQgIAHgFAKQgGAMgCAOIBKAAIAAAAg");
	this.shape_4.setTransform(-226.925,5.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBNIAAgDQAJgCAGgEQAGgDABgKIAAhkQAAgHgFgEQgDgDgJgBIgHAAIAAgEIAsgMIAEAAIAAApQAHgUALgLQALgKANAAIAGABIAHABIgCAZIgHgEIgJgBQgLABgKAGQgKAIgGANIAABRQAAAKAGADQAHAEAQACIAAADg");
	this.shape_5.setTransform(-240.25,4.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBmIAAgDQAPgCAEgFQADgFgHgNIgQglIhUAAIgQAlQgGANAEAFQAEAFAOACIAAADIg3AAIAAgDQAMgCAGgFQAGgFAGgNIBLiwIAEAAIBNCwQAGANAGAFQAHAFAMACIAAADgAAcAcIgmhcIgoBcIBOAAg");
	this.shape_6.setTransform(-257.45,2.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-270.6,-21.9,541.2,43.9);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPBjQgEgFgBgIQABgIAEgFQAGgGAIAAQAHAAAFAGQAFAFAAAIQgBAIgFAFQgEAFgHAAQgIAAgGgFgAgGAtQgEgOADgLQADgLAFgJIAPgRQAIgJAFgKQAFgLABgNQgBgQgIgKQgKgIgOgBQgJAAgIAHQgIAGgFALQgFAKgBANIgbgHQACgNAJgLQAIgKAOgIQANgGARAAQAcAAAQANQAQAMAAAWQgBAPgGAKQgHALgKAKIgTAPQgKAJgGAJQgFAKABAMg");
	this.shape.setTransform(-155.85,2.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAkBQIAAgjQgNARgNAJQgLAJgQAAQgUAAgLgMQgLgMAAgWIAAhRQAAgHgEgEQgDgEgJAAIgHAAIAAgFIAsgMIAEAAIAABvQAAAOAHAIQAIAIANAAQAKABAKgGQAKgGAMgOIAAhUQAAgHgEgEQgEgEgIAAIgHAAIAAgFIArgMIAEAAIAAB+QAAAIAEAEQAEAEAIAAIAHAAIAAAEIgqANg");
	this.shape_1.setTransform(-170.925,5.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkBGQgQgKgJgRQgIgRAAgWQAAgYAJgTQAJgTAQgKQAQgKAUAAQAVAAAPAKQAQAJAIARQAJASAAAWQAAAYgJASQgJATgQAKQgQALgUgBQgVABgPgKgAgYg+QgJAIgFAOQgFAOAAATQAAAMADANQACAOAGAMQAGAMAJAIQAJAHAMABQAMgBAJgIQAJgIAFgOQAFgOAAgSQAAgMgDgOQgCgNgGgMQgGgMgJgIQgJgHgMgBQgMAAgJAIg");
	this.shape_2.setTransform(-187.975,5.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BqQgFgBgDgBIAIgZQAEAEAFABQAFACAGAAQAMAAAIgHQAIgIAFgOIAGgOIg2iAQgDgJgFgEQgFgDgHAAIAAgFIBAAAIAAAFQgLAAgEAEQgFAEADAIIAnBgIAohgQADgIgEgEQgDgEgLAAIAAgFIAsAAIAAAFQgHAAgFADQgEAEgEAJIg7CQQgJAWgMAOQgMAMgTAAIgJgBg");
	this.shape_3.setTransform(-203.95,8.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggBFQgPgJgIgSQgIgRAAgVQAAgZAJgSQAJgTAQgKQAQgKAUAAQASAAANAIQANAJAGAOQAHAPAAATIhmAAIAAADIAAADQAAAUAGAPQAHAOANAIQAMAIARAAQAQAAALgIQALgGAGgLIADABQgDANgIALQgJAJgMAHQgMAFgQAAQgUAAgQgKgAAlgVQAAgNgFgKQgEgMgHgHQgIgHgKAAQgKAAgJAGQgIAHgFAKQgGAMgCAOIBKAAIAAAAg");
	this.shape_4.setTransform(-226.925,5.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBNIAAgDQAJgCAGgEQAGgDABgKIAAhkQAAgHgFgEQgDgDgJgBIgHAAIAAgEIAsgMIAEAAIAAApQAHgUALgLQALgKANAAIAGABIAHABIgCAZIgHgEIgJgBQgLABgKAGQgKAIgGANIAABRQAAAKAGADQAHAEAQACIAAADg");
	this.shape_5.setTransform(-240.25,4.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBmIAAgDQAPgCAEgFQADgFgHgNIgQglIhUAAIgQAlQgGANAEAFQAEAFAOACIAAADIg3AAIAAgDQAMgCAGgFQAGgFAGgNIBLiwIAEAAIBNCwQAGANAGAFQAHAFAMACIAAADgAAcAcIgmhcIgoBcIBOAAg");
	this.shape_6.setTransform(-257.45,2.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-270.6,-21.9,541.2,43.9);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape.setTransform(182.625,5.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_1.setTransform(163.575,8.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_2.setTransform(144.375,2.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_3.setTransform(126.175,5.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_4.setTransform(105.275,5.6485);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaByIAAicIA1AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_5.setTransform(94.1,2.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_6.setTransform(80.675,5.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBxIAAhcQAAgNgGgGQgFgGgMABQgLAAgHAFQgIAIAAAPIAABYIg1AAIAAjhIA1AAIAABeQAHgMANgIQALgJAUAAQAXAAAOAOQAOAPAAAdIAABmg");
	this.shape_7.setTransform(62.425,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBUQgOgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAfAAIAAAkIgfAAIAABAQAAAJAEAEQAEAEAHAAIAJgBIAHgCIAAApIgNADQgIABgJAAQgaABgOgNg");
	this.shape_8.setTransform(46.95,4.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_9.setTransform(25.375,8.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_10.setTransform(6.925,5.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgIgHAAgNQAAgMAIgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_11.setTransform(-6.85,2.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_12.setTransform(-21.325,2.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_13.setTransform(-39.825,5.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_14.setTransform(-58.225,5.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_15.setTransform(-73.25,4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZBOIgbguIgdAuIg3AAIA1hPIgxhMIA+AAIAXApIAYgpIA3AAIgyBJIA3BSg");
	this.shape_16.setTransform(-87.625,5.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_17.setTransform(-104.725,5.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_18.setTransform(-128.575,5.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_19.setTransform(-143.425,5.6485);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgxBOQgMgFgGgLQgIgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgKABgFAFQgFAFgBAIIgyAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQAQAGAJANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgKAGgTAAQgPAAgMgEgAgOASQgIAEAAAJQAAAHAEAEQAFAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgOAAQgPAAgHAEg");
	this.shape_20.setTransform(-159.3,5.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AABBSQghAAgTgNQgSgOgBgaIAxAAQABAJAFAEQAFAFAKAAQAKAAAEgEQAGgDAAgGQgBgGgGgDQgHgDgPgCQgVgDgNgFQgNgGgGgJQgHgLABgQQAAgRAJgMQAJgLAPgGQAPgFASAAQAdgBATAMQASALADAcIgwAAQgCgIgFgDQgEgEgJAAQgIAAgFADQgFAEAAAFQABAFAFADQAHADANACQAWACAOAGQAOAFAIAKQAGAKABAQQgBAcgTANQgSANgfAAIgCAAg");
	this.shape_21.setTransform(-181.25,5.7249);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_22.setTransform(-195.025,5.6485);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_23.setTransform(-210.825,5.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_24.setTransform(-229.825,2.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgxBOQgMgFgHgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgNgBQgKABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAARAGQAPAGAJANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_25.setTransform(-248.1,5.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_26.setTransform(-265.525,5.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-278.875,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeBrIAAjVIA9AAIAADVg");
	this.shape_28.setTransform(-294.45,2.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AArBrIgMgoIhGAAIgLAoIg5AAIBEjVIBPAAIBEDVgAAUAZIgXhRIgYBRIAvAAg");
	this.shape_29.setTransform(-310.95,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-324.1,-22.5,648.3,45.1);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape.setTransform(182.625,5.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_1.setTransform(163.575,8.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_2.setTransform(144.375,2.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_3.setTransform(126.175,5.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_4.setTransform(105.275,5.6485);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaByIAAicIA1AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_5.setTransform(94.1,2.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_6.setTransform(80.675,5.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBxIAAhcQAAgNgGgGQgFgGgMABQgLAAgHAFQgIAIAAAPIAABYIg1AAIAAjhIA1AAIAABeQAHgMANgIQALgJAUAAQAXAAAOAOQAOAPAAAdIAABmg");
	this.shape_7.setTransform(62.425,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBUQgOgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAfAAIAAAkIgfAAIAABAQAAAJAEAEQAEAEAHAAIAJgBIAHgCIAAApIgNADQgIABgJAAQgaABgOgNg");
	this.shape_8.setTransform(46.95,4.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_9.setTransform(25.375,8.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_10.setTransform(6.925,5.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgIgHAAgNQAAgMAIgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_11.setTransform(-6.85,2.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_12.setTransform(-21.325,2.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_13.setTransform(-39.825,5.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_14.setTransform(-58.225,5.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_15.setTransform(-73.25,4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZBOIgbguIgdAuIg3AAIA1hPIgxhMIA+AAIAXApIAYgpIA3AAIgyBJIA3BSg");
	this.shape_16.setTransform(-87.625,5.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_17.setTransform(-104.725,5.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_18.setTransform(-128.575,5.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_19.setTransform(-143.425,5.6485);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgxBOQgMgFgGgLQgIgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgKABgFAFQgFAFgBAIIgyAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQAQAGAJANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgKAGgTAAQgPAAgMgEgAgOASQgIAEAAAJQAAAHAEAEQAFAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgOAAQgPAAgHAEg");
	this.shape_20.setTransform(-159.3,5.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AABBSQghAAgTgNQgSgOgBgaIAxAAQABAJAFAEQAFAFAKAAQAKAAAEgEQAGgDAAgGQgBgGgGgDQgHgDgPgCQgVgDgNgFQgNgGgGgJQgHgLABgQQAAgRAJgMQAJgLAPgGQAPgFASAAQAdgBATAMQASALADAcIgwAAQgCgIgFgDQgEgEgJAAQgIAAgFADQgFAEAAAFQABAFAFADQAHADANACQAWACAOAGQAOAFAIAKQAGAKABAQQgBAcgTANQgSANgfAAIgCAAg");
	this.shape_21.setTransform(-181.25,5.7249);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_22.setTransform(-195.025,5.6485);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_23.setTransform(-210.825,5.725);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_24.setTransform(-229.825,2.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgxBOQgMgFgHgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgNgBQgKABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAARAGQAPAGAJANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_25.setTransform(-248.1,5.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_26.setTransform(-265.525,5.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-278.875,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeBrIAAjVIA9AAIAADVg");
	this.shape_28.setTransform(-294.45,2.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AArBrIgMgoIhGAAIgLAoIg5AAIBEjVIBPAAIBEDVgAAUAZIgXhRIgYBRIAvAAg");
	this.shape_29.setTransform(-310.95,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-324.1,-22.5,648.3,45.1);


// stage content:
(lib.v1TechReport2025Demandbase970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(363.15,162.55);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(363.15,115.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).to({state:[{t:this.instance_1}]},15).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,y:115.4,alpha:1},15,cjs.Ease.cubicInOut).wait(92));

	// SUBTITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(309.15,203.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(309.15,155.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},69).to({state:[{t:this.instance_3}]},15).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({_off:true,y:155.05,alpha:1},15,cjs.Ease.cubicInOut).wait(42));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(128.4,235.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(128.4,202.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},99).to({state:[{t:this.instance_5}]},15).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({_off:true,y:202.25,alpha:1},15,cjs.Ease.cubicInOut).wait(12));

	// LOGO
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(100,56.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(126));

	// RED_BAR
	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(960,456.3);

	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(960,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7}]}).to({state:[{t:this.instance_8}]},14).wait(112));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true,y:125},14,cjs.Ease.cubicInOut).wait(112));

	// BACKGROUND
	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(485.15,124.15,1.1102,1.1102,0,0,0,-0.1,-0.1);

	this.instance_10 = new lib.Tween11("synched",0);
	this.instance_10.setTransform(485.95,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).to({state:[{t:this.instance_10}]},125).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:485.95,y:125},125).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EhNVgVFMCarAAAMAAAAqLMiarAAAg");
	this.shape.setTransform(485,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhNVAVGMAAAgqLMCarAAAMAAAAqLg");
	this.shape_1.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(126));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(424.1,108.3,607.3000000000001,472.99999999999994);
// library properties:
lib.properties = {
	id: '2DB830C2A983B642A244B4632EBC0364',
	width: 970,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_TechReport2025_Demandbase_970x250_atlas_1.jpg", id:"v1_TechReport2025_Demandbase_970x250_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2DB830C2A983B642A244B4632EBC0364'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;