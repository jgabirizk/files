(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1", frames: [[0,0,365,601],[0,603,365,601],[0,1206,365,601]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x600foreground = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._300x600mountain = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._300x600sy = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.8)","rgba(0,0,0,0.239)","rgba(0,0,0,0)"],[0,0.878,1],0,-237.4,0,237.4).s().p("EgXbAlGMAAAhKLMAu3AAAMAAABKLg");
	this.shape.setTransform(150,237.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(0,0,300,474.8), null);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600sy();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600sy();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600mountain();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600mountain();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600foreground();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600foreground();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBkIAAjHMAu3AAAIAADHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-10,300,20);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBkIAAjHMAu3AAAIAADHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-10,300,20);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah/CAQg2g1AAhLQAAhKA2g1QA1g1BKAAQAOAAAPACIgQAUIgNAAQg+AAgsAsQgtArAAA+QAAA9AtArQAsAsA+AAQBAAAAsgsQAtgrAAg9QAAgvgbgmQgbgmgrgQIgGgZQA6ARAlAvQAlAxAAA8QAABLg1A1Qg2A1hLAAQhKAAg1g1gAg8gTIBbh3IAhCTg");
	this.shape.setTransform(41.825,-0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAoIgIgQIgdAAIgIAQIgOAAIAlhPIAmBPgAAKALIgKgWIgJAWIATAAg");
	this.shape_1.setTransform(-7.45,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSgGIAAAtIgOAAIAAhPIAzAvIAAguIAOAAIAABQg");
	this.shape_2.setTransform(1.7,14.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAjQgHgGAAgKQAAgNAQgJQgJgKAAgIQAAgIAHgGQAGgFALgBQAIAAAHAGQAGAFAAAIQAAANgSAJIAOAOIAIgMIAMAAIgOAUIAPARIgPAAIgHgIQgJAKgNAAQgLABgHgHgAgLAEQgEACgDAEQgEAFAAAEQAAAMAPAAQAHAAAGgHIgQgVgAgPgVQAAAGAJAIQAMgHAAgIQAAgJgJAAQgMAAAAAKg");
	this.shape_3.setTransform(-56.475,14.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBnIAAjOIAyAAQAlAAAUAOQAUAOAAAaQAAAPgHALQgIAMgNAFQAoAMAAAmQAAAdgVAPQgUAPgnAAgAgeBJIARAAQArgBAAgbQAAgRgLgGQgLgHgVAAIgRAAgAgegPIAIAAQAWAAAJgGQAKgHAAgPQAAgPgKgHQgKgHgWABIgGAAg");
	this.shape_4.setTransform(-52.35,-5.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA5BpIgTgsIhPAAIgTAsIgoAAIBkjRIBlDRgAAYAcIgYg6IgZA6IAxAAg");
	this.shape_5.setTransform(-32.3,-5.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTBnIAAjOIAnAAIAADOg");
	this.shape_6.setTransform(-15.175,-5.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgwgSIAAB5IgnAAIAAjSICJB+IAAh6IAmAAIAADTg");
	this.shape_7.setTransform(4.55,-5.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYgCIgKApIgOAAIAThPIAdA0IAcg0IAVBPIgPAAIgKgpIgYArg");
	this.shape_8.setTransform(-24.625,14.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAnIAAhOIATAAQAgAAAAAZQAAAMgKAGQgIAGgOAAIgEAAIAAAdgAgKgBIAEAAQAQAAAAgNQAAgNgQABIgEAAg");
	this.shape_9.setTransform(-14.575,14.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAnIAAggIgdguIARAAIASAgIAUggIARAAIgdAuIAAAgg");
	this.shape_10.setTransform(10.45,14.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAeQgMgMAAgSQAAgQANgMQALgMARAAQAUAAALAPIABABIgMAJIAAgBQgGgLgOAAQgKAAgIAIQgHAIAAALQgBAMAIAJQAHAIALAAQANAAAHgMIAAgBIAMAJIgBABQgKAPgVAAQgSAAgLgLg");
	this.shape_11.setTransform(-44.85,14.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAeQgMgMABgSQgBgRAMgLQANgMAQgBQASAAAMAMQAMAMgBARQABASgMALQgNAMgRAAQgQABgNgMgAgSgSQgIAIAAAKQAAANAIAHQAHAJALAAQALgBAHgIQAIgIAAgMQAAgMgHgHQgIgIgLAAQgLAAgHAJg");
	this.shape_12.setTransform(-35.3,14.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agqg5IBVA5IhVA6g");
	this.shape.setTransform(114.15,1.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_1.setTransform(92.675,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVBAIgegxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAhA2gAgWgEIAQAAQALAAAFgFQAGgEgBgKIAAAAQABgKgGgEQgFgEgLAAIgQAAg");
	this.shape_2.setTransform(81.2,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_3.setTransform(66.425,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_4.setTransform(53.075,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_5.setTransform(41.175,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQALAAAFgFQAGgEAAgKIAAAAQAAgKgGgEQgFgEgLAAIgQAAg");
	this.shape_6.setTransform(29.1,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_7.setTransform(11.875,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_8.setTransform(-1.55,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-14.675,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_10.setTransform(-31.125,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_11.setTransform(-42.325,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgHgPgBgTIAAgBQAAgTAJgPQAIgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgHgGgMABQgKAAgIAFQgIAFgEAKQgEAJgBANIAAABQAAANAFAJQADAKAIAFQAIAGALAAQALAAAHgEQAHgEADgGQADgGABgHIgeAAIAAgVIA6AAIAAANQAAARgHANQgHANgNAHQgOAHgTAAQgVAAgOgIg");
	this.shape_12.setTransform(-55.95,1.6727);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.1,-14.2,183.5,28.4);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgsBUQgSgLgIgVQgIgUAAgbIAAgFQAAgeALgVQALgVATgLQATgMAXAAQAfAAASAOQASAOADAbIgxAAQgBgHgEgEQgFgEgKgBQgOABgIAMQgIANgBAYQAGgKAKgGQAJgGARAAQARAAAOAHQAOAHAIANQAJAMAAAUQAAATgJAPQgJAPgRAIQgRAIgYAAQgcAAgTgMgAgPAMQgGAHgBAMQABAMAGAIQAHAHALAAQALAAAGgHQAHgIAAgMQAAgMgGgHQgHgHgLgBQgLABgHAHg");
	this.shape.setTransform(41.775,25.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBeIAAgHIBBhFQANgPAJgLQAIgNAAgLQAAgKgFgGQgFgFgKAAQgJgBgGAIQgGAHgCAQIgwAAQACgjATgSQAUgRAhAAQAXAAAPAHQAQAIAIANQAIANAAASQgBASgJAQQgKAOgQAPIgaAaIA/AAIAAAng");
	this.shape_1.setTransform(24.725,25.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgtBVQgTgLgKgUQgLgVAAgdIAAgHQAAgdALgVQAMgUATgLQATgLAYAAQAZAAATAKQATAKALAVQALAUABAeIAAAGQAAAegLAVQgLAVgTALQgUALgZAAQgaAAgTgLgAgYgqQgIANAAAaIAAAHQAAAZAIANQAIANAQAAQARAAAIgNQAHgNAAgaIAAgGQAAgagHgNQgIgNgRAAQgQAAgIANg");
	this.shape_2.setTransform(7.525,25.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhKBeIAAgHIBBhFQANgPAJgLQAIgNAAgLQAAgKgFgGQgFgFgKAAQgJgBgGAIQgGAHgCAQIgwAAQACgjATgSQAUgRAhAAQAXAAAPAHQAQAIAIANQAIANAAASQgBASgJAQQgKAOgQAPIgaAaIA/AAIAAAng");
	this.shape_3.setTransform(-10.175,25.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgPBIQgNgLAAgYIAAg7IgQAAIAAggIAQAAIAAgdIAuAAIAAAdIAbAAIAAAgIgbAAIAAA3QAAAHAEAEQADADAHAAIAHgBIAGgBIAAAjIgLADIgPABQgWAAgMgMg");
	this.shape_4.setTransform(-28.2,27.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgsBFIAAiHIAuAAIAAAbQAGgPALgHQALgHAPAAIAAArQgVAAgLAHQgLAHAAAPIAABBg");
	this.shape_5.setTransform(-38.525,28.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AglA/QgRgIgJgPQgLgQAAgWIAAgCQAAgVALgQQAJgQARgJQARgIAUAAQAWAAAQAIQARAJAKAPQAJAQAAAWIAAABQAAAWgKAQQgJAQgRAIQgRAIgVAAQgUAAgRgIgAgTgbQgHAJAAASIAAABQAAARAHAKQAGAJANAAQANAAAHgKQAHgJAAgRIAAgBQAAgRgHgJQgGgJgOgBQgMAAgHAJg");
	this.shape_6.setTransform(-52.45,28.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhIBdIAAi1IAvAAIAAAUQAFgKALgGQAKgIAPAAQAQABANAHQANAIAIAQQAHAQAAAXIAAACQAAAWgHAQQgIAQgNAHQgNAIgQAAQgQAAgKgHQgKgFgFgLIAABCgAgUgwQgHAKAAARIAAABQAAASAHAHQAIAKAMAAQAMAAAHgKQAHgIAAgQIAAgCQAAgSgHgJQgHgIgMgBQgMAAgIAJg");
	this.shape_7.setTransform(-68.575,30.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_8.setTransform(-85.025,28.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAXBdIgkhDIgNAAIAABDIg1AAIAAi5IBJAAQAkAAATAPQAUAPAAAdIAAABQgBAUgJAMQgJALgPAFIAtBNgAgagHIARAAQANAAAHgGQAGgFAAgMIAAgBQAAgLgHgFQgGgFgMAAIgSAAg");
	this.shape_9.setTransform(-100.475,25.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBbIAXg8Ig2h5IAyAAIAbBJIAahJIAsAAIhJC1g");
	this.shape_10.setTransform(60.25,-4.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBIQgNgLAAgYIAAg7IgQAAIAAggIAQAAIAAgdIAuAAIAAAdIAbAAIAAAgIgbAAIAAA3QAAAHADAEQAEADAGAAIAIgBIAGgBIAAAjIgLADIgOABQgXAAgMgMg");
	this.shape_11.setTransform(47.35,-8.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWBjIAAiIIAtAAIAACIgAgSg5QgGgFAAgMQAAgKAGgHQAIgGAKAAQALAAAHAGQAHAHAAAKQAAAMgHAFQgHAIgLgBQgKABgIgIg");
	this.shape_12.setTransform(38.7,-10.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgtBAQgKgFgGgMQgFgKgBgSIAAhYIAvAAIAABQQAAAMAEAGQAFAFAKAAQAKAAAGgGQAGgGAAgOIAAhNIAvAAIAACIIgvAAIAAgWQgFALgKAHQgKAGgRABQgNgBgLgFg");
	this.shape_13.setTransform(26.7,-7.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAaBcIAAhCQgEAKgMAHQgKAHgPAAQgQAAgNgHQgMgIgIgQQgIgPAAgWIAAgDQAAgXAIgQQAIgPAMgJQANgHAQAAQAQAAAJAFQALAHAFAKIAAgTIAvAAIAAC0gAgSgwQgGAJgBASIAAACQAAARAHAHQAIAJAKAAQAOAAAGgJQAIgHAAgRIAAgDQAAgQgHgKQgHgIgNgBQgMAAgHAJg");
	this.shape_14.setTransform(9.95,-5.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhBBdIAAi5IB/AAIAAApIhKAAIAAAgIA7AAIAAAlIg7AAIAAAiIBOAAIAAApg");
	this.shape_15.setTransform(-5.525,-9.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_16.setTransform(-26.825,-7.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgPBIQgMgLAAgYIAAg7IgRAAIAAggIARAAIAAgdIAtAAIAAAdIAbAAIAAAgIgbAAIAAA3QAAAHADAEQAEADAGAAIAIgBIAGgBIAAAjIgLADIgOABQgXAAgMgMg");
	this.shape_17.setTransform(-39.85,-8.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgqBDQgKgEgGgJQgHgJAAgOQAAgYATgKQATgKAhAAIAOAAIAAgDQAAgKgEgGQgEgGgKAAQgJABgEAEQgEAFgBAGIgsAAQACgQAIgLQAIgLAPgFQAOgFARAAQATAAAOAFQAOAFAHAMQAIALAAASIAABXIgtAAIAAgQQgFAIgKAGQgJAFgQAAQgMAAgLgEgAgMAQQgHADAAAIQAAAGAEAEQAEADAIAAQAKAAAGgFQAGgFABgJIAAgJIgNAAQgNAAgGAEg");
	this.shape_18.setTransform(-52.475,-7.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgYBEIgyiHIAxAAIAcBXIAchXIAsAAIgyCHg");
	this.shape_19.setTransform(-66.775,-7.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWBjIAAiIIAtAAIAACIgAgSg5QgGgFAAgMQAAgKAGgHQAIgGAKAAQALAAAHAGQAHAHAAAKQAAAMgHAFQgHAIgLgBQgKABgIgIg");
	this.shape_20.setTransform(-78.3,-10.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgsBFIAAiHIAuAAIAAAbQAGgPALgHQALgHAPAAIAAAsQgVgBgLAHQgLAHAAAQIAABAg");
	this.shape_21.setTransform(-87.425,-7.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhIBdIAAi5IBHAAQAlABASAPQATAQAAAeIAAABQgBAdgSAPQgTAPgjAAIgTAAIAAA/gAgTgFIAQAAQAMAAAGgGQAHgGAAgMIAAgBQAAgMgHgFQgHgFgLAAIgQAAg");
	this.shape_22.setTransform(-101.175,-9.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWBiIAAjDIAtAAIAADDg");
	this.shape_23.setTransform(-30.425,-45.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgqBDQgKgEgGgJQgHgJAAgOQAAgYATgKQATgKAhAAIAOAAIAAgDQAAgKgEgGQgEgGgKAAQgJABgEAEQgEAFgBAGIgsAAQACgQAIgLQAIgLAPgFQAOgFARAAQATAAAOAFQAOAFAHAMQAIALAAASIAABXIgtAAIAAgQQgFAIgKAGQgJAFgQAAQgMAAgLgEgAgMAQQgHADAAAIQAAAGAEAEQAEADAIAAQAKAAAGgFQAGgFABgJIAAgJIgNAAQgNAAgGAEg");
	this.shape_24.setTransform(-42.125,-42.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgJBdQgLgHgFgKIAAAUIgvAAIAAjDIAvAAIAABQQAFgKALgGQAKgHAPAAQAQAAANAHQANAJAIAPQAHAPAAAXIAAADQAAAXgHAQQgIAPgNAIQgNAIgQgBQgQABgJgHgAgUABQgHAJAAARIAAACQAAARAHAJQAIAJAMAAQAMAAAHgJQAHgJAAgQIAAgDQAAgRgHgKQgHgHgMAAQgMAAgIAIg");
	this.shape_25.setTransform(-57.325,-45.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AglA/QgRgIgJgPQgLgQAAgWIAAgCQAAgVALgQQAJgQARgJQARgIAUAAQAWAAAQAIQARAJAKAPQAJAQAAAWIAAABQAAAWgKAQQgJAQgRAIQgRAIgVAAQgUAAgRgIgAgTgbQgHAJAAASIAAABQAAARAHAKQAGAJANAAQANAAAHgKQAHgJAAgRIAAgBQAAgRgHgJQgGgJgOgBQgMAAgHAJg");
	this.shape_26.setTransform(-74.05,-42.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWBiIAAjDIAtAAIAADDg");
	this.shape_27.setTransform(-85.975,-45.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgxBUQgWgMgLgVQgLgWAAgcIAAgBQAAgdANgUQAMgWAWgLQAWgNAbAAQAWAAATAHQATAHAMAQQANAOACAYIg1AAQgCgMgIgHQgJgHgOAAQgTABgLAOQgLAOgBAYIAAACQAAAPAFAMQAEAMAJAIQAKAGAPAAQANAAAIgDQAIgEAEgGQADgHABgIIgjAAIAAgkIBXAAIAAAWQAAAYgKATQgKASgUALQgVALgeAAQgeAAgWgMg");
	this.shape_28.setTransform(-100.025,-45.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-67.5,224.5,110.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQBAIgBggQgCAKgGAHQgGAHgHAEQgIAEgKAAQgOAAgJgIQgJgJAAgOQAAgLAFgJQAGgIANgFQAMgFAUgEIAPgDIAAgJQAAgQgHgKQgHgJgLAAQgKAAgFAGQgGAFgBAIQgCAJAEAIIgVAHQgGgNAEgMQAFgLANgHQAMgGASgBQAVAAALAMQANAMAAATIAAA5QAAAGADADQADADAGAAIAFAAIAAAEIglALgAAAgCQgQACgIAIQgIAHAAANQABAJAFAGQAGAGAJAAQAGAAAFgEQAHgEAEgHQAEgHAAgKIAAgWg");
	this.shape.setTransform(16.075,17.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgqA+IAAgDQAIgBAFgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgGgBIgGAAIAAgDIAngLIAEAAIAAAiQAEgQAKgJQAIgJAMAAIAEAAIAGACIgCAXQgCgCgEgBIgIgBQgIAAgJAFQgHAGgEAKIAAA/QAAAIADADQAGADAMABIAAADg");
	this.shape_1.setTransform(4.55,17.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbA4QgMgJgHgOQgGgOAAgQQAAgTAHgPQAHgPAOgJQAMgHARgBQAQAAAKAHQALAGAGAMQAEANAAAPIhQAAIAAABIAAADQAAAPAFAMQAGALAKAGQAJAHANgBQANAAAJgFQAIgGAFgJIADABQgDALgHAJQgGAJgKAEQgLAGgNAAQgRgBgNgHgAAbgQQAAgKgDgKQgDgIgGgGQgFgGgIAAQgHAAgHAFQgGAGgEAIQgEAJgBAMIA2AAIAAAAg");
	this.shape_2.setTransform(-6.75,17.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAjA+IgihSIgiBSIgDAAIgthqQgDgHgDgDQgEgDgGgBIAAgDIA3AAIAAADQgIABgDADQgEADADAHIAdBIIAXg6IgGgOQgDgHgEgDQgDgDgHgBIAAgDIA2AAIAAADQgIABgDADQgDADACAHIAdBIIAdhIQACgGgDgEQgCgDgIgBIAAgDIAiAAIAAADQgGAAgDAEQgEACgDAIIgsBqg");
	this.shape_3.setTransform(-28.475,17.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaA4QgNgJgGgOQgHgOAAgQQAAgTAHgPQAIgPAMgJQAOgHAQgBQAQAAAKAHQALAGAFAMQAGANAAAPIhQAAIgBABIAAADQgBAPAGAMQAFALAKAGQAKAHAOgBQAMAAAIgFQAJgGAFgJIADABQgDALgGAJQgHAJgKAEQgKAGgOAAQgRgBgMgHgAAbgQQAAgKgDgKQgDgIgFgGQgGgGgJAAQgGAAgGAFQgHAGgEAIQgEAJgBAMIA2AAIAAAAg");
	this.shape_4.setTransform(-44.6,17.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAMA+IAAgDQAHgBAEgDQAEgDAAgIIAAhCQAAgLgFgGQgGgGgKAAQgHAAgHAEQgHAEgIAJIAABIQAAAIAEADQAEADAHABIAAADIg3AAIAAgDQAHgBAEgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgGgBIgFAAIAAgDIAmgLIAEAAIAAAbQAJgNAKgHQAJgHAMAAQARAAAJAKQAIAKAAASIAABDQAAAIAFADQAEADAGABIAAADg");
	this.shape_5.setTransform(-57.875,17.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAQBAIgBggQgCAKgGAHQgGAHgHAEQgIAEgKAAQgOAAgJgIQgJgJAAgOQAAgLAFgJQAGgIANgFQAMgFAUgEIAPgDIAAgJQAAgQgHgKQgHgJgLAAQgKAAgFAGQgGAFgBAIQgCAJAEAIIgVAHQgGgNAEgMQAFgLANgHQAMgGASgBQAVAAALAMQANAMAAATIAAA5QAAAGADADQADADAGAAIAFAAIAAAEIglALgAAAgCQgQACgIAIQgIAHAAANQABAJAFAGQAGAGAJAAQAGAAAFgEQAHgEAEgHQAEgHAAgKIAAgWg");
	this.shape_6.setTransform(-76.575,17.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAMA+IAAgDQAHgBAEgDQAEgDAAgIIAAhCQAAgLgFgGQgGgGgKAAQgHAAgHAEQgHAEgIAJIAABIQAAAIAEADQAEADAHABIAAADIg3AAIAAgDQAHgBAEgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgGgBIgFAAIAAgDIAmgLIAEAAIAAAbQAJgNAKgHQAJgHAMAAQARAAAJAKQAIAKAAASIAABDQAAAIAFADQAEADAGABIAAADg");
	this.shape_7.setTransform(-95.925,17.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZBYIAAgEQAHgBAEgCQAEgDAAgIIAAhOQAAgGgDgDQgDgDgHgBIgEAAIAAgEIAlgKIADAAIAABpQABAIAEADQAEACAGABIAAAEgAgKg7QgGgFAAgGQAAgHAGgFQAEgEAHgBQAIABAEAEQAEAFABAHQgBAGgEAFQgEAFgIAAQgHAAgEgFg");
	this.shape_8.setTransform(-106.7,14.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAXBXIgBgdQgFAOgKAHQgJAIgMAAQgPAAgMgIQgLgJgFgNQgGgOAAgQQAAgWAIgOQAHgPANgIQAMgIAPAAQAJAAAIAEQAIAEAFAHIAAgiQAAgGgDgDQgEgDgFAAIgGAAIAAgEIAngLIAEAAIAACSQAAAGACADQAEADAGAAIAFAAIAAAEIglALgAgXgZQgGAHgFALQgDALAAAOQAAANADAMQADAMAHAIQAIAIALABQAJgBAHgFQAIgGADgJIAAguQAAgJgDgJQgDgIgHgFQgGgGgKAAQgIAAgIAHg");
	this.shape_9.setTransform(81.75,-16.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpA+IAAgDQAHgBAEgDQAFgDAAgIIAAhOQAAgGgDgDQgDgDgHgBIgEAAIAAgDIAmgLIADAAIAAAiQAGgQAJgJQAJgJAKAAIAGAAIAEACIgBAXQgDgCgDgBIgHgBQgKAAgHAFQgIAGgFAKIAAA/QAAAIAFADQAFADAMABIAAADg");
	this.shape_10.setTransform(69.65,-14.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAQBAIgBgfQgCAJgGAHQgGAHgHAEQgIAEgKAAQgOAAgJgJQgJgHAAgOQAAgNAFgHQAGgJANgFQAMgFAUgEIAPgDIAAgIQAAgSgHgIQgHgKgLAAQgKAAgFAFQgGAGgBAJQgCAHAEAJIgVAHQgGgNAEgLQAFgMANgGQAMgIASAAQAVAAALAMQANALAAAVIAAA3QAAAHADADQADADAGABIAFAAIAAADIglALgAAAgCQgQACgIAIQgIAHAAAMQABAKAFAGQAGAGAJABQAGAAAFgFQAHgEAEgHQAEgHAAgKIAAgWg");
	this.shape_11.setTransform(58.775,-14.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAjA+IgihSIgiBSIgDAAIgthrQgDgFgDgEQgEgEgGAAIAAgDIA3AAIAAADQgIAAgDAEQgEAEADAFIAdBIIAXg4IgGgQQgDgGgEgDQgDgEgHAAIAAgDIA2AAIAAADQgIAAgDAEQgDAEACAFIAdBIIAdhIQACgFgDgEQgCgEgIAAIAAgDIAiAAIAAADQgGAAgDADQgEAEgDAGIgsBrg");
	this.shape_12.setTransform(42.075,-14.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqA+IAAgDQAIgBAFgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgGgBIgGAAIAAgDIAngLIAEAAIAAAiQAEgQAKgJQAIgJAMAAIAEAAIAGACIgCAXQgCgCgEgBIgIgBQgIAAgJAFQgHAGgEAKIAAA/QAAAIADADQAGADAMABIAAADg");
	this.shape_13.setTransform(27.5,-14.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgeA4QgMgIgIgNQgHgOAAgTQAAgSAIgPQAHgPANgIQAOgJAQAAQARAAANAIQANAIAHANQAHAOAAATQAAASgIAQQgHAOgNAIQgOAJgQAAQgRgBgNgHgAgSgyQgHAHgDAKQgEAMABAOQAAALABALQADALAEAKQAFAJAGAGQAHAGAJAAQAIAAAHgGQAHgGAEgLQADgLAAgPQAAgKgCgMQgCgLgFgKQgEgKgHgFQgHgGgIAAQgJAAgHAGg");
	this.shape_14.setTransform(15.65,-14.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgtBXIAAgDQAIgBAFgEQAEgDAAgHIAAhfIgUAAIAAgGIAUAAIAAgJQAAgOAHgLQAGgKALgEQAJgGAMAAQALAAAJADQAIAEAFAHIgTANQgCgJgEgFQgFgGgFAAQgHAAgEAEQgEAFgCAIQgCAHAAAKIAAANIAgAAIAAAGIggAAIAABfQAAAHAEADQAGAEAMABIAAADg");
	this.shape_15.setTransform(5.65,-17);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgsBQQgOgIAAgNQAAgHADgGQAEgGAFgDQAGgEAGgBQgHgEgDgEQgDgFAAgGQAAgHAFgGQAEgGAJgEQgKgFgFgJQgGgJAAgMQAAgMAGgJQAGgKALgFQALgFAQgBQALAAAJAEIAmAAIAAAHIgZAAQAHAFAEAIQAEAJABAJQgBAMgGAKQgGAJgLAFQgLAGgOAAIgOgBQgHgCgGgDIgEAGQgCADAAADQAAAEAEAEQAFAEAIABIAlACQASABAKAIQAKAHAAAPQAAAMgIAIQgIAJgPAFQgPAEgSABQgYgBgPgHgAgjApQgDAEAAAGQAAAKAFAGQAGAHAJAEQAKADALAAQALAAAJgDQAKgCAFgGQAFgFABgHQAAgHgGgFQgGgFgOgCIgigDIgHgBIgGgBIgGAHgAgShHQgHAIAAAOQAAASAHAKQAIALAKAAQALAAAGgIQAGgJAAgOQAAgLgDgJQgDgJgGgFQgGgFgHAAQgKABgGAIg");
	this.shape_16.setTransform(-11.875,-11.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAMA+IAAgDQAHgBAEgDQAEgDAAgIIAAhCQAAgLgFgGQgGgGgKAAQgHAAgHAEQgHAEgIAJIAABIQAAAIAEADQAEADAHABIAAADIg3AAIAAgDQAHgBAEgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgGgBIgFAAIAAgDIAmgLIAEAAIAAAbQAJgNAKgHQAJgHAMAAQARAAAJAKQAIAKAAASIAABDQAAAIAFADQAEADAGABIAAADg");
	this.shape_17.setTransform(-25.275,-14.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZBYIAAgDQAHgBAEgEQAEgDAAgHIAAhPQAAgFgDgEQgDgCgHgBIgEAAIAAgDIAlgMIADAAIAABqQABAHAEADQAEAEAGABIAAADgAgKg7QgGgFAAgGQAAgIAGgEQAEgFAHAAQAIAAAEAFQAEAEABAIQgBAGgEAFQgEAFgIAAQgHAAgEgFg");
	this.shape_18.setTransform(-36.05,-17.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgpA+IAAgDQAHgBAFgDQAEgDAAgIIAAhOQAAgGgDgDQgDgDgHgBIgFAAIAAgDIAngLIADAAIAAAiQAGgQAJgJQAIgJALAAIAGAAIAEACIgBAXQgDgCgDgBIgIgBQgIAAgIAFQgJAGgEAKIAAA/QAAAIAFADQAFADAMABIAAADg");
	this.shape_19.setTransform(-44.3,-14.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaA3QgNgHgGgOQgHgOAAgSQAAgSAHgPQAIgPANgIQAMgJARAAQAQAAAKAHQALAHAFAMQAFAMABAPIhQAAIgBABIAAACQgBAPAGAMQAFAMALAGQAJAGANAAQANAAAJgGQAIgFAFgIIADABQgDALgGAIQgHAIgKAGQgLAFgNAAQgRAAgMgJgAAbgRQAAgKgDgJQgDgJgGgFQgFgGgIAAQgIAAgGAFQgGAGgEAIQgEAJgBALIA2AAIAAAAg");
	this.shape_20.setTransform(-55.6,-14.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAjA+IgihSIgiBSIgDAAIgthrQgDgFgDgEQgEgEgGAAIAAgDIA3AAIAAADQgIAAgDAEQgEAEADAFIAdBIIAXg4IgGgQQgDgGgEgDQgDgEgHAAIAAgDIA2AAIAAADQgIAAgDAEQgDAEACAFIAdBIIAdhIQACgFgDgEQgCgEgIAAIAAgDIAiAAIAAADQgGAAgDADQgEAEgDAGIgsBrg");
	this.shape_21.setTransform(-71.775,-14.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgeA4QgNgIgHgNQgHgOAAgTQAAgSAHgPQAIgPANgIQAOgJAQAAQARAAANAIQANAIAHANQAHAOAAATQAAASgIAQQgHAOgNAIQgOAJgQAAQgRgBgNgHgAgSgyQgGAHgEAKQgDAMgBAOQAAALACALQACALAFAKQAEAJAHAGQAHAGAIAAQAKAAAGgGQAHgGADgLQAEgLAAgPQAAgKgDgMQgCgLgEgKQgEgKgHgFQgGgGgJAAQgJAAgHAGg");
	this.shape_22.setTransform(-88.45,-14.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhCBQIAAgDQALgBAFgDQAFgEAAgJIAAh2QAAgKgFgDQgFgEgLgBIAAgDIBFAAQAUAAAOAFQAOAFAIAKQAIAKAAAPQAAAPgIAKQgIAJgOAFQgOAFgUAAIgWAAIAAAyQAAAJAGAEQAFADAJABIAAADgAgTADIATAAQATAAAKgKQAKgKAAgRQAAgRgKgLQgKgKgTAAIgTAAg");
	this.shape_23.setTransform(-102.675,-16.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-36.3,224.5,67.8);


// stage content:
(lib.v11PE2026DemandbaseLandingPage300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// SUBTITLE_PAIR
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(150.2,304.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51).to({_off:false},0).to({y:264.7,alpha:1},17,cjs.Ease.cubicInOut).wait(53));

	// TITLE_PAIR
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(150.2,227.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({_off:false},0).to({y:178.4,alpha:1},17,cjs.Ease.cubicInOut).wait(80));

	// CTA
	this.instance_2 = new lib.Tween7("synched",0);
	this.instance_2.setTransform(103.7,360.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(79).to({_off:false},0).to({x:105.25,y:339.35,alpha:1},15,cjs.Ease.cubicInOut).wait(27));

	// LOGO
	this.instance_3 = new lib.Tween9("synched",0);
	this.instance_3.setTransform(100,58.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(121));

	// RED_BAR
	this.instance_4 = new lib.Tween10("synched",0);
	this.instance_4.setTransform(-173.15,590);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween11("synched",0);
	this.instance_5.setTransform(150,590);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},4).to({state:[{t:this.instance_5}]},14).wait(103));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).to({_off:true,x:150},14,cjs.Ease.cubicInOut).wait(103));

	// SHADOW
	this.instance_6 = new lib.Rectangle();
	this.instance_6.setTransform(150,237.25,1,1,0,0,0,150,237.4);
	this.instance_6.alpha = 0.6406;
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(121));

	// FOREGROUND
	this.instance_7 = new lib.Tween12("synched",0);
	this.instance_7.setTransform(155,300);

	this.instance_8 = new lib.Tween13("synched",0);
	this.instance_8.setTransform(180.5,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7}]}).to({state:[{t:this.instance_8}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true,x:180.5},120).wait(1));

	// MOUNT
	this.instance_9 = new lib.Tween14("synched",0);
	this.instance_9.setTransform(180.5,322);

	this.instance_10 = new lib.Tween15("synched",0);
	this.instance_10.setTransform(180.5,301);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).to({state:[{t:this.instance_10}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true,y:301},120).wait(1));

	// SKY
	this.instance_11 = new lib.Tween16("synched",0);
	this.instance_11.setTransform(169,300);

	this.instance_12 = new lib.Tween17("synched",0);
	this.instance_12.setTransform(180.5,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11}]}).to({state:[{t:this.instance_12}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true,x:180.5},120).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(121));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-173.1,298,536.1,326);
// library properties:
lib.properties = {
	id: 'EDEBA2EAA84A0C4884EBB71C7C72A593',
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1.png", id:"v1_1_PE2026_Demandbase_LandingPage_300x600_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EDEBA2EAA84A0C4884EBB71C7C72A593'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;