(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1", frames: [[0,0,365,601],[0,603,365,601],[0,1206,365,601]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x600foreground = function() {
	this.initialize(ss["v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._300x600mountain = function() {
	this.initialize(ss["v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._300x600sy = function() {
	this.initialize(ss["v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.8)","rgba(0,0,0,0.239)","rgba(0,0,0,0)"],[0,0.878,1],0,-237.4,0,237.4).s().p("EgXbAlGMAAAhKLMAu3AAAMAAABKLg");
	this.shape.setTransform(150,237.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(0,0,300,474.8), null);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600sy();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600sy();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600mountain();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600mountain();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600foreground();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._300x600foreground();
	this.instance.setTransform(-182.5,-302,1,1.005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.5,-302,365,604);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBkIAAjHMAu3AAAIAADHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-10,300,20);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBkIAAjHMAu3AAAIAADHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-10,300,20);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah/CAQg2g1AAhLQAAhKA2g1QA1g1BKAAQAOAAAPACIgQAUIgNAAQg+AAgsAsQgtArAAA+QAAA9AtArQAsAsA+AAQBAAAAsgsQAtgrAAg9QAAgvgbgmQgbgmgrgQIgGgZQA6ARAlAvQAlAxAAA8QAABLg1A1Qg2A1hLAAQhKAAg1g1gAg8gTIBbh3IAhCTg");
	this.shape.setTransform(41.825,-0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAoIgIgQIgdAAIgIAQIgOAAIAlhPIAmBPgAAKALIgKgWIgJAWIATAAg");
	this.shape_1.setTransform(-7.45,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSgGIAAAtIgOAAIAAhPIAzAvIAAguIAOAAIAABQg");
	this.shape_2.setTransform(1.7,14.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAjQgHgGAAgKQAAgNAQgJQgJgKAAgIQAAgIAHgGQAGgFALgBQAIAAAHAGQAGAFAAAIQAAANgSAJIAOAOIAIgMIAMAAIgOAUIAPARIgPAAIgHgIQgJAKgNAAQgLABgHgHgAgLAEQgEACgDAEQgEAFAAAEQAAAMAPAAQAHAAAGgHIgQgVgAgPgVQAAAGAJAIQAMgHAAgIQAAgJgJAAQgMAAAAAKg");
	this.shape_3.setTransform(-56.475,14.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBnIAAjOIAyAAQAlAAAUAOQAUAOAAAaQAAAPgHALQgIAMgNAFQAoAMAAAmQAAAdgVAPQgUAPgnAAgAgeBJIARAAQArgBAAgbQAAgRgLgGQgLgHgVAAIgRAAgAgegPIAIAAQAWAAAJgGQAKgHAAgPQAAgPgKgHQgKgHgWABIgGAAg");
	this.shape_4.setTransform(-52.35,-5.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA5BpIgTgsIhPAAIgTAsIgoAAIBkjRIBlDRgAAYAcIgYg6IgZA6IAxAAg");
	this.shape_5.setTransform(-32.3,-5.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTBnIAAjOIAnAAIAADOg");
	this.shape_6.setTransform(-15.175,-5.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgwgSIAAB5IgnAAIAAjSICJB+IAAh6IAmAAIAADTg");
	this.shape_7.setTransform(4.55,-5.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYgCIgKApIgOAAIAThPIAdA0IAcg0IAVBPIgPAAIgKgpIgYArg");
	this.shape_8.setTransform(-24.625,14.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAnIAAhOIATAAQAgAAAAAZQAAAMgKAGQgIAGgOAAIgEAAIAAAdgAgKgBIAEAAQAQAAAAgNQAAgNgQABIgEAAg");
	this.shape_9.setTransform(-14.575,14.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAnIAAggIgdguIARAAIASAgIAUggIARAAIgdAuIAAAgg");
	this.shape_10.setTransform(10.45,14.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAeQgMgMAAgSQAAgQANgMQALgMARAAQAUAAALAPIABABIgMAJIAAgBQgGgLgOAAQgKAAgIAIQgHAIAAALQgBAMAIAJQAHAIALAAQANAAAHgMIAAgBIAMAJIgBABQgKAPgVAAQgSAAgLgLg");
	this.shape_11.setTransform(-44.85,14.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAeQgMgMABgSQgBgRAMgLQANgMAQgBQASAAAMAMQAMAMgBARQABASgMALQgNAMgRAAQgQABgNgMgAgSgSQgIAIAAAKQAAANAIAHQAHAJALAAQALgBAHgIQAIgIAAgMQAAgMgHgHQgIgIgLAAQgLAAgHAJg");
	this.shape_12.setTransform(-35.3,14.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agqg5IBVA5IhVA6g");
	this.shape.setTransform(114.15,1.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaA9QgMgFgFgKQgHgJAAgNIAcAAQAAAGACAFQADAEAFADQAGADAIAAQAKAAAFgFQAGgEAAgIQAAgFgCgDQgCgEgGgBIgNgEQgQgCgLgEQgKgFgFgHQgEgIgBgMQABgLAFgJQAGgIALgFQAKgFAOAAQAVAAAMAJQANAKACATIgbAAQgBgIgGgFQgFgEgJAAQgKAAgEAEQgFAEAAAHQAAAEACADQABAEAGACQAFACAJABQAQACAKAEQAKAEAGAHQAFAIAAANQAAAMgGAJQgGAJgLAGQgLAFgPAAQgQAAgMgFg");
	this.shape_1.setTransform(92.25,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_2.setTransform(80.675,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAUBAIgsg5IAAA5IgdAAIAAh/IAdAAIAAA3IAsg3IAfAAIgzA8IA2BDg");
	this.shape_3.setTransform(68.525,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfBAIgJgcIguAAIgJAcIgbAAIAqh/IAlAAIAqB/gAAPAPIgQg3IgRA3IAhAAg");
	this.shape_4.setTransform(54.45,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_5.setTransform(42.925,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_6.setTransform(26.475,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOBAIAAh/IAdAAIAAB/g");
	this.shape_7.setTransform(17.375,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_8.setTransform(3.375,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAfBAIgJgcIguAAIgJAcIgbAAIAqh/IAlAAIAqB/gAAPAPIgQg3IgRA3IAhAAg");
	this.shape_9.setTransform(-8.1,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAaBAIAAg1IgzAAIAAA1IgdAAIAAh/IAdAAIAAA0IAzAAIAAg0IAdAAIAAB/g");
	this.shape_10.setTransform(-22.3,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAXBAIgXhYIgXBYIgcAAIggh/IAeAAIAUBXIAWhXIAYAAIAWBYIAWhYIAbAAIggB/g");
	this.shape_11.setTransform(-38.8,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_12.setTransform(-58.225,1.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_13.setTransform(-69.775,1.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgaA9QgMgFgFgKQgHgJAAgNIAbAAQABAGACAFQADAEAFADQAGADAIAAQAJAAAHgFQAFgEAAgIQAAgFgCgDQgCgEgGgBIgNgEQgQgCgLgEQgKgFgFgHQgFgIAAgMQAAgLAGgJQAGgIALgFQAKgFAOAAQAVAAAMAJQAMAKACATIgbAAQgBgIgFgFQgGgEgIAAQgKAAgFAEQgEAEAAAHQAAAEACADQACAEAFACQAFACAJABQAQACAKAEQAKAEAGAHQAFAIAAANQAAAMgGAJQgGAJgLAGQgLAFgPAAQgRAAgLgFg");
	this.shape_14.setTransform(-82.15,1.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-14.2,208.4,28.4);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgIAAgOQAAgWASgIQARgKAfAAIAMAAIAAgCQAAgKgDgFQgEgGgKAAQgHAAgEAFQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHAKQAHALAAAQIAABRIgqAAIAAgOQgEAHgJAEQgIAFgPABQgMAAgJgEgAgLAPQgGACAAAIQAAAGADADQAEADAIAAQAIAAAGgFQAGgEAAgJIAAgHIgLAAQgMAAgGADg");
	this.shape.setTransform(-22.375,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgpBAIAAh9IAqAAIAAAZQAGgOAKgGQAKgHAPAAIAAApQgUgBgKAHQgKAGgBAOIAAA8g");
	this.shape_1.setTransform(-33.525,24.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgOAAgVIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAHQAHAGALAAQAKABAFgFQAGgEABgGIAoAAQgDAVgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLAAQgJAAgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_2.setTransform(-46.125,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AATA/IgThFIgSBFIgqAAIgmh9IAtAAIASBKIAVhKIAiAAIASBKIAUhKIAqAAIgpB9g");
	this.shape_3.setTransform(-68.2,25.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgOAAgVIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAHQAHAGALAAQAKABAFgFQAGgEABgGIAoAAQgDAVgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLAAQgJAAgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_4.setTransform(-85.175,25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBBIAAhIQAAgLgFgFQgEgFgJgBQgJABgGAFQgFAGgBAMIAABGIgrAAIAAh9IArAAIAAAUQAFgKALgHQAJgGAQgBQASAAALAMQALAMABAYIAABRg");
	this.shape_5.setTransform(-99.825,24.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIAAhIQAAgKgFgGQgEgEgJAAQgJAAgGAFQgFAGgBAMIAABFIgrAAIAAh8IArAAIAAAUQAFgKALgGQAJgHAQAAQASAAALALQALAMABAYIAABQg");
	this.shape_6.setTransform(36.475,-5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVBbIAAh8IAqAAIAAB8gAgQg0QgGgGgBgJQABgKAGgHQAGgFAKgBQAKABAHAFQAHAHgBAKQABAJgHAGQgHAHgKgBQgKABgGgHg");
	this.shape_7.setTransform(25.4,-7.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgOAAgVIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAOAAAXIAAALIhXAAQABAMAGAHQAHAGALABQAKAAAFgFQAGgEABgHIAoAAQgDAWgQAMQgQALgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLgBQgJABgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_8.setTransform(9.925,-4.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpA3QgPgLAAgVIAnAAQABAHAEADQAEAFAIAAQAIAAAEgEQADgDAAgEQAAgEgFgDQgFgDgMgBQgRgDgKgEQgLgEgFgIQgFgHAAgNQAAgOAIgKQAHgJAMgEQAMgFAPAAQAXAAAOAJQAPAJACAXIgmAAQgCgHgDgCQgEgEgHAAQgHAAgDADQgEACAAAFQAAAEAFACQAFADALACQARACALAEQAMAEAFAHQAGAJAAAMQAAAXgPALQgPAKgbAAQgaAAgPgLg");
	this.shape_9.setTransform(-3.475,-4.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgVBbIAAh8IAqAAIAAB8gAgQg0QgGgGgBgJQABgKAGgHQAHgFAJgBQAKABAHAFQAHAHgBAKQABAJgHAGQgHAHgKgBQgJABgHgHg");
	this.shape_10.setTransform(-13.2,-7.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgpBAIAAh9IAqAAIAAAZQAGgOAKgGQAKgHAPAAIAAApQgUgBgKAHQgKAGgBAOIAAA8g");
	this.shape_11.setTransform(-21.575,-4.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgpA3QgPgLAAgVIAnAAQABAHAEADQAEAFAIAAQAIAAAEgEQADgDAAgEQAAgEgFgDQgFgDgMgBQgRgDgKgEQgLgEgFgIQgFgHAAgNQAAgOAIgKQAHgJAMgEQAMgFAPAAQAXAAAOAJQAPAJACAXIgmAAQgCgHgDgCQgEgEgHAAQgHAAgDADQgEACAAAFQAAAEAFACQAFADALACQARACALAEQAMAEAFAHQAGAJAAAMQAAAXgPALQgPAKgbAAQgaAAgPgLg");
	this.shape_12.setTransform(-37.925,-4.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgOAAgVIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAOAAAXIAAALIhXAAQABAMAGAHQAHAGALABQAKAAAFgFQAGgEABgHIAoAAQgDAWgQAMQgQALgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLgBQgJABgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_13.setTransform(-51.375,-4.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAOBaIghg3IAAA3IgqAAIAAizIAqAAIAABnIAhgwIAtAAIgpA3IAtBFg");
	this.shape_14.setTransform(-64.25,-7.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgVASgKQARgJAfAAIAMAAIAAgCQAAgKgDgFQgEgGgKABQgHgBgEAFQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHALQAHAKAAARIAABQIgqAAIAAgOQgEAHgJAEQgIAGgPAAQgMAAgJgEgAgLAOQgGADAAAIQAAAFADADQAEAEAIAAQAIAAAGgFQAGgFAAgIIAAgHIgLAAQgMAAgGACg");
	this.shape_15.setTransform(-78.975,-4.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOBDQgMgLAAgWIAAg3IgPAAIAAgdIAPAAIAAgaIArAAIAAAaIAYAAIAAAdIgYAAIAAAzQAAAHACADQAEADAGAAIAHgBIAGgBIAAAhIgLACQgGABgHAAQgVAAgLgKg");
	this.shape_16.setTransform(-90.5,-5.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgpA3QgPgLAAgVIAnAAQABAHAEADQAEAFAIAAQAIAAAEgEQADgDAAgEQAAgEgFgDQgFgDgMgBQgRgDgKgEQgLgEgFgIQgFgHAAgNQAAgOAIgKQAHgJAMgEQAMgFAPAAQAXAAAOAJQAPAJACAXIgmAAQgCgHgDgCQgEgEgHAAQgHAAgDADQgEACAAAFQAAAEAFACQAFADALACQARACALAEQAMAEAFAHQAGAJAAAMQAAAXgPALQgPAKgbAAQgaAAgPgLg");
	this.shape_17.setTransform(-101.175,-4.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAUBAIAAhIQAAgKgFgFQgEgGgJAAQgJAAgGAHQgFAFgBAMIAABFIgrAAIAAh8IArAAIAAAUQAFgKALgGQAJgHAQgBQASAAALAMQALAMABAYIAABQg");
	this.shape_18.setTransform(55.075,-34.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgiA6QgPgHgKgPQgJgOAAgUIAAgCQAAgTAJgPQAKgPAPgIQAPgIATAAQAUAAAPAIQAPAIAJAOQAJAPABAUIAAAAQgBAVgJAPQgJAOgPAIQgQAIgTAAQgTAAgPgIgAgRgZQgHAJAAAQIAAAAQAAARAGAJQAHAIALAAQAMAAAHgIQAGgJAAgQIAAgBQAAgQgGgIQgHgIgMgBQgLAAgGAIg");
	this.shape_19.setTransform(40.075,-34.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgUBbIAAh9IAqAAIAAB9gAgQg0QgHgGABgKQgBgKAHgGQAGgGAKAAQAKAAAHAGQAGAGABAKQgBAKgGAGQgHAHgKAAQgKAAgGgHg");
	this.shape_20.setTransform(29.05,-37.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgOBDQgLgLAAgWIAAg3IgQAAIAAgdIAQAAIAAgaIAqAAIAAAaIAYAAIAAAdIgYAAIAAAzQAAAHACADQAEADAGAAIAHgBIAGgBIAAAhIgLACQgGABgHAAQgVAAgLgKg");
	this.shape_21.setTransform(20.65,-35.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgWASgIQARgKAfAAIAMAAIAAgDQAAgJgDgFQgEgFgKgBQgHABgEAEQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHALQAHAKAAARIAABQIgqAAIAAgPQgEAHgJAGQgIAFgPAAQgMAAgJgEgAgLAPQgGADAAAHQAAAFADAEQAEADAIAAQAIAAAGgFQAGgFAAgIIAAgIIgLAAQgMAAgGAEg");
	this.shape_22.setTransform(8.975,-34.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgPAAgUIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLAAQgJAAgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_23.setTransform(-4.925,-34.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgpBAIAAh9IAqAAIAAAZQAGgOAKgGQAKgHAPAAIAAApQgUgBgKAHQgKAGgBAOIAAA8g");
	this.shape_24.setTransform(-16.825,-34.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AggA6QgOgGgIgPQgKgOABgVIAAgCQgBgUAKgPQAIgOAQgIQAPgIARAAQAQAAAOAFQANAFAIALQAKAMABATIgoAAQgCgJgFgFQgEgFgKAAQgKABgGAHQgGAJAAAPIAAABQAAARAFAIQAHAJALAAQAJAAAGgGQAGgFABgLIAmAAQAAARgHAMQgIALgOAHQgNAGgVAAQgRAAgQgIg");
	this.shape_25.setTransform(-29.2,-34.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgPAAgUIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLAAQgJAAgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_26.setTransform(-48.175,-34.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgpA7QgKgFgFgKQgFgLgBgPIAAhRIArAAIAABKQAAAKAFAFQAEAGAJAAQAJAAAGgGQAGgGAAgMIAAhHIArAAIAAB8IgrAAIAAgTQgFAKgKAGQgJAGgPAAQgNAAgJgFg");
	this.shape_27.setTransform(-62.875,-34.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgUBaIAAizIApAAIAACzg");
	this.shape_28.setTransform(-73.825,-37.425);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgWASgIQARgKAfAAIAMAAIAAgDQAAgJgDgFQgEgFgKgBQgHABgEAEQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHALQAHAKAAARIAABQIgqAAIAAgPQgEAHgJAGQgIAFgPAAQgMAAgJgEgAgLAPQgGADAAAHQAAAFADAEQAEADAIAAQAIAAAGgFQAGgFAAgIIAAgIIgLAAQgMAAgGAEg");
	this.shape_29.setTransform(-84.575,-34.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgbBWIg4irIA0AAIAiB4IAjh4IAuAAIg4Crg");
	this.shape_30.setTransform(-98.6,-36.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.3,-57.7,193.1,96.6);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjA0QgOgRAAghQAAgTAFgOQAFgOAIgIQAIgIAKgEQAKgEAIAAQAKAAAJADQAJADAGAGQAHAFADAJIgXAHQgCgMgHgIQgGgHgJAAQgHAAgHAHQgGAHgEAOQgEAOAAAUQAHgJAKgEQAJgEAJAAQAMAAAJAFQAJAFAGAJQAFAKAAANQAAANgGALQgFAKgLAGQgLAGgPAAQgYAAgNgSgAgOgEQgHADgFAFQABAMACAKQACALAEAJQADAIAGAFQAGAFAGAAQAIAAAFgFQAFgEADgIQADgIAAgKQAAgMgEgIQgEgJgHgDQgHgEgHAAQgGAAgHADg");
	this.shape.setTransform(7.825,14.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AguBEIAAgDIAjgnIANgRQAHgIAFgJQAEgKAAgKQAAgMgHgHQgHgGgLgBQgGAAgGADQgHADgFAFQgFAFgCAIIgCgBQABgJAFgIQAGgJAJgFQAJgFAMAAQASAAAKAKQALAKAAARQAAAPgJAMQgIAMgPANQgOANgUAPIAqAAQAJABAFgCQAFgCADgEQADgFACgIIADAAIgGAmg");
	this.shape_1.setTransform(-3.625,13.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdA8QgLgJgHgQQgGgQAAgTQAAgSAGgQQAHgQALgJQAMgKARAAQASAAAMAKQAMAJAGAQQAGAQAAASQAAATgGAQQgGAQgMAJQgMAKgSAAQgRAAgMgKgAgQg4QgHAHgDANQgEANAAAQQAAALACANQACANAEAKQAEALAGAGQAHAHAIAAQAIAAAGgHQAGgHAEgNQAEgNAAgQQAAgLgCgMQgCgNgEgLQgEgLgHgGQgGgHgIAAQgIAAgGAHg");
	this.shape_2.setTransform(-15.075,14.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBEIAAgDIAjgnIANgRQAHgIAFgJQAEgKAAgKQAAgMgHgHQgHgGgLgBQgGAAgGADQgHADgFAFQgFAFgCAIIgCgBQABgJAFgIQAGgJAJgFQAJgFAMAAQASAAAKAKQALAKAAARQAAAPgJAMQgIAMgPANQgOANgUAPIAqAAQAJABAFgCQAFgCADgEQADgFACgIIADAAIgGAmg");
	this.shape_3.setTransform(-26.875,13.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_4.setTransform(-40.125,14.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQAAgFgDgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAHgHQAIgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_5.setTransform(-47.65,15.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAvQgLgHgFgLQgGgMAAgOQAAgQAGgNQAGgMALgHQAMgHANAAQAPAAAKAGQAKAHAHALQAFAMAAAPQAAAPgFANQgHANgLAGQgLAHgOAAQgOAAgLgGgAgPgpQgFAFgDAJQgDAJAAANQAAAIACAKQACAJADAIQAEAIAGAEQAFAFAHABQAHgBAGgFQAGgFADgJQACgJAAgNQAAgIgBgKQgCgJgEgIQgEgIgFgEQgGgGgGAAQgIAAgGAGg");
	this.shape_6.setTransform(-57.55,15.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0BIIAAgDQAHgCADgCQAFgDAAgGIAAhoQAAgFgDgCQgDgDgFgBIgFAAIAAgDIAhgJIADAAIAAAYQAEgLAIgGQAIgHAJAAQANAAAKAIQAIAGAFAMQAGALAAAOQgBARgGAMQgGANgLAGQgKAHgMAAQgIAAgHgEQgGgDgEgGIAAAiQAAAGAEADQAEACAJACIAAADgAgIg1QgGAFgDAHIAAAnQAAAHACAHQADAHAFAFQAGAEAIAAQAHgBAFgFQAGgGAEgJQADgIAAgMQAAgLgDgLQgCgKgHgGQgGgHgKAAQgGABgGAEg");
	this.shape_7.setTransform(-69.35,17.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_8.setTransform(-80.475,15.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcBDIgDgGIgDgFIghgwIgOAAIAAAqQAAAIAEADQAEACAJABIAAADIg5AAIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIA7AAQAPAAAMAEQAMAEAGAJQAHAIAAANQAAAOgJAJQgJAIgQADIAhAuQAEAFAGADQAFADAGABIAAADgAgZACIAQAAQAPAAAIgHQAJgJAAgOQAAgPgJgIQgIgJgPAAIgQAAg");
	this.shape_9.setTransform(-92.475,14.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBHIgGgCIAHgTIAHAEIAHABQAIAAAFgEQAFgGAEgJIADgIIglhUQgCgHgDgCQgEgCgEgBIAAgDIAuAAIAAADQgHAAgDAEQgCACACAGIAYA7IAag7QACgGgCgCQgCgEgIAAIAAgDIAeAAIAAADQgFABgDACQgDACgDAHIgoBdQgGAQgJAKQgIAIgNABIgGgBg");
	this.shape_10.setTransform(89.75,-6.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_11.setTransform(80.775,-9.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_12.setTransform(74.275,-11.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAXA1IgBgWQgIALgIAFQgIAHgKgBQgOAAgHgIQgIgIAAgPIAAgzQAAgFgCgDQgDgCgFgCIgFAAIAAgCIAhgKIADAAIAABKQAAAJAEAFQAFAFAIAAQAFAAAHgEQAGgDAHgIIAAg2QAAgFgDgDQgCgCgGgCIgEAAIAAgCIAggKIADAAIAABUQAAAFADACQADADAFABIAEAAIAAACIgfAJg");
	this.shape_13.setTransform(65.475,-8.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAABIIAAgEQAKAAAFgDQAEgDAAgFIAAgtQgDAGgEAFQgEAFgHAEQgFADgHAAQgNAAgJgGQgJgIgFgLQgEgKgBgOQAAgSAHgNQAGgNALgGQAKgHANABQAIgBAHAEQAHAEAGAFIANgMIADAAIAAB/QAAAFAEADQAEADAGAAIAAAEgAgSg6QgGAGgDAKQgDAJAAALQAAAMADAJQACAKAGAGQAGAHAKAAQAHAAAGgFQAGgFADgHIAAgoQAAgIgCgGQgDgHgGgDQgFgEgIgBQgHABgGAFg");
	this.shape_14.setTransform(54.05,-7.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag3BDIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIBnAAIAGAlIgDAAQgEgPgIgIQgJgIgOAAIgfAAIAAA4IAVAAQAIAAAEgCQADgCACgEQACgEAAgHIACAAIAAArIgCAAQAAgGgCgEQgCgFgDgCQgEgCgIAAIgVAAIAAAxQAAAGACACQADADAEAAIAYAAQAPAAAIgIQAJgIADgPIADAAIgFAlg");
	this.shape_15.setTransform(41.35,-10.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_16.setTransform(25.175,-8.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_17.setTransform(16.525,-9.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANA1IAAgaQgCAIgFAGQgFAGgGADQgHADgIAAQgMAAgIgHQgHgHAAgLQAAgKAFgHQAFgHAKgEQALgEAPgDIAOgDIAAgHQgBgOgFgIQgGgIgJAAQgJAAgEAFQgFAFgBAHQgBAGADAHIgRAGQgGgLAEgJQAEgKAKgFQALgGAPAAQARAAAKAJQAKAKAAARIAAAuQAAAGACACQAEADAEAAIAFAAIAAADIggAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAEAFQAFAFAIAAQAFAAAEgEQAFgDAEgGQADgGABgIIAAgSg");
	this.shape_18.setTransform(8.1,-8.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAAA0IgnhZQgDgGgCgCQgEgDgEAAIAAgDIAvAAIAAADQgIAAgCADQgDADACAFIAZA9IAZg9QACgFgDgDQgCgDgHAAIAAgDIAeAAIAAADQgFAAgDADQgDACgDAGIgmBZg");
	this.shape_19.setTransform(-3.05,-8.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_20.setTransform(-11.375,-11.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQgBgFgCgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAIgHQAHgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_21.setTransform(-18.2,-9.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag3BDIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIA6AAQAQAAAMAEQAMAEAGAJQAHAIAAANQAAAMgHAIQgGAIgMAEQgMAEgQAAIgSAAIAAAqQAAAIAEADQAEACAJABIAAADgAgPACIAPAAQAQAAAIgHQAJgJAAgOQAAgPgJgIQgIgJgQAAIgPAAg");
	this.shape_22.setTransform(-28.6,-10.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgVBHIAAgDQAHgBACgCQAEgDAAgGIAAhnQAAgFgCgDQgDgCgFAAIgFgBIAAgDIAggJIACAAIAAB+QABAGADADQAEACAFABIAAADg");
	this.shape_23.setTransform(-42.45,-11);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAOA1IgBgaQgCAIgFAGQgFAGgGADQgHADgIAAQgMAAgHgHQgIgHAAgLQAAgKAFgHQAFgHAKgEQAKgEAQgDIAOgDIAAgHQAAgOgGgIQgGgIgJAAQgIAAgFAFQgFAFgBAHQgBAGADAHIgSAGQgEgLADgJQAEgKALgFQAKgGAPAAQARAAAKAJQAKAKAAARIAAAuQAAAGACACQADADAFAAIAFAAIAAADIggAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAFAFQAEAFAIAAQAFAAAEgEQAGgDADgGQAEgGAAgIIAAgSg");
	this.shape_24.setTransform(-50.15,-8.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgJBFQgHgDgFgGIgOAMIgDAAIAAh5QAAgFgCgCQgDgCgFgBIgFgBIAAgCIAhgJIACAAIAAA+QADgHAFgGQAEgFAGgDQAFgDAIAAQAMAAAJAHQAJAHAGALQAEAKAAAOQAAASgHANQgFAMgMAHQgKAGgNAAQgHAAgIgDgAgEgSQgFACgDAEQgEAEgCAFIAAAlQABAJACAGQADAIAFAEQAFAEAJAAQAGAAAGgFQAGgGADgJQAEgKAAgLQAAgJgBgIIgGgOQgDgGgGgEQgEgEgIgBQgEABgEADg");
	this.shape_25.setTransform(-61.95,-10.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAuQgLgFgFgMQgGgMAAgPQAAgPAGgNQAGgMALgHQAMgHANAAQAPAAAKAHQAKAGAHAMQAFALAAAPQAAAQgFAMQgHAMgLAHQgLAHgOAAQgOAAgLgHgAgPgqQgFAGgDAJQgDAJAAAMQAAAJACAJQACAKADAIQAEAIAGAFQAFAEAHAAQAHAAAGgEQAGgGADgJQACgJAAgMQAAgJgBgJQgCgKgEgIQgEgHgFgGQgGgEgGAAQgIAAgGAEg");
	this.shape_26.setTransform(-73.3,-8.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgUBHIAAgDQAFgBAEgCQADgDAAgGIAAhnQAAgFgCgDQgDgCgFAAIgFgBIAAgDIAfgJIADAAIAAB+QAAAGAEADQADACAGABIAAADg");
	this.shape_27.setTransform(-81.85,-11);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgkA9QgQgJgIgPQgIgPgBgTQABgVAIgQQAJgQAPgJQAPgKAVAAQANAAAKAEQALADAHAHQAIAHADAJIgVAGQgCgOgKgIQgJgIgMAAQgNAAgJAIQgKAHgGAOQgFAOAAATQAAARAHAPQAHAPAKAJQAMAJANAAQAHAAAHgCQAHgCAEgFIAAgjQAAgIgDgFQgFgEgKgBIAAgCIA6AAIAAACQgJABgEAEQgFAFAAAIIAAAZQgEAHgJAFQgIAGgKADQgKAEgMAAQgTgBgPgIg");
	this.shape_28.setTransform(-92.05,-10.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#C20000").s().p("AvzD4IAAnuIfnAAIAAHug");
	this.shape_29.setTransform(-0.575,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.8,-27.6,203.7,55.2);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjA0QgOgRAAghQAAgTAFgOQAFgOAIgIQAIgIAKgEQAKgEAIAAQAKAAAJADQAJADAGAGQAHAFADAJIgXAHQgCgMgHgIQgGgHgJAAQgHAAgHAHQgGAHgEAOQgEAOAAAUQAHgJAKgEQAJgEAJAAQAMAAAJAFQAJAFAGAJQAFAKAAANQAAANgGALQgFAKgLAGQgLAGgPAAQgYAAgNgSgAgOgEQgHADgFAFQABAMACAKQACALAEAJQADAIAGAFQAGAFAGAAQAIAAAFgFQAFgEADgIQADgIAAgKQAAgMgEgIQgEgJgHgDQgHgEgHAAQgGAAgHADg");
	this.shape.setTransform(7.825,14.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AguBEIAAgDIAjgnIANgRQAHgIAFgJQAEgKAAgKQAAgMgHgHQgHgGgLgBQgGAAgGADQgHADgFAFQgFAFgCAIIgCgBQABgJAFgIQAGgJAJgFQAJgFAMAAQASAAAKAKQALAKAAARQAAAPgJAMQgIAMgPANQgOANgUAPIAqAAQAJABAFgCQAFgCADgEQADgFACgIIADAAIgGAmg");
	this.shape_1.setTransform(-3.625,13.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdA8QgLgJgHgQQgGgQAAgTQAAgSAGgQQAHgQALgJQAMgKARAAQASAAAMAKQAMAJAGAQQAGAQAAASQAAATgGAQQgGAQgMAJQgMAKgSAAQgRAAgMgKgAgQg4QgHAHgDANQgEANAAAQQAAALACANQACANAEAKQAEALAGAGQAHAHAIAAQAIAAAGgHQAGgHAEgNQAEgNAAgQQAAgLgCgMQgCgNgEgLQgEgLgHgGQgGgHgIAAQgIAAgGAHg");
	this.shape_2.setTransform(-15.075,14.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBEIAAgDIAjgnIANgRQAHgIAFgJQAEgKAAgKQAAgMgHgHQgHgGgLgBQgGAAgGADQgHADgFAFQgFAFgCAIIgCgBQABgJAFgIQAGgJAJgFQAJgFAMAAQASAAAKAKQALAKAAARQAAAPgJAMQgIAMgPANQgOANgUAPIAqAAQAJABAFgCQAFgCADgEQADgFACgIIADAAIgGAmg");
	this.shape_3.setTransform(-26.875,13.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_4.setTransform(-40.125,14.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQAAgFgDgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAHgHQAIgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_5.setTransform(-47.65,15.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAvQgLgHgFgLQgGgMAAgOQAAgQAGgNQAGgMALgHQAMgHANAAQAPAAAKAGQAKAHAHALQAFAMAAAPQAAAPgFANQgHANgLAGQgLAHgOAAQgOAAgLgGgAgPgpQgFAFgDAJQgDAJAAANQAAAIACAKQACAJADAIQAEAIAGAEQAFAFAHABQAHgBAGgFQAGgFADgJQACgJAAgNQAAgIgBgKQgCgJgEgIQgEgIgFgEQgGgGgGAAQgIAAgGAGg");
	this.shape_6.setTransform(-57.55,15.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0BIIAAgDQAHgCADgCQAFgDAAgGIAAhoQAAgFgDgCQgDgDgFgBIgFAAIAAgDIAhgJIADAAIAAAYQAEgLAIgGQAIgHAJAAQANAAAKAIQAIAGAFAMQAGALAAAOQgBARgGAMQgGANgLAGQgKAHgMAAQgIAAgHgEQgGgDgEgGIAAAiQAAAGAEADQAEACAJACIAAADgAgIg1QgGAFgDAHIAAAnQAAAHACAHQADAHAFAFQAGAEAIAAQAHgBAFgFQAGgGAEgJQADgIAAgMQAAgLgDgLQgCgKgHgGQgGgHgKAAQgGABgGAEg");
	this.shape_7.setTransform(-69.35,17.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_8.setTransform(-80.475,15.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcBDIgDgGIgDgFIghgwIgOAAIAAAqQAAAIAEADQAEACAJABIAAADIg5AAIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIA7AAQAPAAAMAEQAMAEAGAJQAHAIAAANQAAAOgJAJQgJAIgQADIAhAuQAEAFAGADQAFADAGABIAAADgAgZACIAQAAQAPAAAIgHQAJgJAAgOQAAgPgJgIQgIgJgPAAIgQAAg");
	this.shape_9.setTransform(-92.475,14.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBHIgGgCIAHgTIAHAEIAHABQAIAAAFgEQAFgGAEgJIADgIIglhUQgCgHgDgCQgEgCgEgBIAAgDIAuAAIAAADQgHAAgDAEQgCACACAGIAYA7IAag7QACgGgCgCQgCgEgIAAIAAgDIAeAAIAAADQgFABgDACQgDACgDAHIgoBdQgGAQgJAKQgIAIgNABIgGgBg");
	this.shape_10.setTransform(89.75,-6.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_11.setTransform(80.775,-9.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_12.setTransform(74.275,-11.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAXA1IgBgWQgIALgIAFQgIAHgKgBQgOAAgHgIQgIgIAAgPIAAgzQAAgFgCgDQgDgCgFgCIgFAAIAAgCIAhgKIADAAIAABKQAAAJAEAFQAFAFAIAAQAFAAAHgEQAGgDAHgIIAAg2QAAgFgDgDQgCgCgGgCIgEAAIAAgCIAggKIADAAIAABUQAAAFADACQADADAFABIAEAAIAAACIgfAJg");
	this.shape_13.setTransform(65.475,-8.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAABIIAAgEQAKAAAFgDQAEgDAAgFIAAgtQgDAGgEAFQgEAFgHAEQgFADgHAAQgNAAgJgGQgJgIgFgLQgEgKgBgOQAAgSAHgNQAGgNALgGQAKgHANABQAIgBAHAEQAHAEAGAFIANgMIADAAIAAB/QAAAFAEADQAEADAGAAIAAAEgAgSg6QgGAGgDAKQgDAJAAALQAAAMADAJQACAKAGAGQAGAHAKAAQAHAAAGgFQAGgFADgHIAAgoQAAgIgCgGQgDgHgGgDQgFgEgIgBQgHABgGAFg");
	this.shape_14.setTransform(54.05,-7.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag3BDIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIBnAAIAGAlIgDAAQgEgPgIgIQgJgIgOAAIgfAAIAAA4IAVAAQAIAAAEgCQADgCACgEQACgEAAgHIACAAIAAArIgCAAQAAgGgCgEQgCgFgDgCQgEgCgIAAIgVAAIAAAxQAAAGACACQADADAEAAIAYAAQAPAAAIgIQAJgIADgPIADAAIgFAlg");
	this.shape_15.setTransform(41.35,-10.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_16.setTransform(25.175,-8.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgMA4QgHgHAAgOIAAhFIgLAAIAAgDIAdgZIACAAIAAAXIAdAAIAAAFIgdAAIAABFQAAAIAEAFQAEAFAHAAQAFAAADgCIAFgDIACABIgFAGIgIAGQgFACgHAAQgLAAgHgHg");
	this.shape_17.setTransform(16.525,-9.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANA1IAAgaQgCAIgFAGQgFAGgGADQgHADgIAAQgMAAgIgHQgHgHAAgLQAAgKAFgHQAFgHAKgEQALgEAPgDIAOgDIAAgHQgBgOgFgIQgGgIgJAAQgJAAgEAFQgFAFgBAHQgBAGADAHIgRAGQgGgLAEgJQAEgKAKgFQALgGAPAAQARAAAKAJQAKAKAAARIAAAuQAAAGACACQAEADAEAAIAFAAIAAADIggAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAEAFQAFAFAIAAQAFAAAEgEQAFgDAEgGQADgGABgIIAAgSg");
	this.shape_18.setTransform(8.1,-8.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAAA0IgnhZQgDgGgCgCQgEgDgEAAIAAgDIAvAAIAAADQgIAAgCADQgDADACAFIAZA9IAZg9QACgFgDgDQgCgDgHAAIAAgDIAeAAIAAADQgFAAgDADQgDACgDAGIgmBZg");
	this.shape_19.setTransform(-3.05,-8.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_20.setTransform(-11.375,-11.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQgBgFgCgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAIgHQAHgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_21.setTransform(-18.2,-9.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag3BDIAAgDQAJgBAEgCQAFgDAAgIIAAhjQAAgIgFgCQgEgEgJAAIAAgDIA6AAQAQAAAMAEQAMAEAGAJQAHAIAAANQAAAMgHAIQgGAIgMAEQgMAEgQAAIgSAAIAAAqQAAAIAEADQAEACAJABIAAADgAgPACIAPAAQAQAAAIgHQAJgJAAgOQAAgPgJgIQgIgJgQAAIgPAAg");
	this.shape_22.setTransform(-28.6,-10.575);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgVBHIAAgDQAHgBACgCQAEgDAAgGIAAhnQAAgFgCgDQgDgCgFAAIgFgBIAAgDIAggJIACAAIAAB+QABAGADADQAEACAFABIAAADg");
	this.shape_23.setTransform(-42.45,-11);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAOA1IgBgaQgCAIgFAGQgFAGgGADQgHADgIAAQgMAAgHgHQgIgHAAgLQAAgKAFgHQAFgHAKgEQAKgEAQgDIAOgDIAAgHQAAgOgGgIQgGgIgJAAQgIAAgFAFQgFAFgBAHQgBAGADAHIgSAGQgEgLADgJQAEgKALgFQAKgGAPAAQARAAAKAJQAKAKAAARIAAAuQAAAGACACQADADAFAAIAFAAIAAADIggAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAFAFQAEAFAIAAQAFAAAEgEQAGgDADgGQAEgGAAgIIAAgSg");
	this.shape_24.setTransform(-50.15,-8.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgJBFQgHgDgFgGIgOAMIgDAAIAAh5QAAgFgCgCQgDgCgFgBIgFgBIAAgCIAhgJIACAAIAAA+QADgHAFgGQAEgFAGgDQAFgDAIAAQAMAAAJAHQAJAHAGALQAEAKAAAOQAAASgHANQgFAMgMAHQgKAGgNAAQgHAAgIgDgAgEgSQgFACgDAEQgEAEgCAFIAAAlQABAJACAGQADAIAFAEQAFAEAJAAQAGAAAGgFQAGgGADgJQAEgKAAgLQAAgJgBgIIgGgOQgDgGgGgEQgEgEgIgBQgEABgEADg");
	this.shape_25.setTransform(-61.95,-10.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZAuQgLgFgFgMQgGgMAAgPQAAgPAGgNQAGgMALgHQAMgHANAAQAPAAAKAHQAKAGAHAMQAFALAAAPQAAAQgFAMQgHAMgLAHQgLAHgOAAQgOAAgLgHgAgPgqQgFAGgDAJQgDAJAAAMQAAAJACAJQACAKADAIQAEAIAGAFQAFAEAHAAQAHAAAGgEQAGgGADgJQACgJAAgMQAAgJgBgJQgCgKgEgIQgEgHgFgGQgGgEgGAAQgIAAgGAEg");
	this.shape_26.setTransform(-73.3,-8.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgUBHIAAgDQAFgBAEgCQADgDAAgGIAAhnQAAgFgCgDQgDgCgFAAIgFgBIAAgDIAfgJIADAAIAAB+QAAAGAEADQADACAGABIAAADg");
	this.shape_27.setTransform(-81.85,-11);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgkA9QgQgJgIgPQgIgPgBgTQABgVAIgQQAJgQAPgJQAPgKAVAAQANAAAKAEQALADAHAHQAIAHADAJIgVAGQgCgOgKgIQgJgIgMAAQgNAAgJAIQgKAHgGAOQgFAOAAATQAAARAHAPQAHAPAKAJQAMAJANAAQAHAAAHgCQAHgCAEgFIAAgjQAAgIgDgFQgFgEgKgBIAAgCIA6AAIAAACQgJABgEAEQgFAFAAAIIAAAZQgEAHgJAFQgIAGgKADQgKAEgMAAQgTgBgPgIg");
	this.shape_28.setTransform(-92.05,-10.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#C20000").s().p("AvzD4IAAnuIfnAAIAAHug");
	this.shape_29.setTransform(-0.575,1.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.8,-27.6,203.7,55.2);


// stage content:
(lib.v21PE2026FTABMTargeting300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// EYEBROW
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(141.75,178.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween4("synched",0);
	this.instance_1.setTransform(141.75,133.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},24).to({state:[{t:this.instance_1}]},14).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({_off:false},0).to({_off:true,y:133.1,alpha:1},14,cjs.Ease.cubicInOut).wait(83));

	// TITLE_W_EYEBROW
	this.instance_2 = new lib.Tween5("synched",0);
	this.instance_2.setTransform(147.3,270.65);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({y:226.9,alpha:1},15,cjs.Ease.cubicInOut).wait(55));

	// CTA
	this.instance_3 = new lib.Tween7("synched",0);
	this.instance_3.setTransform(129.3,360.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({y:311.8,alpha:1},15,cjs.Ease.cubicInOut).wait(27));

	// LOGO
	this.instance_4 = new lib.Tween9("synched",0);
	this.instance_4.setTransform(100,58.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(121));

	// RED_BAR
	this.instance_5 = new lib.Tween10("synched",0);
	this.instance_5.setTransform(-173.15,590);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween11("synched",0);
	this.instance_6.setTransform(150,590);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},4).to({state:[{t:this.instance_6}]},14).wait(103));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).to({_off:true,x:150},14,cjs.Ease.cubicInOut).wait(103));

	// SHADOW
	this.instance_7 = new lib.Rectangle();
	this.instance_7.setTransform(150,237.25,1,1,0,0,0,150,237.4);
	this.instance_7.alpha = 0.6406;
	this.instance_7.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(121));

	// FOREGROUND
	this.instance_8 = new lib.Tween12("synched",0);
	this.instance_8.setTransform(155,300);

	this.instance_9 = new lib.Tween13("synched",0);
	this.instance_9.setTransform(180.5,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,x:180.5},120).wait(1));

	// MOUNT
	this.instance_10 = new lib.Tween14("synched",0);
	this.instance_10.setTransform(180.5,322);

	this.instance_11 = new lib.Tween15("synched",0);
	this.instance_11.setTransform(180.5,301);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true,y:301},120).wait(1));

	// SKY
	this.instance_12 = new lib.Tween16("synched",0);
	this.instance_12.setTransform(169,300);

	this.instance_13 = new lib.Tween17("synched",0);
	this.instance_13.setTransform(180.5,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,x:180.5},120).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(121));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-173.1,298,536.1,326);
// library properties:
lib.properties = {
	id: 'EDEBA2EAA84A0C4884EBB71C7C72A593',
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1.png", id:"v2_1_PE2026_FT_ABMTargeting_300x600_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EDEBA2EAA84A0C4884EBB71C7C72A593'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;