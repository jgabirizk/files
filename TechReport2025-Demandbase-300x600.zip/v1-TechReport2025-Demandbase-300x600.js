(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_TechReport2025_Demandbase_300x600_atlas_1", frames: [[0,0,626,1251]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v11_TechReport2025_staticlayered_300600 = function() {
	this.initialize(ss["v1_TechReport2025_Demandbase_300x600_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_300600();
	this.instance.setTransform(-152,-303.8,0.4856,0.4857);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152,-303.8,304,607.6);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_300600();
	this.instance.setTransform(-152,-303.8,0.4856,0.4857);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152,-303.8,304,607.6);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("A3bBkIAAjHMAu3AAAIAADHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-10,300,20);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgBCGIAAAuIgOAAIAAhQIAzAwIAAgvIAOAAIAABRgAkOCJIgKArIgOAAIAThQIAdA1IAdg1IAWBQIgRAAIgJgrIgZAtgAl+CrQgMgMABgSQgBgSAMgMQANgMARAAQASAAAMALQALAMAAATQABARgMAMQgNAMgRAAQgRAAgNgLgAlzB5QgHAIAAAMQAAAMAHAIQAHAIAMAAQALAAAIgJQAHgIAAgLQAAgNgHgIQgHgIgMAAQgMAAgHAJgApPCwQgIgGAAgKQAAgOARgJQgJgLAAgHQAAgJAGgFQAHgGAKAAQAKAAAGAFQAHAFAAAJQAAAMgTAJIAOAQIAIgMIANAAIgOAUIAPARIgQAAIgHgIQgJAKgNAAQgMAAgGgGgApKCfQAAAFAEAEQAEAEAGAAQAKAAAFgIIgRgUIgBAAQgLAGAAAJgApDB3QAAAFAIAIQAOgGAAgIQAAgKgLAAQgLAAAAALgAnZCqQgLgLAAgTQAAgRAMgMQANgMAQAAQAUAAANAPIAAABIgLAJIgBAAQgHgMgOAAQgKAAgIAIQgIAJAAALQABANAGAIQAHAIAMAAQAPAAAGgMIABgBIALAKIAAAAQgMAQgVAAQgSAAgMgMgAEjB/Qg2g1AAhKQAAhLA2g1QA1g1BKAAQANAAAQACIgPAUIgNAAQhAAAgsArQgtAsAAA+QAAA9AtArQAsAsBAAAQA/AAAtgsQAtgrAAg9QAAgvgcgmQgbgmgrgQIgFgZQA5AQAlAwQAlAxAAA9QAABKg1A1Qg1A1hMAAQhKAAg1g1gABhC0IAAghIgdguIARAAIAUAgIAUggIAQAAIgdAuIAAAhgAgzC0IgIgRIgeAAIgHARIgQAAIAnhQIAnBQgAhUCXIAUAAIgJgXgAiqC0IAAhPIATAAQAgAAAAAZQAAAMgJAGQgJAHgOAAIgFAAIAAAdgAicCKIAFABQARAAAAgNQAAgNgRAAIgFAAgAgDhIIAAB5IgmAAIAAjSICIB+IAAh7IAmAAIAADUgAiqAxIAAjPIAnAAIAADPgAkIAxIgTgsIhQAAIgUAsIgnAAIBljSIBkDSgAlcgcIAzAAIgYg8gApQAxIAAjPIAyAAQAmAAAUAOQAUAOAAAaQAAAPgIALQgIALgMAGQAoAOAAAlQAAAcgVAPQgVAQgnAAgAopARIARAAQArAAABgaQAAgQgMgHQgKgGgWAAIgRAAgAophGIAJAAQAVAAAJgGQALgHAAgPQAAgPgLgHQgJgGgXAAIgHAAgAFmgUIBch3IAgCTg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape.setTransform(66.425,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAuAAQAPAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgIADIAiA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_1.setTransform(54.95,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_2.setTransform(40.175,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_3.setTransform(26.825,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_4.setTransform(14.925,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAvAAQAOAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgJADIAjA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_5.setTransform(2.85,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_6.setTransform(-14.375,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_7.setTransform(-27.8,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_8.setTransform(-40.925,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-57.375,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_10.setTransform(-68.575,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggA6QgPgJgHgOQgHgPgBgTIAAgBQABgTAHgPQAJgPAPgIQAPgIASAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgHgGgMABQgKAAgIAFQgIAFgEAKQgFAJABANIAAABQAAANADAJQAEAKAIAFQAIAGAMAAQAKAAAHgEQAGgEAEgGQADgGAAgHIgcAAIAAgVIA5AAIAAANQAAARgHANQgHANgOAHQgNAHgTAAQgVAAgOgIg");
	this.shape_11.setTransform(-82.2,1.6727);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Agog2IBQA2IhQA3g");
	this.shape_12.setTransform(87.15,2.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.2,-14.2,182.4,28.4);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape.setTransform(66.425,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAuAAQAPAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgIADIAiA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_1.setTransform(54.95,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_2.setTransform(40.175,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_3.setTransform(26.825,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_4.setTransform(14.925,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgMAAIAAAxIgeAAIAAh/IAvAAQAOAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgDAHQgEAHgGADQgFAEgJADIAjA2gAgVgEIAPAAQAKAAAGgFQAFgEABgKIAAAAQgBgKgFgEQgGgEgKAAIgPAAg");
	this.shape_5.setTransform(2.85,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_6.setTransform(-14.375,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_7.setTransform(-27.8,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_8.setTransform(-40.925,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-57.375,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_10.setTransform(-68.575,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggA6QgPgJgHgOQgHgPgBgTIAAgBQABgTAHgPQAJgPAPgIQAPgIASAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgHgGgMABQgKAAgIAFQgIAFgEAKQgFAJABANIAAABQAAANADAJQAEAKAIAFQAIAGAMAAQAKAAAHgEQAGgEAEgGQADgGAAgHIgcAAIAAgVIA5AAIAAANQAAARgHANQgHANgOAHQgNAHgTAAQgVAAgOgIg");
	this.shape_11.setTransform(-82.2,1.6727);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Agog2IBQA2IhQA3g");
	this.shape_12.setTransform(87.15,2.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.2,-14.2,182.4,28.4);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNBWQgEgFAAgGQAAgHAEgFQAFgEAHAAQAGAAAEAEQAEAFAAAHQAAAGgEAFQgFAEgFAAQgHAAgFgEgAgFAnQgDgMACgKQADgJAEgIIANgPQAGgHAFgJQAEgJABgLQgBgOgHgJQgIgIgMAAQgIAAgHAGQgHAFgEAJQgFAJgBAMIgWgHQABgLAIgJQAHgJALgGQAMgGAOAAQAYAAAOALQAOALAAATQAAAMgGAKQgGAJgIAIIgRAOQgIAHgGAJQgEAIABAKg");
	this.shape.setTransform(-5.275,2.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfBFIAAgeQgLAPgLAHQgKAIgOAAQgRAAgKgKQgJgLAAgTIAAhFQAAgHgDgDQgEgDgHgBIgGAAIAAgEIAmgKIADAAIAABgQABAMAGAHQAGAHALAAQAJAAAJgFQAJgFAKgMIAAhIQAAgHgEgDQgDgDgHgBIgGAAIAAgEIAlgKIAEAAIAABtQAAAHADADQAEADAHABIAGAAIAAAEIglAKg");
	this.shape_1.setTransform(-18.325,4.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfA8QgOgIgHgPQgIgPAAgTQAAgVAIgQQAIgQAOgJQAOgJARAAQASAAAOAJQANAIAHAPQAIAPAAATQAAAVgIAQQgHAQgOAJQgOAJgSAAQgSAAgNgJgAgUg2QgIAHgFAMQgEAMAAAQQAAALACALQADAMAEALQAFAKAIAHQAIAGALABQAKgBAIgGQAIgHAEgNQAEgMAAgQQAAgKgCgMQgDgMgEgKQgFgKgIgHQgIgGgKgBQgKAAgIAHg");
	this.shape_2.setTransform(-33.15,4.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2BcIgHgCIAHgVQAEADAFABQAEACAEAAQALAAAHgHQAHgGAEgNIAFgMIguhvQgEgHgEgDQgDgEgHAAIAAgEIA4AAIAAAEQgKABgDADQgEAEACAGIAiBUIAihUQADgGgDgEQgEgDgIgBIAAgEIAmAAIAAAEQgHAAgEAEQgEADgDAHIgzB9QgIAUgKALQgLALgQAAIgIgBg");
	this.shape_3.setTransform(-47.025,7.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbA8QgNgJgHgPQgHgOgBgTQABgVAHgQQAIgQAOgJQAOgJARAAQAQAAALAHQALAIAGAMQAGANAAARIhYAAIAAACIAAADQgBARAGANQAGAMALAHQAKAHAPAAQAOAAAJgGQAKgHAFgJIADACQgDALgHAJQgHAIgLAGQgLAFgNAAQgSAAgNgJgAAggSQAAgLgEgKQgDgJgHgGQgGgHgKAAQgIAAgHAGQgHAFgFAKQgFAKgBAMIA/AAIAAAAg");
	this.shape_4.setTransform(-66.975,4.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBDIAAgDQAIgCAFgDQAFgDAAgIIAAhXQAAgGgDgDQgDgDgHgBIgHAAIAAgEIAmgKIAEAAIAAAkQAGgSAJgJQAKgJALAAIAFAAIAGACIgCAVIgGgCIgHgCQgKABgJAFQgIAHgFALIAABHQAAAIAFADQAGADANACIAAADg");
	this.shape_5.setTransform(-78.575,4.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAcBZIAAgEQANgBADgEQACgFgFgMIgOggIhJAAIgOAgQgFAMADAFQADAEAOABIAAAEIgwAAIAAgEQAJgBAGgEQAGgFAFgMIBBiXIADAAIBCCXQAFAMAGAFQAGAEAKABIAAAEgAAYAYIghhPIgiBPIBDAAg");
	this.shape_6.setTransform(-93.475,2.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.1,-19.3,210.3,38.6);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNBWQgEgFAAgGQAAgHAEgFQAFgEAHAAQAGAAAEAEQAEAFAAAHQAAAGgEAFQgFAEgFAAQgHAAgFgEgAgFAnQgDgMACgKQADgJAEgIIANgPQAGgHAFgJQAEgJABgLQgBgOgHgJQgIgIgMAAQgIAAgHAGQgHAFgEAJQgFAJgBAMIgWgHQABgLAIgJQAHgJALgGQAMgGAOAAQAYAAAOALQAOALAAATQAAAMgGAKQgGAJgIAIIgRAOQgIAHgGAJQgEAIABAKg");
	this.shape.setTransform(-5.275,2.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfBFIAAgeQgLAPgLAHQgKAIgOAAQgRAAgKgKQgJgLAAgTIAAhFQAAgHgDgDQgEgDgHgBIgGAAIAAgEIAmgKIADAAIAABgQABAMAGAHQAGAHALAAQAJAAAJgFQAJgFAKgMIAAhIQAAgHgEgDQgDgDgHgBIgGAAIAAgEIAlgKIAEAAIAABtQAAAHADADQAEADAHABIAGAAIAAAEIglAKg");
	this.shape_1.setTransform(-18.325,4.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfA8QgOgIgHgPQgIgPAAgTQAAgVAIgQQAIgQAOgJQAOgJARAAQASAAAOAJQANAIAHAPQAIAPAAATQAAAVgIAQQgHAQgOAJQgOAJgSAAQgSAAgNgJgAgUg2QgIAHgFAMQgEAMAAAQQAAALACALQADAMAEALQAFAKAIAHQAIAGALABQAKgBAIgGQAIgHAEgNQAEgMAAgQQAAgKgCgMQgDgMgEgKQgFgKgIgHQgIgGgKgBQgKAAgIAHg");
	this.shape_2.setTransform(-33.15,4.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2BcIgHgCIAHgVQAEADAFABQAEACAEAAQALAAAHgHQAHgGAEgNIAFgMIguhvQgEgHgEgDQgDgEgHAAIAAgEIA4AAIAAAEQgKABgDADQgEAEACAGIAiBUIAihUQADgGgDgEQgEgDgIgBIAAgEIAmAAIAAAEQgHAAgEAEQgEADgDAHIgzB9QgIAUgKALQgLALgQAAIgIgBg");
	this.shape_3.setTransform(-47.025,7.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbA8QgNgJgHgPQgHgOgBgTQABgVAHgQQAIgQAOgJQAOgJARAAQAQAAALAHQALAIAGAMQAGANAAARIhYAAIAAACIAAADQgBARAGANQAGAMALAHQAKAHAPAAQAOAAAJgGQAKgHAFgJIADACQgDALgHAJQgHAIgLAGQgLAFgNAAQgSAAgNgJgAAggSQAAgLgEgKQgDgJgHgGQgGgHgKAAQgIAAgHAGQgHAFgFAKQgFAKgBAMIA/AAIAAAAg");
	this.shape_4.setTransform(-66.975,4.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBDIAAgDQAIgCAFgDQAFgDAAgIIAAhXQAAgGgDgDQgDgDgHgBIgHAAIAAgEIAmgKIAEAAIAAAkQAGgSAJgJQAKgJALAAIAFAAIAGACIgCAVIgGgCIgHgCQgKABgJAFQgIAHgFALIAABHQAAAIAFADQAGADANACIAAADg");
	this.shape_5.setTransform(-78.575,4.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAcBZIAAgEQANgBADgEQACgFgFgMIgOggIhJAAIgOAgQgFAMADAFQADAEAOABIAAAEIgwAAIAAgEQAJgBAGgEQAGgFAFgMIBBiXIADAAIBCCXQAFAMAGAFQAGAEAKABIAAAEgAAYAYIghhPIgiBPIBDAAg");
	this.shape_6.setTransform(-93.475,2.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.1,-19.3,210.3,38.6);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape.setTransform(31.275,38.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQgBAIgIQAIgJAAgPIAAgYQgEAHgHAHQgHAHgKAEQgIADgMAAQgSABgPgJQgPgJgJgQQgJgRAAgYIAAgCQAAgXAJgRQAJgRAPgKQAPgIASgBQASABAMAGQALAHAHAMIAAgVIA2AAIAACPQgBAigWATQgWARgpABQgoAAgUgQgAgUg7QgIAKAAAQIAAACQAAARAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgRgIgJQgIgJgOAAQgPgBgHAKg");
	this.shape_1.setTransform(12.225,41.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_2.setTransform(-6.975,35.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_3.setTransform(-25.175,38.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_4.setTransform(-46.075,38.6985);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgIgHAAgNQAAgMAIgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_5.setTransform(-57.25,35.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_6.setTransform(-70.675,38.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBxIAAhbQAAgOgGgGQgFgFgMAAQgLgBgHAHQgIAHAAAPIAABYIg1AAIAAjhIA1AAIAABeQAHgMANgIQALgJAUAAQAXAAAOAPQAOAOAAAdIAABmg");
	this.shape_7.setTransform(-88.925,35.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBUQgOgOAAgcIAAhFIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABBQAAAIAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgHACgKgBQgaABgOgNg");
	this.shape_8.setTransform(-104.4,37.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_9.setTransform(29.075,8.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_10.setTransform(10.625,5.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgHgHgBgNQABgMAHgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_11.setTransform(-3.15,2.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_12.setTransform(-17.625,2.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_13.setTransform(-36.125,5.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_14.setTransform(-54.525,5.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_15.setTransform(-69.55,4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZBOIgbguIgdAuIg3AAIA1hPIgxhMIA+AAIAXApIAYgpIA3AAIgyBJIA3BSg");
	this.shape_16.setTransform(-83.925,5.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_17.setTransform(-101.025,5.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_18.setTransform(83.575,-27.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_19.setTransform(68.725,-27.4015);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgxBOQgLgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgLABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQARAGAIANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_20.setTransform(52.85,-27.325);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AABBSQgiAAgSgNQgTgOAAgaIAxAAQABAJAFAEQAFAFAKAAQAKAAAEgEQAGgDgBgGQAAgGgGgDQgHgDgPgCQgUgDgOgFQgNgGgGgJQgHgLAAgQQABgRAJgMQAJgLAPgGQAPgFATAAQAcgBATAMQASALADAcIgwAAQgCgIgFgDQgFgEgHAAQgKAAgEADQgFAEABAFQAAAFAFADQAHADANACQAWACAOAGQAOAFAHAKQAIAKAAAQQgBAcgSANQgTANgfAAIgCAAg");
	this.shape_21.setTransform(30.9,-27.3251);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_22.setTransform(17.125,-27.4015);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_23.setTransform(1.325,-27.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_24.setTransform(-17.675,-30.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgwBOQgMgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAQAAIAAgEQgBgLgEgHQgEgGgNgBQgKABgEAFQgFAFAAAIIgzAAQABgTAKgMQAKgNAQgGQAQgGAVAAQAWAAAQAGQAPAGAJANQAJANAAAVIAABlIg0AAIAAgTQgGAJgLAHQgLAGgSAAQgPAAgLgEgAgPASQgHAEAAAJQAAAHAEAEQAFAEAKAAQAKAAAIgGQAHgGABgKIAAgKIgPAAQgPAAgIAEg");
	this.shape_25.setTransform(-35.95,-27.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_26.setTransform(-53.375,-27.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-66.725,-30.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeBrIAAjVIA9AAIAADVg");
	this.shape_28.setTransform(-82.3,-30.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AArBrIgMgoIhGAAIgLAoIg5AAIBEjVIBPAAIBEDVgAAUAZIgXhRIgXBRIAuAAg");
	this.shape_29.setTransform(-98.8,-30.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-55.5,224,111.1);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape.setTransform(31.275,38.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQgBAIgIQAIgJAAgPIAAgYQgEAHgHAHQgHAHgKAEQgIADgMAAQgSABgPgJQgPgJgJgQQgJgRAAgYIAAgCQAAgXAJgRQAJgRAPgKQAPgIASgBQASABAMAGQALAHAHAMIAAgVIA2AAIAACPQgBAigWATQgWARgpABQgoAAgUgQgAgUg7QgIAKAAAQIAAACQAAARAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgRgIgJQgIgJgOAAQgPgBgHAKg");
	this.shape_1.setTransform(12.225,41.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_2.setTransform(-6.975,35.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_3.setTransform(-25.175,38.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_4.setTransform(-46.075,38.6985);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgIgHAAgNQAAgMAIgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_5.setTransform(-57.25,35.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_6.setTransform(-70.675,38.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBxIAAhbQAAgOgGgGQgFgFgMAAQgLgBgHAHQgIAHAAAPIAABYIg1AAIAAjhIA1AAIAABeQAHgMANgIQALgJAUAAQAXAAAOAPQAOAOAAAdIAABmg");
	this.shape_7.setTransform(-88.925,35.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBUQgOgOAAgcIAAhFIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABBQAAAIAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgHACgKgBQgaABgOgNg");
	this.shape_8.setTransform(-104.4,37.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BeQgUgQgDgbIA2AAQABAKAHAFQAGAGAPAAQAQAAAIgKQAIgIAAgPIAAgYQgEAIgHAGQgHAGgKAFQgIADgMAAQgSAAgPgIQgPgJgJgRQgJgPAAgYIAAgDQAAgXAJgRQAJgRAPgKQAPgIASgBQASAAAMAHQALAIAHALIAAgVIA2AAIAACPQgBAigWATQgWASgpAAQgogBgUgPgAgUg6QgIAJAAAQIAAADQAAAQAIAKQAIAIANAAQAPAAAIgIQAIgKAAgRIAAgCQAAgQgIgKQgIgJgOAAQgPAAgHAKg");
	this.shape_9.setTransform(29.075,8.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_10.setTransform(10.625,5.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgVhBQgHgHgBgNQABgMAHgIQAJgHAMgBQANABAIAHQAIAIABAMQgBANgIAHQgIAIgNAAQgMAAgJgIg");
	this.shape_11.setTransform(-3.15,2.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_12.setTransform(-17.625,2.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZBQIAAhaQAAgNgGgGQgFgHgMAAQgLAAgHAHQgIAIAAAOIAABXIg1AAIAAibIA1AAIAAAZQAHgNANgIQALgJAUAAQAXAAAOAPQAOAPAAAeIAABkg");
	this.shape_13.setTransform(-36.125,5.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_14.setTransform(-54.525,5.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_15.setTransform(-69.55,4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZBOIgbguIgdAuIg3AAIA1hPIgxhMIA+AAIAXApIAYgpIA3AAIgyBJIA3BSg");
	this.shape_16.setTransform(-83.925,5.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_17.setTransform(-101.025,5.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_18.setTransform(83.575,-27.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_19.setTransform(68.725,-27.4015);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgxBOQgLgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgLABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQARAGAIANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_20.setTransform(52.85,-27.325);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AABBSQgiAAgSgNQgTgOAAgaIAxAAQABAJAFAEQAFAFAKAAQAKAAAEgEQAGgDgBgGQAAgGgGgDQgHgDgPgCQgUgDgOgFQgNgGgGgJQgHgLAAgQQABgRAJgMQAJgLAPgGQAPgFATAAQAcgBATAMQASALADAcIgwAAQgCgIgFgDQgFgEgHAAQgKAAgEADQgFAEABAFQAAAFAFADQAHADANACQAWACAOAGQAOAFAHAKQAIAKAAAQQgBAcgSANQgTANgfAAIgCAAg");
	this.shape_21.setTransform(30.9,-27.3251);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_22.setTransform(17.125,-27.4015);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_23.setTransform(1.325,-27.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgyBqQgPgJgJgSQgJgRAAgcIAAgCQAAgbAJgRQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAhbIA1AAIAADhIg1AAIAAgZQgGAMgNAIQgMAJgRAAQgTAAgOgJgAgVABQgIAKAAAUIAAADQABAUAIAKQAIAKANAAQAOAAAJgKQAIgKAAgVIAAgCQAAgUgIgKQgIgJgPAAQgOAAgIAJg");
	this.shape_24.setTransform(-17.675,-30.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgwBOQgMgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAQAAIAAgEQgBgLgEgHQgEgGgNgBQgKABgEAFQgFAFAAAIIgzAAQABgTAKgMQAKgNAQgGQAQgGAVAAQAWAAAQAGQAPAGAJANQAJANAAAVIAABlIg0AAIAAgTQgGAJgLAHQgLAGgSAAQgPAAgLgEgAgPASQgHAEAAAJQAAAHAEAEQAFAEAKAAQAKAAAIgGQAHgGABgKIAAgKIgPAAQgPAAgIAEg");
	this.shape_25.setTransform(-35.95,-27.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_26.setTransform(-53.375,-27.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-66.725,-30.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeBrIAAjVIA9AAIAADVg");
	this.shape_28.setTransform(-82.3,-30.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AArBrIgMgoIhGAAIgLAoIg5AAIBEjVIBPAAIBEDVgAAUAZIgXhRIgXBRIAuAAg");
	this.shape_29.setTransform(-98.8,-30.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-55.5,224,111.1);


// stage content:
(lib.v1TechReport2025Demandbase300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(150,213.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(150,159.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).to({state:[{t:this.instance_1}]},15).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,y:159.6,alpha:1},15,cjs.Ease.cubicInOut).wait(92));

	// SUBTITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(143.7,277.3);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(143.7,237.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},69).to({state:[{t:this.instance_3}]},15).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({_off:true,y:237.3,alpha:1},15,cjs.Ease.cubicInOut).wait(42));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(129.75,561.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(129.75,532.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},99).to({state:[{t:this.instance_5}]},15).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({_off:true,y:532.7,alpha:1},15,cjs.Ease.cubicInOut).wait(12));

	// LOGO
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(100,57.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(126));

	// RED_BAR
	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(-270.05,590);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:150},14,cjs.Ease.cubicInOut).wait(112));

	// BACKGROUND
	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(148.65,299.35,1.1776,1.1776,0,0,0,-0.1,-0.2);

	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(150,300.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},125).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:150,y:300.8},125).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-270,241.9,597.8,415.4);
// library properties:
lib.properties = {
	id: '6A3A26545A15EC43A3F8B5893C08FB60',
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_TechReport2025_Demandbase_300x600_atlas_1.jpg", id:"v1_TechReport2025_Demandbase_300x600_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6A3A26545A15EC43A3F8B5893C08FB60'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;