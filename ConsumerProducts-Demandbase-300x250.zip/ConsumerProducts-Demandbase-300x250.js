(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ConsumerProducts_Demandbase_300x250_atlas_1", frames: [[0,0,626,521]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v1ConcumerProductsPadiDemandbasestatics_300250 = function() {
	this.initialize(ss["ConsumerProducts_Demandbase_300x250_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgtAsg+AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AASAiIgGgPIgYAAIgGAPIgNAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.225,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.4,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAdQgFgFgBgIQAAgMAOgGQgIgJAAgGQABgHAFgFQAGgFAIAAQAHAAAGAEQAFAFAAAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgJAJgJAAQgJAAgHgGgAgJADQgJAEAAAIQAAALAMAAQAGAAAFgGIgNgRgAgMgRQAAAFAHAGQAKgGAAgGQAAgIgIAAQgJAAAAAJg");
	this.shape_3.setTransform(-47.05,11.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQAfgBARAMQARALAAAWQAAAMgHAKQgGAKgLAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAPAAQAjAAAAgXQAAgYgjAAIgPAAgAgZgMIAHAAQASAAAHgFQAJgGAAgNQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.625,-4.576);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.925,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQBWIAAirIAhAAIAACrg");
	this.shape_6.setTransform(-12.65,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhDIAYAsIAYgsIARBDIgNAAIgIgjIgUAlg");
	this.shape_8.setTransform(-20.525,11.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIAQAAQAaAAABAVQgBAKgHAFQgIAEgLAAIgDAAIAAAZgAgIgBIADAAQANAAAAgKQAAgLgNAAIgDAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIAQgbIAPAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.7,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgNALgKQAKgKANAAQAQAAALAMIAAABIgKAHIAAAAQgFgJgMAAQgIAAgGAGQgHAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIgBABQgJAMgRAAQgOAAgKgJg");
	this.shape_11.setTransform(-37.375,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXAZQgLgKAAgPQAAgNALgLQAKgKANAAQAPAAAKAKQAJAJAAAPQABAOgLALQgKAKgOAAQgOAAgJgKgAgOgPQgHAGABAJQgBAKAHAHQAFAGAJAAQAJAAAHgHQAGgGAAgKQAAgKgGgGQgGgHgKAAQgIAAgGAIg");
	this.shape_12.setTransform(-29.45,11.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v1ConcumerProductsPadiDemandbasestatics_300250();
	this.instance.setTransform(-152.6,-127,0.4875,0.4875);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.6,-127,305.2,254);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AsfRMMAAAgiXIY/AAMAAAAiXg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-110,160,220);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(44.925,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(37.275,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgFgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQADAHAGADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_2.setTransform(27.4,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_3.setTransform(18.4,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(10.425,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(2.325,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-9.225,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_7.setTransform(-18.2,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-26.975,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-37.975,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-45.475,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFANAAQAJAAAJADQAHADAGAGQAGAHABALIgTAAQgCgIgFgEQgEgDgIAAQgGAAgGADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgKAEQgJAFgMAAQgNAAgKgGg");
	this.shape_11.setTransform(-54.55,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbgmIA3AmIg3Ang");
	this.shape_12.setTransform(58.625,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.4,-10.1,122.9,20.299999999999997);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape.setTransform(52.875,34.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_1.setTransform(44.475,34.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLAAgQIAAgBQABgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAeAAQgCAQgMAJQgMAIgWAAQgNAAgMgFgAASgJQAAgJgFgFQgDgEgJAAQgGAAgEAEQgGAFgBAJIAiAAIAAAAg");
	this.shape_2.setTransform(35.05,34.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgSBAIAAh/IAlAAIAAB/g");
	this.shape_3.setTransform(22.925,32.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAaBAIgHgYIgqAAIgHAYIgiAAIAph/IAvAAIApB/gAAMAPIgNgxIgPAxIAcAAg");
	this.shape_4.setTransform(13.025,32.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgCgEgIAAQgGAAgEAEQgFAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFAMAAQANAAAIAIQAJAJAAASIAAA8g");
	this.shape_5.setTransform(-2.85,34.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_6.setTransform(-13.85,34.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOQgCAEgEAEQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_7.setTransform(-25.275,36.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGAOAAQAMAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAfAAQgDAQgMAJQgMAIgVAAQgPAAgKgFgAASgJQgBgJgDgFQgEgEgIAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_8.setTransform(-39.7,34.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAPBEIAAg3QAAgIgEgEQgDgDgHAAQgGAAgFAEQgDAEgBAJIAAA1IggAAIAAiHIAgAAIAAA5QAEgIAIgFQAHgFALAAQAOAAAIAJQAJAIAAARIAAA+g");
	this.shape_9.setTransform(-50.7,32.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_10.setTransform(-59.975,33.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgDgEQgDgEgIAAQgGAAgFAEQgEAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFALAAQAOAAAJAIQAIAJAAASIAAA8g");
	this.shape_11.setTransform(38.35,13.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_12.setTransform(30.075,11.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgEAEQgFAFgCAJIAiAAIAAAAg");
	this.shape_13.setTransform(18.5,13.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXAsQgLgFgHgLQgGgLAAgQIAAgBQgBgPAIgLQAGgLAMgGQAKgFAOAAQALgBALAEQAKAEAGAJQAHAIABAOIgfAAQgBgGgDgEQgEgDgGAAQgIAAgFAGQgFAGABALIAAABQgBAMAFAHQAFAGAIAAQAHAAAEgEQAFgEAAgIIAeAAQgBAMgGAJQgFAJgLAFQgKAEgPAAQgNAAgLgFg");
	this.shape_14.setTransform(7.9,13.7222);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgDgEgHAAQgGAAgFAEQgDAEgBAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFALAAQAOAAAIAIQAJAJAAASIAAA8g");
	this.shape_15.setTransform(-3,13.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape_16.setTransform(-14.075,13.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgRAvIgihdIAiAAIATA8IATg8IAfAAIgiBdg");
	this.shape_17.setTransform(-23.9,13.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGAOAAQAMAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAfAAQgDAQgMAJQgMAIgVAAQgPAAgKgFgAASgJQgBgJgDgFQgEgEgIAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_18.setTransform(-34.3,13.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_19.setTransform(-42.35,11.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgEAEQgFAFgCAJIAiAAIAAAAg");
	this.shape_20.setTransform(-50.35,13.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_21.setTransform(-59.275,13.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AArAwIAAg3QgBgHgDgEQgDgDgGAAQgGAAgEAEQgEAEAAAIIAAA1IgfAAIAAg3QAAgHgDgEQgDgDgGAAQgGAAgEAEQgEAEgBAIIAAA1IgfAAIAAhdIAfAAIAAAOQAFgGAHgFQAIgFALAAQAIAAAGAEQAGADAEAIQAGgIAIgEQAIgEAJABQAJAAAHADQAHAEAEAIQADAIAAAMIAAA8g");
	this.shape_22.setTransform(30.65,-7.0278);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_23.setTransform(19.625,-9.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgHAAgDACg");
	this.shape_24.setTransform(11.525,-6.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_25.setTransform(3.9,-8.975);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgXAsQgLgFgHgLQgGgLgBgQIAAgBQAAgPAHgLQAHgLALgGQAMgFANAAQALgBAKAEQAKAEAHAJQAHAIABAOIgeAAQgCgGgDgEQgEgDgGAAQgIAAgFAGQgEAGAAALIAAABQAAAMAEAHQAFAGAIAAQAHAAAEgEQAFgEABgIIAcAAQAAAMgGAJQgFAJgKAFQgLAEgPAAQgNAAgLgFg");
	this.shape_26.setTransform(-3.95,-6.9278);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGANAAQANAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAIAAAEgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgKgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_27.setTransform(-14.6,-6.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_28.setTransform(-23.525,-6.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgDgEgHAAQgGAAgFAEQgDAEgBAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFALAAQAOAAAIAIQAJAJAAASIAAA8g");
	this.shape_29.setTransform(-36.75,-7.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape_30.setTransform(-47.825,-6.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgXAsQgLgFgHgLQgGgLgBgQIAAgBQAAgPAIgLQAGgLAMgGQALgFANAAQALgBAKAEQALAEAGAJQAHAIABAOIgfAAQAAgGgEgEQgEgDgGAAQgIAAgFAGQgFAGABALIAAABQgBAMAFAHQAFAGAIAAQAHAAAEgEQAFgEABgIIAdAAQgBAMgGAJQgFAJgLAFQgKAEgPAAQgNAAgLgFg");
	this.shape_31.setTransform(-58.05,-6.9278);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAAxQgTAAgLgIQgLgIgBgQIAeAAQAAAGADACQADADAGAAQAGAAADgCQADgCAAgEQAAgDgEgCIgNgDQgMgCgIgDQgIgEgEgFQgEgGAAgJQAAgLAGgHQAFgHAJgDQAKgDALAAQAQgBALAHQALAHACARIgdAAQgBgFgDgCQgDgCgEAAQgFAAgDACQgDACAAADQAAADAEACIALADQANABAJAEQAIADAFAFQAEAGAAAKQAAARgMAIQgKAHgSAAIgDAAg");
	this.shape_32.setTransform(24.625,-27.5752);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgiA6QgPgIgHgPQgIgPAAgTIAAgBQAAgTAJgPQAIgPAQgIQAPgIASAAQAQAAANAEQANAFAIALQAJAKABARIgkAAQgCgJgFgFQgGgEgLAAQgMAAgIAJQgIAKAAARIAAABQAAALADAIQADAJAHAEQAGAFAKAAQAJAAAGgCQAFgDADgEQADgFAAgFIgYAAIAAgZIA8AAIAAAPQAAARgHAMQgHANgOAIQgOAHgVAAQgVAAgPgIg");
	this.shape_33.setTransform(12.875,-29.275);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgxBAIAAh/IAxAAQAZAAANALQAMALAAAVIAAAAQAAAUgNAKQgNALgYAAIgNAAIAAArgAgNgDIALAAQAIAAAFgEQAEgFAAgHIAAgBQAAgIgEgEQgFgEgIAAIgLAAg");
	this.shape_34.setTransform(0.175,-29.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AghA6QgPgIgIgPQgHgOAAgUIAAgBQAAgUAJgOQAIgPAPgIQAPgIASAAQARAAANAFQANAFAHALQAIALABARIglAAQgCgKgFgFQgFgFgKAAQgLAAgIAJQgHAJAAASIAAABQAAARAHAJQAIAKAMAAQAJAAAHgFQAGgFABgLIAlAAQgBARgIALQgIALgNAGQgNAFgQAAQgWAAgPgIg");
	this.shape_35.setTransform(-12.8,-29.275);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAOAvIgOgzIgNAzIggAAIgchdIAhAAIAOA3IAQg3IAZAAIAOA3IAPg3IAeAAIgdBdg");
	this.shape_36.setTransform(-30.9,-27.55);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgZAsQgMgGgGgLQgIgKAAgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQAPAAAMAFQALAGAHALQAGALABAPIAAAAQgBAQgGALQgHALgMAGQgMAFgOAAQgNAAgMgFgAgNgSQgEAGAAAMIAAAAQgBANAFAGQAFAHAIAAQAJgBAFgGQAEgGABgMIAAgBQgBgMgEgGQgEgGgKAAQgIAAgFAGg");
	this.shape_37.setTransform(-43.8,-27.575);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAVBAIAAgyIgpAAIAAAyIglAAIAAh/IAlAAIAAAxIApAAIAAgxIAlAAIAAB/g");
	this.shape_38.setTransform(-56.3,-29.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.3,-45.3,130.7,90.6);


// stage content:
(lib.ConsumerProductsDemandbase300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// General_Headline
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(94.3,162.35);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({y:126.5,alpha:1},20,cjs.Ease.cubicInOut).wait(82));

	// CTA
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(89.2,234.55);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({_off:false},0).to({y:214.05,alpha:1},19,cjs.Ease.cubicInOut).wait(53));

	// Bain_Logo
	this.Bain_Logo__300x250_ = new lib.StackedWhiteRGB();
	this.Bain_Logo__300x250_.name = "Bain_Logo__300x250_";
	this.Bain_Logo__300x250_.setTransform(70,40.75,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.Bain_Logo__300x250_).wait(121));

	// Red_Box
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(14.75,124.65,1.9519,1,0,0,0,-80,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1,x:14.8},19,cjs.Ease.cubicInOut).wait(102));

	// Background
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(149.6,124,1.2874,1.2874);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1,scaleY:1},120).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(103.2,85.6,242.90000000000003,202.00000000000003);
// library properties:
lib.properties = {
	id: '7CD986CA07CC3846BEA1AC01B19B29AE',
	width: 300,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"ConsumerProducts_Demandbase_300x250_atlas_1.jpg", id:"ConsumerProducts_Demandbase_300x250_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['7CD986CA07CC3846BEA1AC01B19B29AE'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;