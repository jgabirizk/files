(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ConsumerProducts_Demandbase_728x90_atlas_1", frames: [[0,0,1517,188]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v1ConcumerProductsPadiDemandbasestatics_72890 = function() {
	this.initialize(ss["ConsumerProducts_Demandbase_728x90_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgtAsg+AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AASAiIgGgPIgYAAIgGAPIgNAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.225,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.4,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAdQgFgFgBgIQAAgMAOgGQgIgJAAgGQABgHAFgFQAGgFAIAAQAHAAAGAEQAFAFAAAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgJAJgJAAQgJAAgHgGgAgJADQgJAEAAAIQAAALAMAAQAGAAAFgGIgNgRgAgMgRQAAAFAHAGQAKgGAAgGQAAgIgIAAQgJAAAAAJg");
	this.shape_3.setTransform(-47.05,11.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQAfgBARAMQARALAAAWQAAAMgHAKQgGAKgLAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAPAAQAjAAAAgXQAAgYgjAAIgPAAgAgZgMIAHAAQASAAAHgFQAJgGAAgNQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.625,-4.576);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.925,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQBWIAAirIAhAAIAACrg");
	this.shape_6.setTransform(-12.65,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhDIAYAsIAYgsIARBDIgNAAIgIgjIgUAlg");
	this.shape_8.setTransform(-20.525,11.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIAQAAQAaAAABAVQgBAKgHAFQgIAEgLAAIgDAAIAAAZgAgIgBIADAAQANAAAAgKQAAgLgNAAIgDAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIAQgbIAPAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.7,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgNALgKQAKgKANAAQAQAAALAMIAAABIgKAHIAAAAQgFgJgMAAQgIAAgGAGQgHAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIgBABQgJAMgRAAQgOAAgKgJg");
	this.shape_11.setTransform(-37.375,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXAZQgLgKAAgPQAAgNALgLQAKgKANAAQAPAAAKAKQAJAJAAAPQABAOgLALQgKAKgOAAQgOAAgJgKgAgOgPQgHAGABAJQgBAKAHAHQAFAGAJAAQAJAAAHgHQAGgGAAgKQAAgKgGgGQgGgHgKAAQgIAAgGAIg");
	this.shape_12.setTransform(-29.45,11.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v1ConcumerProductsPadiDemandbasestatics_72890();
	this.instance.setTransform(-379.25,-47,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-379.2,-47,758.5,94);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("EgidAFeIAAq7MBE6AAAIAAK7g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-220.5,-35,441.1,70);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(44.675,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(37.025,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWAmQgLgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgJAGgOAAQgNAAgJgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQAEAHAFADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_2.setTransform(27.15,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAJAHQAIAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAADgDQAEgEABgGIAAgBQgBgGgEgDQgDgDgGAAIgKAAg");
	this.shape_3.setTransform(18.15,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(10.175,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(2.075,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-9.475,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIghAAIAAAjIgUAAIAAhVIAUAAIAAAkIAhAAIAAgkIAUAAIAABVg");
	this.shape_7.setTransform(-18.45,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-27.225,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-38.225,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-45.725,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAmQgJgFgFgKQgFgKAAgNIAAAAQAAgNAGgJQAFgKAKgGQAJgFANAAQAJAAAJADQAHADAGAGQAFAHABALIgSAAQgCgIgFgEQgEgDgIAAQgHAAgFADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAGAEAHAAQAHAAAEgCQAFgDADgEQABgEAAgFIgTAAIAAgNIAnAAIAAAIQAAALgFAJQgEAJgKAEQgIAFgNAAQgNAAgLgGg");
	this.shape_11.setTransform(-54.8,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape_12.setTransform(58.875,0.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.7,-10.1,123.4,20.299999999999997);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTA6QgJgDgGgGQgGgHgCgKIARgFQABAJAEAHQADAGAGAEQAGADAGAAQAMAAAGgIQAHgIAAgPQAAgPgJgJQgHgIgNAAQgJAAgGACQgHADgFADIgCgBIAKg8IA7AAIAAAOIg4AAIgHApQAGgGAHgDQAHgEAJAAQALAAAKAFQAJAFAFAIQAFAJAAALQAAAMgGAKQgEAJgKAFQgLAFgNAAQgKAAgIgDg");
	this.shape.setTransform(107.8,1.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgoA9IAAgCIAegiIANgPQAGgJAFgIQAEgJAAgKQAAgKgGgHQgHgGgJgBQgGAAgGADQgGADgFAEQgEAFgDAHIgCAAQACgJAFgHQAFgHAIgFQAIgEAKAAQAPAAAJAJQAJAIABAPQAAAOgIALQgHALgOAMQgMANgSAPIAmAAQAIgBAEgBQAEgCADgDIAFgLIACAAIgFAfg");
	this.shape_1.setTransform(98.225,1.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZA2QgKgIgFgOQgGgOAAgSQAAgQAGgPQAFgOAKgIQALgJAOAAQAPAAALAJQAKAIAFAOQAGAPAAAQQAAASgGAOQgFAOgKAIQgLAJgPAAQgOAAgLgJgAgQgyQgGAGgDAMQgDALAAAPIABAVQACALAEAKQADAJAHAHQAGAGAIAAQAHAAAGgHQAGgGAEgLQADgMAAgPQABgIgCgLQgCgLgEgLQgDgKgGgGQgHgHgIAAQgIAAgGAHg");
	this.shape_2.setTransform(88.125,1.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoA9IAAgCIAegiIANgPQAGgJAFgIQAEgJAAgKQAAgKgGgHQgHgGgJgBQgGAAgGADQgGADgFAEQgEAFgDAHIgCAAQACgJAFgHQAFgHAIgFQAIgEAKAAQAPAAAJAJQAJAIABAPQAAAOgIALQgHALgOAMQgMANgSAPIAmAAQAIgBAEgBQAEgCADgDIAFgLIACAAIgFAfg");
	this.shape_3.setTransform(77.725,1.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_4.setTransform(65.525,2.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_5.setTransform(56.875,3.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfBBIAAgCQAFgCAEgCQADgBAAgHIAAhGIgOAAIAAgFIAPAAIAAgHQAAgLAEgIQAEgGAIgEQAGgEAJAAQAHAAAFACQAHACACAFIgMAJQAAgFgDgEQgEgDgEgBQgIABgDAGQgEAHAAALIAAAKIAZAAIAAAFIgZAAIAABGQABAHADABQAEACAJACIAAACg");
	this.shape_6.setTransform(49.6,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNAtQgHgDgFgEQgGgFgCgGIANgGQACAKAGAGQAHAGAIAAQAIAAAFgFQAGgEAAgIQgBgIgFgEQgFgEgIgDIgPgGQgHgCgGgFQgFgFAAgKQAAgLAIgHQAIgHAOgBQAIAAAGADQAHACAEAEQAFAEACAFIgMAGQgDgIgFgFQgGgGgGAAQgIAAgFAEQgFAFAAAGQAAAHAFAEQAGAEAHADIAPAFQAIADAFAFQAGAGAAAJQAAAJgEAGQgEAHgHADQgIAEgJAAQgIAAgHgDg");
	this.shape_7.setTransform(37.225,3.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_8.setTransform(28.375,3.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSBBIAAgCIAJgEQADgBAAgHIAAg6QAAgFgCgDQgCgCgFAAIgEAAIAAgDIAZgHIACAAIAABOQAAAHAEABIAIAEIAAACgAgHgtQgDgEAAgEQAAgFADgDQAEgDAEAAQAEAAAEADQADADAAAFQAAAEgDAEQgEADgEAAQgEAAgEgDg");
	this.shape_9.setTransform(21.275,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AggA8QgKgGAAgKQAAgGADgEQACgFAEgCQAEgDAFgBQgFgDgCgDQgDgEAAgEQAAgFAEgEQADgEAFgEQgGgEgEgGQgEgHAAgIQAAgJAEgHQAFgHAIgEQAIgFALAAQAIAAAHADIAcAAIAAAFIgTAAQAFAFADAFQADAHAAAHQAAAJgEAHQgFAHgIAEQgIAEgKAAIgKgBQgFgBgEgCIgEAEIgCAFQAAADADADQADADAHABIAbABQANACAIAFQAHAFAAALQAAAJgGAGQgGAHgKADQgLAEgNAAQgSgBgLgFgAgaAeQgDADAAAGQAAAHAEAEQAEAFAHAEQAHACAIAAQAJAAAHgCQAIgCAEgFQAEgEAAgFQABgGgFgEQgEgEgMgBIgZgCIgFgBIgEgBIgFAGgAgPg1QgFAHAAAKQAAANAGAIQAGAHAIAAQAJAAAFgFQAFgHABgKQAAgJgDgHQgDgGgFgEQgFgDgFAAQgJAAgFAGg");
	this.shape_10.setTransform(13.925,4.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_11.setTransform(4.475,3.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgJAyQgGgHAAgLIAAg/IgKAAIAAgCIAWgWIADAAIAAATIAaAAIAAAFIgaAAIAAA+QAAAIADAEQADAEAHABQAFgBACgBIAFgDIABABIgEAFIgGAFQgFACgGAAQgJAAgFgGg");
	this.shape_12.setTransform(-3.125,2.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AANAwIAAgYQgCAHgEAFQgEAGgGADQgGADgHAAQgLAAgHgGQgGgHgBgKQAAgNAKgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgIABgEAEQgFAEgBAGQgBAGADAHIgNAEQgFgJADgJQADgIAKgFQAJgFAMgBQAPABAIAIQAIAJABAPIAAArQAAAEACACQADADAEAAIAEAAIAAADIgZAHgAAAgBQgNACgFAFQgHAGAAAJQAAAIAEAEQAFAFAIAAQAFAAAEgDQAEgDAEgGQAEgGAAgIIAAgQg");
	this.shape_13.setTransform(-10.5,3.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_14.setTransform(-18.925,2.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJAyQgGgHAAgLIAAg/IgKAAIAAgCIAWgWIADAAIAAATIAaAAIAAAFIgaAAIAAA+QAAAIADAEQADAEAHABQAFgBACgBIAFgDIABABIgEAFIgGAFQgFACgGAAQgJAAgFgGg");
	this.shape_15.setTransform(-25.525,2.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNAtQgHgDgFgEQgGgFgCgGIANgGQACAKAGAGQAHAGAIAAQAIAAAFgFQAGgEAAgIQgBgIgFgEQgFgEgIgDIgPgGQgHgCgGgFQgFgFAAgKQAAgLAIgHQAIgHAOgBQAIAAAGADQAHACAEAEQAFAEACAFIgMAGQgDgIgFgFQgGgGgGAAQgIAAgFAEQgFAFAAAGQAAAHAFAEQAGAEAHADIAPAFQAIADAFAFQAGAGAAAJQAAAJgEAGQgEAHgHADQgIAEgJAAQgIAAgHgDg");
	this.shape_16.setTransform(-32.825,3.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgmA7QgJgEgFgIQgFgHAAgKQAAgNAIgJQAHgIAOgEIgIgJQgDgEgCgGQgCgFAAgGQAAgNAIgHQAJgIAOAAQAKAAAGAEQAHADAEAGQADAFAAAHQABAJgIAIQgHAIgNAFIAhAlQAEgHACgKQACgKABgKIAOACQgDALgFAKQgGAKgGAIIAMANQAFAGAEACQAFADAFAAIAAACIgdAAIgNgNQgHAHgJAFQgIAEgKAAQgMAAgIgEgAgkAKQgEAHAAAIQAAAJADAGQADAHAHAEQAGADAJABQAHAAAGgDQAHgDAFgGIgmgrQgHADgEAHgAgXg0QgEAFgBAIQABAJAEAGQAEAHAGAGQAJgEAEgHQADgGAAgIQAAgJgDgGQgFgGgIAAQgGAAgEAFg");
	this.shape_17.setTransform(-47.125,1.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgNAtQgHgDgFgEQgGgFgCgGIANgGQACAKAGAGQAHAGAIAAQAIAAAFgFQAGgEAAgIQgBgIgFgEQgFgEgIgDIgPgGQgHgCgGgFQgFgFAAgKQAAgLAIgHQAIgHAOgBQAIAAAGADQAHACAEAEQAFAEACAFIgMAGQgDgIgFgFQgGgGgGAAQgIAAgFAEQgFAFAAAGQAAAHAFAEQAGAEAHADIAPAFQAIADAFAFQAGAGAAAJQAAAJgEAGQgEAHgHADQgIAEgJAAQgIAAgHgDg");
	this.shape_18.setTransform(-62.025,3.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AATBBIgBgWQgDAKgIAGQgHAGgKAAQgLAAgHgGQgJgGgFgKQgEgKAAgNQAAgRAGgKQAGgLAJgGQAJgGAMAAQAGAAAGAEQAHADADAFIAAgbQABgEgDgCQgDgDgEAAIgEAAIAAgCIAagIIADAAIAABuQAAAEABACQADADAFAAIAEAAIAAADIgZAHgAgSgSQgGAFgDAIQgDAIAAAKQAAAIACAHQABAHADAGQAEAGAEAEQAGADAHABQAGgBAGgEQAHgFACgIIAAgiQAAgGgCgGQgDgGgGgEQgEgEgIgBQgHAAgGAGg");
	this.shape_19.setTransform(-70.95,1.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAKAuIAAgCQAFgBADgCQADgCABgGIAAgyQAAgIgFgFQgEgFgIAAQgFAAgGAEQgHADgGAIIAAA1QAAAGAEACIAIADIAAACIgnAAIAAgCIAIgDQAEgCAAgGIAAg7QAAgFgCgCQgCgCgGgBIgEAAIAAgCIAbgIIACAAIAAAVQAHgKAIgFQAHgFAJgBQAMABAGAHQAHAHgBANIAAAzQABAGADACIAJADIAAACg");
	this.shape_20.setTransform(-81.55,2.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_21.setTransform(-91.625,3.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_22.setTransform(-99.625,2.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgJAyQgGgHAAgLIAAg/IgKAAIAAgCIAWgWIADAAIAAATIAaAAIAAAFIgaAAIAAA+QAAAIADAEQADAEAHABQAFgBACgBIAFgDIABABIgEAFIgGAFQgFACgGAAQgJAAgFgGg");
	this.shape_23.setTransform(-106.225,2.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggA3QgNgIgIgOQgHgNAAgRQAAgSAHgPQAIgPANgIQAOgJASAAQALAAAJAEQAKADAGAGQAHAGADAIIgQAFQgDgMgJgHQgJgIgLAAQgMAAgJAHQgJAHgFANQgGANAAAQQABAPAGAOQAGANAKAIQAKAIANABQAHAAAHgCQAGgDAFgEIAAggQABgHgEgEQgEgDgKgBIAAgCIAyAAIAAACQgJABgDAEQgEAEAAAGIAAAYQgEAGgHAFQgHAFgJADQgKADgKAAQgRAAgNgIg");
	this.shape_24.setTransform(-120.025,1.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgwA8IAAgCIAJgCQAEgBACgDQABgDAAgFIAAhYQAAgHgEgDQgEgCgIAAIAAgDIAyAAQAOAAAKADQALAEAGAHQAGAIAAALQAAAMgGAHQgGAHgLAEQgKADgOAAIgRAAIAAAlQAAAFABADQACADAEABIAIACIAAACgAgPACIAPAAQAPAAAIgHQAIgIAAgNQAAgNgIgHQgIgIgPAAIgPAAg");
	this.shape_25.setTransform(-132.375,1.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZA3QgMgIgHgNQgIgOAAgRQABgSAGgPQAIgPANgIQANgJARAAQARAAALAHQAMAHAEANIgQAFQgDgNgIgHQgIgHgLAAQgLAAgJAHQgIAHgFAMQgFAMgBAQQABAPAGAMQAFAMALAHQAKAGANAAQAOAAAKgHQALgHAEgMIACAAQgEATgNAKQgNALgSAAQgQAAgNgIg");
	this.shape_26.setTransform(-143.85,1.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151.9,-13.9,303.9,27.9);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape.setTransform(128.675,3.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_1.setTransform(120.275,3.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_2.setTransform(110.85,3.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgSBAIAAh/IAlAAIAAB/g");
	this.shape_3.setTransform(98.725,1.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAaBAIgHgYIgqAAIgHAYIgiAAIAph/IAvAAIApB/gAAMAPIgNgxIgPAxIAcAAg");
	this.shape_4.setTransform(88.825,1.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgDgEgHAAQgGAAgEAEQgEAEgBAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFAMAAQANAAAIAIQAJAJAAASIAAA8g");
	this.shape_5.setTransform(72.95,3.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLAAgQIAAgBQABgOAGgLQAHgLALgGQAMgGANAAQAOAAALAFQAKAFAHALQAGAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAJAAADgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgWAAQgNAAgMgFgAASgJQAAgJgFgFQgDgEgJAAQgGAAgEAEQgGAFgBAJIAiAAIAAAAg");
	this.shape_6.setTransform(61.95,3.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOIgGAIQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_7.setTransform(50.525,5.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_8.setTransform(36.1,3.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAPBEIAAg3QAAgIgDgEQgEgDgHAAQgGAAgFAEQgEAEAAAJIAAA1IggAAIAAiHIAgAAIAAA5QAEgIAIgFQAGgFAMAAQAOAAAJAJQAIAIAAARIAAA+g");
	this.shape_9.setTransform(25.1,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_10.setTransform(15.825,2.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgDgEgHAAQgGAAgEAEQgEAEgBAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAHgFALAAQAOAAAIAIQAJAJAAASIAAA8g");
	this.shape_11.setTransform(3.3,3.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_12.setTransform(-4.975,1.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_13.setTransform(-16.55,3.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgYAsQgLgFgGgLQgHgLAAgQIAAgBQABgPAGgLQAHgLALgGQALgFAOAAQALgBAKAEQAKAEAHAJQAHAIABAOIgeAAQgBgGgEgEQgDgDgIAAQgHAAgFAGQgEAGgBALIAAABQABAMAEAHQAFAGAIAAQAHAAAEgEQAEgEABgIIAdAAQAAAMgFAJQgGAJgKAFQgLAEgPAAQgNAAgMgFg");
	this.shape_14.setTransform(-27.15,3.4222);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgEgEQgCgEgIAAQgGAAgEAEQgFAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAGgFANAAQANAAAIAIQAJAJAAASIAAA8g");
	this.shape_15.setTransform(-38.05,3.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgHAAgDACg");
	this.shape_16.setTransform(-49.125,3.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgQAvIgjhdIAjAAIASA7IATg7IAfAAIgjBdg");
	this.shape_17.setTransform(-58.95,3.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLAAgQIAAgBQABgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAeAAQgCAQgMAJQgMAIgWAAQgNAAgMgFgAASgJQAAgJgFgFQgDgEgJAAQgGAAgEAEQgGAFgBAJIAiAAIAAAAg");
	this.shape_18.setTransform(-69.35,3.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_19.setTransform(-77.4,1.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_20.setTransform(-85.4,3.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_21.setTransform(-94.325,3.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AArAwIAAg3QAAgHgEgEQgDgDgGAAQgGAAgEAEQgEAEAAAIIAAA1IgfAAIAAg3QAAgHgDgEQgDgDgGAAQgGAAgEAEQgEAEgBAIIAAA1IgfAAIAAhdIAfAAIAAAOQAFgGAHgFQAIgFALAAQAIAAAGAEQAGADAEAIQAGgIAIgEQAIgEAJABQAJAAAHADQAGAEAFAIQADAIAAAMIAAA8g");
	this.shape_22.setTransform(-110.3,3.3222);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_23.setTransform(-121.325,1.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgHAAgDACg");
	this.shape_24.setTransform(-129.425,3.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_25.setTransform(-137.05,1.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgXAsQgLgFgHgLQgGgLgBgQIAAgBQAAgPAIgLQAGgLAMgGQALgFANAAQALgBAKAEQALAEAGAJQAHAIABAOIgfAAQAAgGgEgEQgEgDgGAAQgIAAgFAGQgFAGABALIAAABQgBAMAFAHQAFAGAIAAQAHAAAEgEQAFgEABgIIAdAAQgBAMgGAJQgFAJgLAFQgKAEgPAAQgNAAgLgFg");
	this.shape_26.setTransform(-144.9,3.4222);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAALAFQALAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_27.setTransform(-155.55,3.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAQBAIgZguIgJAAIAAAuIgkAAIAAh/IAyAAQAYAAAOAKQANAKAAAUIAAABQAAAOgGAIQgGAHgLAEIAfA1gAgSgFIAMAAQAJAAAEgEQAFgEAAgHIAAgBQAAgIgFgDQgFgEgIAAIgMAAg");
	this.shape_28.setTransform(-166.225,1.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175,-14.3,350,28.700000000000003);


// stage content:
(lib.ConsumerProductsDemandbase728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// General_Headline
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(297.45,49.45);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({y:31.5,alpha:1},15,cjs.Ease.cubicInOut).wait(87));

	// General_Subheadline
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(274.35,76);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).to({y:55.35,alpha:1},15,cjs.Ease.cubicInOut).wait(62));

	// CTA
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(646.75,69.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({y:45.85,alpha:1},15,cjs.Ease.cubicInOut).wait(37));

	// Bain_Logo
	this.Bain_Logo__728x90_ = new lib.StackedWhiteRGB();
	this.Bain_Logo__728x90_.name = "Bain_Logo__728x90_";
	this.Bain_Logo__728x90_.setTransform(62.1,45,0.85,0.85);

	this.timeline.addTween(cjs.Tween.get(this.Bain_Logo__728x90_).wait(121));

	// Red_Box
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(8.9,44.9,1.6617,1,0,0,0,-221.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:-220.6,regY:0,scaleX:1,x:9.85,y:45},19,cjs.Ease.cubicInOut).wait(102));

	// Background
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(355.25,47,1.233,1.233);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:1,scaleY:1},120).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(251.7,34.1,571.2,70.9);
// library properties:
lib.properties = {
	id: '81204CA729EA174FAA67E252B24EDF32',
	width: 728,
	height: 90,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"ConsumerProducts_Demandbase_728x90_atlas_1.jpg", id:"ConsumerProducts_Demandbase_728x90_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['81204CA729EA174FAA67E252B24EDF32'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;