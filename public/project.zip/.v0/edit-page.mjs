import fs from "fs"
const f = "app/page.tsx"
let s = fs.readFileSync(f, "utf8")
const rep = (from, to, count) => {
  const n = s.split(from).length - 1
  if (count !== undefined && n !== count) { console.error("MISMATCH", n, "!=", count, JSON.stringify(from)); process.exit(1) }
  if (n === 0) { console.error("NOT FOUND", JSON.stringify(from)); process.exit(1) }
  s = s.split(from).join(to)
}
rep(`// Easing function for smooth animations
const easeOutCubic = (t: number): number => 1 - Math.pow(1 - t, 3)
const easeOutQuart = (t: number): number => 1 - Math.pow(1 - t, 4)
const easeInOutCubic = (t: number): number => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
`, `const hexToRgba = (hex: string, alpha: number) => {
  const h = hex.replace("#", "")
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h
  const n = parseInt(full, 16)
  return \`rgba(\${(n >> 16) & 255},\${(n >> 8) & 255},\${n & 255},\${alpha})\`
}
`, 1)
rep(`const layerProgress = easeOutCubic(`, `const layerProgress = easeStandard(`, 1)
rep(`const redBarProgress = easeOutQuart(`, `const redBarProgress = easeStandard(`, 1)
rep(`const redBlockProgress = easeInOutCubic(`, `const redBlockProgress = easeStandard(`, 1)
for (const v of ["eyebrowProgress", "titleProgress", "subtitleProgress", "ctaProgress", "title2Progress728", "title2Progress", "tf2InProgress"])
  rep(`const ${v} = easeInOutCubic(`, `const ${v} = easeEntrance(`)
for (const v of ["title1OutProgress728", "title1OutProgress", "tf1OutProgress"])
  rep(`const ${v} = easeInOutCubic(`, `const ${v} = easeExit(`)
rep("ctx.fillStyle = `rgba(255,255,255,${alpha})`", "ctx.fillStyle = hexToRgba(ctaArrowColor, alpha)", 1)
s = s.replace(/`rgba\(255,255,255,\$\{([^}]+)\}\)`/g, "txt($1)")
rep("txt(ctaProgress)", "ctaTxt(ctaProgress)", 6)
rep("ctx.fillStyle = `rgba(204, 0, 0, ${eyebrowProgress})`", `ctx.fillStyle = "#CC0000"`, 2)
rep("ctx.fillRect(textX, blockTop, eyebrowMetrics.width + eyebrowPadH * 2, eyebrowBlockH)",
    "ctx.fillRect(textX, blockTop, (eyebrowMetrics.width + eyebrowPadH * 2) * eyebrowWipe, eyebrowBlockH)", 1)
rep("          ctx.measureText(activeEyebrow).width + eyebrowPadH * 2,\n",
    "          (ctx.measureText(activeEyebrow).width + eyebrowPadH * 2) * eyebrowWipe,\n", 1)
rep(`    const ctaProgress = easeEntrance(`, `    const eyebrowWipe = easeStandard(Math.max(0, Math.min(1, (animProgress - eyebrowTiming.start / 100) / Math.max(0.01, (eyebrowTiming.end - eyebrowTiming.start) / 100))))
    const txt = (a: number) => hexToRgba(textColor, a)
    const ctaTxt = (a: number) => hexToRgba(ctaColor, a)
    const ctaProgress = easeEntrance(`, 1)
rep(`    const slideMax = Math.min(width, height) * 0.12\n`, `    const slideMax = TEXT_SLIDE_PX\n`, 1)
rep(`    if (layoutType === "red-bar") {
      const redBarTimingKey`, `    if (!showRedBar) {
      // Red bar / block removed by the user
    } else if (layoutType === "red-bar") {
      const redBarTimingKey`, 1)
rep(`      // Background animation based on selected type
      let animSx`, `      // Background animation based on selected type (camera move: standard curve)
      const bgT = elemTimings[selectedSize].bg || DEFAULT_BG_TIMING
      const bgP = easeStandard(Math.max(0, Math.min(1, (animProgress - bgT.start / 100) / Math.max(0.01, (bgT.end - bgT.start) / 100))))
      let animSx`, 1)
rep(`0.27 * animProgress`, `0.27 * bgP`, 2)
rep(`panAmount * animProgress`, `panAmount * bgP`, 2)
fs.writeFileSync(f, s)
console.log("ok")
