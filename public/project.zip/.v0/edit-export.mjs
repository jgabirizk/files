import fs from "fs"
const f = "lib/export-ads.ts"
let s = fs.readFileSync(f, "utf8")
const rep = (from, to, count) => {
  const n = s.split(from).length - 1
  if (count !== undefined && n !== count) { console.error("MISMATCH", n, "!=", count, JSON.stringify(from)); process.exit(1) }
  if (n === 0) { console.error("NOT FOUND", JSON.stringify(from)); process.exit(1) }
  s = s.split(from).join(to)
}
rep(`import JSZip from "jszip"\n`, `import JSZip from "jszip"\nimport { makeBezier, CURVES, TEXT_SLIDE_PX } from "./motion"\n`, 1)
rep(`  title2?: { start: number; end: number }\n}`, `  title2?: { start: number; end: number }\n  bg?: { start: number; end: number }\n}`, 1)

// Curves: the generated ad uses the same serialised bezier solver as the preview.
rep(`function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
function easeOutQuart(t) { return 1 - Math.pow(1 - t, 4); }
function easeInOutCubic(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }

var slideMax = Math.min(W, H) * 0.12;`, `var makeBezier = \${makeBezier.toString()};
var easeStandard = makeBezier(\${CURVES.standard.join(", ")});
var easeEntrance = makeBezier(\${CURVES.entrance.join(", ")});
var easeExit = makeBezier(\${CURVES.exit.join(", ")});
function clamp01(v) { return Math.max(0, Math.min(1, v)); }
function hexToRgba(hex, a) {
  var h = hex.replace("#", "");
  if (h.length === 3) h = h.split("").map(function(c) { return c + c; }).join("");
  var n = parseInt(h, 16);
  return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")";
}
var TEXT_COLOR = \${JSON.stringify(config.textColor || "#FFFFFF")};
var CTA_COLOR = \${JSON.stringify(config.ctaColor || "#FFFFFF")};
var CTA_ARROW_COLOR = \${JSON.stringify(config.ctaArrowColor || "#FFFFFF")};
var SHOW_RED_BAR = \${config.showRedBar === false ? "false" : "true"};
function txt(a) { return hexToRgba(TEXT_COLOR, a); }
function ctaTxt(a) { return hexToRgba(CTA_COLOR, a); }

var slideMax = \${TEXT_SLIDE_PX};`, 1)
rep(`  ctx.fillStyle = "rgba(255,255,255," + alpha + ")";`, `  ctx.fillStyle = hexToRgba(CTA_ARROW_COLOR, alpha);`, 1)

rep(`var layerProgress = easeOutCubic(`, `var layerProgress = easeStandard(`, 1)
rep(`        var bgProgress = easeOutCubic(progress);`, `        var bgT = timing.bg || { start: 0, end: 27.2 };
        var bgProgress = easeStandard(clamp01((progress - bgT.start / 100) / Math.max(0.01, (bgT.end - bgT.start) / 100)));`, 1)

// The DOM red bar used its own fixed 35% timing and doubled the canvas bar; the canvas bar is the one the preview draws.
rep(`    // Animate red bar via DOM
    var rbProgress = easeOutQuart(Math.max(0, Math.min(1, progress / 0.35)));
    if ("\${size}" === "970x250") {
      redBar.style.height = (H * rbProgress) + "px";
    } else {
      redBar.style.width = (W * rbProgress) + "px";
    }
`, ``, 1)
rep(`var redBar = document.getElementById("red-bar");\n`, ``, 1)
rep(`    <div id="red-bar"></div>\n`, ``, 1)
rep(`    #red-bar{position:absolute;background:#CC0000;\${redBarCss}}\n`, ``, 1)
rep(`  const redBarH = size === "728x90" ? 10 : size === "300x600" ? 20 : Math.min(12, height * 0.05)
  const redBarCss = size === "970x250"
    ? \`right:0;top:0;width:12px;height:0;\`
    : \`bottom:0;left:0;width:\${0};height:\${redBarH}px;\`
`.replace("${0}", "0"), ``, 1)

rep(`    var redBarProgress = easeOutQuart(`, `    var redBarProgress = easeStandard(`, 1)
rep(`    ctx.fillStyle = "#CC0000";
    \${size === "970x250" ? \``, `    ctx.fillStyle = "#CC0000";
    if (SHOW_RED_BAR) {
    \${size === "970x250" ? \``, 1)
rep(`    ctx.fillRect(0, H - rBarH, rBarWidth, rBarH);
    \`}
`, `    ctx.fillRect(0, H - rBarH, rBarWidth, rBarH);
    \`}
    }
`, 1)

for (const v of ["eyebrowProgress", "titleProgress", "subtitleProgress", "ctaProgress", "title2Progress728", "title2ProgressV"])
  rep(`var ${v} = easeInOutCubic(`, `var ${v} = easeEntrance(`)
rep(`var title1OutProgress = easeInOutCubic(`, `var title1OutProgress = easeExit(`, 2)
rep(`    var ctaProgress = easeEntrance(`, `    var eyebrowWipe = easeStandard(clamp01((progress - eyebrowTiming.start / 100) / Math.max(0.01, (eyebrowTiming.end - eyebrowTiming.start) / 100)));
    var ctaProgress = easeEntrance(`, 1)

// Eyebrow highlight: a colour change on one shape wipes, never crossfades.
rep(`ctx.fillStyle = "rgba(204, 0, 0, " + eyebrowProgress + ")";`, `ctx.fillStyle = "#CC0000";`, 2)
rep(`ctx.fillRect(textX, blockTop, eyebrowMetrics.width + eyebrowPadH * 2, eyebrowBlockH);`,
    `ctx.fillRect(textX, blockTop, (eyebrowMetrics.width + eyebrowPadH * 2) * eyebrowWipe, eyebrowBlockH);`, 1)
rep(`ctx.measureText(eyebrow).width + eyebrowPadH * 2, eyebrowBlockH);`,
    `(ctx.measureText(eyebrow).width + eyebrowPadH * 2) * eyebrowWipe, eyebrowBlockH);`, 1)

rep(`"rgba(255,255,255," + ctaProgress + ")"`, `ctaTxt(ctaProgress)`, 4)
s = s.replace(/"rgba\(255,255,255," \+ ([A-Za-z0-9_]+) \+ "\)"/g, "txt($1)")
fs.writeFileSync(f, s)
console.log("ok")
