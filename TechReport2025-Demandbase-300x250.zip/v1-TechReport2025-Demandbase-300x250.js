(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_TechReport2025_Demandbase_300x250_atlas_1", frames: [[0,0,626,522]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v11_TechReport2025_staticlayered_300250 = function() {
	this.initialize(ss["v1_TechReport2025_Demandbase_300x250_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgsAsg/AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAiIgHgPIgYAAIgHAPIgMAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.2,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.425,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQgFgGgBgIQAAgLAOgHQgHgIAAgIQAAgGAGgFQAFgFAIABQAIAAAFADQAGAFgBAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgIAIgKAAQgJAAgHgEgAgIAEQgKAEAAAHQAAALAMAAQAHAAAEgGIgNgRgAgMgRQAAAFAHAGQAKgFAAgHQAAgHgIAAQgJgBAAAJg");
	this.shape_3.setTransform(-47.05,11.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQBAgBAAAtQAAAMgGAKQgHAKgKAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAOAAQAkAAAAgXQAAgYgkAAIgOAAgAgZgMIAHAAQAiAAAAgYQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.575,-4.5761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.9,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBWIAAirIAfAAIAACrg");
	this.shape_6.setTransform(-12.625,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhCIAYArIAXgrIASBCIgNAAIgIgjIgUAkg");
	this.shape_8.setTransform(-20.5,11.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIARAAQAaAAAAAVQgBAKgHAFQgHAEgLAAIgEAAIAAAZgAgIgBIAEAAQANAAAAgKQAAgLgNAAIgEAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIARgbIANAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.725,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgOAKgJQAKgKAOAAQARAAAKAMIAAABIgKAHIAAAAQgGgJgLAAQgIAAgHAGQgGAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIAAABQgKAMgRAAQgPAAgJgJg");
	this.shape_11.setTransform(-37.35,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgKQALgKANAAQAPAAAKAJQAJAKABAOQgBAOgJAKQgLAKgOAAQgNAAgLgJgAgPgPQgGAHAAAIQAAAKAGAHQAHAGAIAAQAJABAHgIQAFgGAAgKQAAgJgFgHQgHgGgJAAQgIAAgHAHg");
	this.shape_12.setTransform(-29.4,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_300250();
	this.instance.setTransform(-152.3,-127,0.4866,0.4866);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.3,-127,304.6,254);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_300250();
	this.instance.setTransform(-152.3,-127,0.4866,0.4866);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.3,-127,304.6,254);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("A3bBLIAAiVMAu3AAAIAACVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-7.5,300,15);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("A3bBLIAAiVMAu3AAAIAACVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-7.5,300,15);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(58.225,1.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.175,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.525,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgFgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQADAHAFADQAGAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgLAAgFAIg");
	this.shape_3.setTransform(27.65,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(18.65,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(10.675,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.575,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.975,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.95,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.725,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.725,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-45.225,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAFAHACALIgUAAQgBgIgEgEQgGgDgHAAQgHAAgFADQgFAEgDAGQgDAHAAAIIAAABQAAAIACAGQADAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQADgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-54.3,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-10.1,122.1,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(58.225,1.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.175,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.525,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgFgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQADAHAFADQAGAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgLAAgFAIg");
	this.shape_3.setTransform(27.65,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(18.65,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(10.675,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.575,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.975,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.95,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.725,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.725,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-45.225,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAFAHACALIgUAAQgBgIgEgEQgGgDgHAAQgHAAgFADQgFAEgDAGQgDAHAAAIIAAABQAAAIACAGQADAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQADgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-54.3,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-10.1,122.1,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIA7QgDgCgBgGQABgEADgDQADgDAEgBQAEABADADQADADAAAEQAAAGgDACQgDAEgEAAQgEAAgDgEgAgDAbQgDgIACgHQACgGADgGIAIgKIAIgLQADgHAAgHQAAgKgFgGQgFgFgJgBQgFABgFAEQgEADgEAHQgDAGAAAHIgQgEQABgHAFgHQAFgGAIgEQAIgEAKAAQAQAAAKAIQAKAGAAAOQAAAIgEAIQgEAGgGAFIgMAJQgGAFgDAGQgDAGAAAHg");
	this.shape.setTransform(-21.625,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAwIgBgVQgHAKgIAGQgGAFgKAAQgMAAgGgHQgHgHAAgOIAAgvQAAgFgCgCQgCgDgFAAIgFAAIAAgCIAagIIADAAIAABCQAAAJAEAFQAFAEAIABQAFAAAGgEQAGgDAHgJIAAgxQAAgFgCgCQgCgDgFAAIgEAAIAAgCIAagIIACAAIAABMQAAAEADACQACADAFAAIAEAAIAAADIgaAHg");
	this.shape_1.setTransform(-30.675,3.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_2.setTransform(-40.925,3.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglA/IgFgBIAFgPIAGAEIAGABQAHgBAFgEQAFgFADgIIAEgIIghhNIgFgIQgCgCgFAAIAAgCIAmAAIAAACQgGABgDACQgCACACAFIAWA6IAYg6QACgFgCgCQgCgCgGgBIAAgCIAaAAIAAACQgFAAgCACQgDADgCAFIgjBWQgGAOgHAHQgHAIgLAAIgGgBg");
	this.shape_3.setTransform(-50.525,5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-64.325,3.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_5.setTransform(-72.325,2.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA9IAAgCQAJgBACgDQACgDgEgIIgJgWIgyAAIgKAWQgDAIABADQACADAKABIAAACIghAAIAAgCQAGgBAEgDQAEgDAEgIIAthoIABAAIAuBoQAEAIAEADQAEADAHABIAAACgAAQARIgWg3IgXA3IAtAAg");
	this.shape_6.setTransform(-82.65,1.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.3,-13.9,182.7,27.9);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIA7QgDgCgBgGQABgEADgDQADgDAEgBQAEABADADQADADAAAEQAAAGgDACQgDAEgEAAQgEAAgDgEgAgDAbQgDgIACgHQACgGADgGIAIgKIAIgLQADgHAAgHQAAgKgFgGQgFgFgJgBQgFABgFAEQgEADgEAHQgDAGAAAHIgQgEQABgHAFgHQAFgGAIgEQAIgEAKAAQAQAAAKAIQAKAGAAAOQAAAIgEAIQgEAGgGAFIgMAJQgGAFgDAGQgDAGAAAHg");
	this.shape.setTransform(-21.625,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAwIgBgVQgHAKgIAGQgGAFgKAAQgMAAgGgHQgHgHAAgOIAAgvQAAgFgCgCQgCgDgFAAIgFAAIAAgCIAagIIADAAIAABCQAAAJAEAFQAFAEAIABQAFAAAGgEQAGgDAHgJIAAgxQAAgFgCgCQgCgDgFAAIgEAAIAAgCIAagIIACAAIAABMQAAAEADACQACADAFAAIAEAAIAAADIgaAHg");
	this.shape_1.setTransform(-30.675,3.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_2.setTransform(-40.925,3.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglA/IgFgBIAFgPIAGAEIAGABQAHgBAFgEQAFgFADgIIAEgIIghhNIgFgIQgCgCgFAAIAAgCIAmAAIAAACQgGABgDACQgCACACAFIAWA6IAYg6QACgFgCgCQgCgCgGgBIAAgCIAaAAIAAACQgFAAgCACQgDADgCAFIgjBWQgGAOgHAHQgHAIgLAAIgGgBg");
	this.shape_3.setTransform(-50.525,5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-64.325,3.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_5.setTransform(-72.325,2.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA9IAAgCQAJgBACgDQACgDgEgIIgJgWIgyAAIgKAWQgDAIABADQACADAKABIAAACIghAAIAAgCQAGgBAEgDQAEgDAEgIIAthoIABAAIAuBoQAEAIAEADQAEADAHABIAAACgAAQARIgWg3IgXA3IAtAAg");
	this.shape_6.setTransform(-82.65,1.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.3,-13.9,182.7,27.9);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAxQgNgGgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCARgOALQgNAJgYAAQgQAAgMgGgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape.setTransform(-45.575,14.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgoA/QgOgLgBgSIAjAAQABAGAEAEQAFAEAJAAQALAAAFgGQAGgGgBgKIAAgQQgCAFgFAEQgEAFgHACQgFADgIAAQgMAAgKgGQgKgGgGgLQgGgKAAgQIAAgCQAAgPAGgMQAGgLAKgGQAKgGAMAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAABeQAAAYgPAMQgPAMgbAAQgaAAgNgKgAgNgnQgGAGAAALIAAACQAAALAGAGQAFAGAJAAQAJAAAGgGQAFgGAAgLIAAgCQAAgLgFgGQgFgGgKAAQgJAAgFAGg");
	this.shape_1.setTransform(-58.225,16.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiBHQgJgHgGgLQgGgMAAgTIAAgBQAAgSAGgLQAGgMAJgGQAKgGANgBQALAAAIAGQAIAEAEAIIAAg9IAkAAIAACWIgkAAIAAgRQgEAIgIAGQgIAFgLAAQgNAAgKgFgAgOABQgFAGAAAOIAAABQAAAOAGAGQAFAHAIAAQAKAAAGgHQAFgGAAgOIAAgCQAAgNgFgGQgFgHgKAAQgKAAgFAHg");
	this.shape_2.setTransform(-71.025,12.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAxQgNgGgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCARgOALQgNAJgYAAQgQAAgMgGgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_3.setTransform(-83.175,14.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_4.setTransform(56.875,-6.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgGgFABgIQgBgIAGgFQAGgGAHAAQAJAAAFAGQAFAFAAAIQAAAIgFAFQgFAFgJAAQgHAAgGgFg");
	this.shape_5.setTransform(49.45,-9.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_6.setTransform(40.525,-6.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAQBLIAAg9QABgIgEgFQgEgDgIAAQgHAAgEAEQgFAFAAAKIAAA6IgkAAIAAiVIAkAAIAAA+QAEgIAIgFQAIgGANAAQAPAAAKAJQAJAKAAATIAABEg");
	this.shape_7.setTransform(28.325,-9.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgYIANAAIAAgXIAjAAIAAAXIAVAAIAAAYIgVAAIAAAqQAAAGADACQACADAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_8.setTransform(17.975,-7.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgoA/QgOgLgBgSIAjAAQABAGAEAEQAFAEAJAAQALAAAFgGQAGgGgBgKIAAgQQgCAFgFAEQgEAFgHACQgFADgIAAQgMAAgKgGQgKgGgGgLQgGgKAAgQIAAgCQAAgPAGgMQAGgLAKgGQAKgGAMAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAABeQAAAYgPAMQgPAMgbAAQgaAAgNgKgAgNgnQgGAGAAALIAAACQAAALAGAGQAFAGAJAAQAJAAAGgGQAFgGAAgLIAAgCQAAgLgFgGQgFgGgKAAQgJAAgFAGg");
	this.shape_9.setTransform(3.625,-5.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQA2IAAg8QABgJgEgEQgEgFgIAAQgHAAgEAFQgFAFAAAKIAAA6IgkAAIAAhoIAkAAIAAARQAEgIAIgGQAIgFANgBQAPAAAKAKQAJAKAAAUIAABDg");
	this.shape_10.setTransform(-8.725,-7.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgGgFAAgIQAAgIAGgFQAFgGAIAAQAIAAAGAGQAFAFABAIQgBAIgFAFQgGAFgIAAQgIAAgFgFg");
	this.shape_11.setTransform(-17.9,-9.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgiBHQgJgHgGgLQgGgMAAgTIAAgBQAAgSAGgLQAGgMAJgGQAKgGANgBQALAAAIAGQAIAEAEAIIAAg9IAkAAIAACWIgkAAIAAgRQgEAIgIAGQgIAFgLAAQgNAAgKgFgAgOAAQgFAHAAAOIAAABQAAANAGAIQAFAGAIAAQAKAAAGgGQAFgIAAgNIAAgCQAAgMgFgIQgFgGgKAAQgKAAgFAGg");
	this.shape_12.setTransform(-27.525,-9.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAQA2IAAg8QABgJgEgEQgEgFgIAAQgHAAgEAFQgFAFAAAKIAAA6IgkAAIAAhoIAkAAIAAARQAEgIAIgGQAIgFANgBQAPAAAKAKQAJAKAAAUIAABDg");
	this.shape_13.setTransform(-39.925,-7.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_14.setTransform(-52.175,-6.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgYIANAAIAAgXIAjAAIAAAXIAVAAIAAAYIgVAAIAAAqQAAAGADACQACADAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_15.setTransform(-62.225,-7.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AARA0IgSgfIgTAfIglAAIAjg0IgggzIApAAIAPAbIAQgbIAlAAIghAwIAkA3g");
	this.shape_16.setTransform(-71.775,-6.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_17.setTransform(-83.175,-6.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_18.setTransform(39.875,-28.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_19.setTransform(29.975,-28.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggA0QgIgDgFgHQgFgIAAgKQABgTAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIABQgGgBgDAEQgEAEAAAEIgiAAQABgMAHgIQAGgIALgFQALgEANAAQAPAAAKAEQALAFAGAIQAGAJAAANIAABEIgjAAIAAgMQgEAFgHAFQgHAEgMAAQgKAAgIgDgAgJAMQgFACAAAHQAAAEADADQADACAGAAQAHAAAFgEQAFgDAAgHIAAgHIgJAAQgKABgFACg");
	this.shape_20.setTransform(19.425,-28.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgiAuQgMgJgBgSIAhAAQABAGADADQAEADAGAAQAHAAADgCQADgCAAgEQAAgEgEgCQgFgCgJgCQgOgCgJgDQgJgEgEgGQgEgGAAgLQAAgMAGgIQAGgHAKgEQAKgEANAAQASAAAMAIQANAHACATIghAAQgBgFgDgDQgDgCgFAAQgGAAgDACQgDACAAADQAAAFAEABIANADQAOACAKADQAJAEAFAGQAFAHAAALQgBATgMAIQgNAJgWAAQgVAAgNgJg");
	this.shape_21.setTransform(4.775,-28.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_22.setTransform(-4.425,-28.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_23.setTransform(-14.925,-28.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgiBGQgJgGgGgLQgGgMAAgSIAAgCQAAgRAGgMQAGgMAJgGQAKgHANAAQALABAIAEQAIAFAEAIIAAg8IAkAAIAACVIgkAAIAAgRQgEAJgIAFQgIAFgLABQgNgBgKgGgAgOAAQgFAHAAAOIAAACQAAAMAGAIQAFAGAIAAQAKAAAGgGQAFgIAAgNIAAgCQAAgNgFgHQgFgFgKgBQgKABgFAFg");
	this.shape_24.setTransform(-27.575,-30.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AggA0QgIgDgFgHQgFgIAAgKQABgTAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIABQgGgBgDAEQgEAEAAAEIgiAAQABgMAHgIQAGgIALgFQALgEANAAQAPAAAKAEQALAFAGAIQAGAJAAANIAABEIgjAAIAAgMQgEAFgHAFQgHAEgMAAQgKAAgIgDgAgJAMQgFACAAAHQAAAEADADQADACAGAAQAHAAAFgEQAFgDAAgHIAAgHIgJAAQgKABgFACg");
	this.shape_25.setTransform(-39.775,-28.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_26.setTransform(-51.375,-28.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_27.setTransform(-60.25,-30.575);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgUBIIAAiPIApAAIAACPg");
	this.shape_28.setTransform(-70.675,-30.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAdBIIgIgbIguAAIgIAbIgmAAIAuiPIA0AAIAtCPgAANARIgPg2IgPA2IAeAAg");
	this.shape_29.setTransform(-81.675,-30.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.1,-47.8,182.3,95.6);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAxQgNgGgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCARgOALQgNAJgYAAQgQAAgMgGgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape.setTransform(-45.575,14.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgoA/QgOgLgBgSIAjAAQABAGAEAEQAFAEAJAAQALAAAFgGQAGgGgBgKIAAgQQgCAFgFAEQgEAFgHACQgFADgIAAQgMAAgKgGQgKgGgGgLQgGgKAAgQIAAgCQAAgPAGgMQAGgLAKgGQAKgGAMAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAABeQAAAYgPAMQgPAMgbAAQgaAAgNgKgAgNgnQgGAGAAALIAAACQAAALAGAGQAFAGAJAAQAJAAAGgGQAFgGAAgLIAAgCQAAgLgFgGQgFgGgKAAQgJAAgFAGg");
	this.shape_1.setTransform(-58.225,16.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiBHQgJgHgGgLQgGgMAAgTIAAgBQAAgSAGgLQAGgMAJgGQAKgGANgBQALAAAIAGQAIAEAEAIIAAg9IAkAAIAACWIgkAAIAAgRQgEAIgIAGQgIAFgLAAQgNAAgKgFgAgOABQgFAGAAAOIAAABQAAAOAGAGQAFAHAIAAQAKAAAGgHQAFgGAAgOIAAgCQAAgNgFgGQgFgHgKAAQgKAAgFAHg");
	this.shape_2.setTransform(-71.025,12.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaAxQgNgGgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCARgOALQgNAJgYAAQgQAAgMgGgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_3.setTransform(-83.175,14.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_4.setTransform(56.875,-6.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgGgFABgIQgBgIAGgFQAGgGAHAAQAJAAAFAGQAFAFAAAIQAAAIgFAFQgFAFgJAAQgHAAgGgFg");
	this.shape_5.setTransform(49.45,-9.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_6.setTransform(40.525,-6.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAQBLIAAg9QABgIgEgFQgEgDgIAAQgHAAgEAEQgFAFAAAKIAAA6IgkAAIAAiVIAkAAIAAA+QAEgIAIgFQAIgGANAAQAPAAAKAJQAJAKAAATIAABEg");
	this.shape_7.setTransform(28.325,-9.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgYIANAAIAAgXIAjAAIAAAXIAVAAIAAAYIgVAAIAAAqQAAAGADACQACADAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_8.setTransform(17.975,-7.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgoA/QgOgLgBgSIAjAAQABAGAEAEQAFAEAJAAQALAAAFgGQAGgGgBgKIAAgQQgCAFgFAEQgEAFgHACQgFADgIAAQgMAAgKgGQgKgGgGgLQgGgKAAgQIAAgCQAAgPAGgMQAGgLAKgGQAKgGAMAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAABeQAAAYgPAMQgPAMgbAAQgaAAgNgKgAgNgnQgGAGAAALIAAACQAAALAGAGQAFAGAJAAQAJAAAGgGQAFgGAAgLIAAgCQAAgLgFgGQgFgGgKAAQgJAAgFAGg");
	this.shape_9.setTransform(3.625,-5.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQA2IAAg8QABgJgEgEQgEgFgIAAQgHAAgEAFQgFAFAAAKIAAA6IgkAAIAAhoIAkAAIAAARQAEgIAIgGQAIgFANgBQAPAAAKAKQAJAKAAAUIAABDg");
	this.shape_10.setTransform(-8.725,-7.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgGgFAAgIQAAgIAGgFQAFgGAIAAQAIAAAGAGQAFAFABAIQgBAIgFAFQgGAFgIAAQgIAAgFgFg");
	this.shape_11.setTransform(-17.9,-9.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgiBHQgJgHgGgLQgGgMAAgTIAAgBQAAgSAGgLQAGgMAJgGQAKgGANgBQALAAAIAGQAIAEAEAIIAAg9IAkAAIAACWIgkAAIAAgRQgEAIgIAGQgIAFgLAAQgNAAgKgFgAgOAAQgFAHAAAOIAAABQAAANAGAIQAFAGAIAAQAKAAAGgGQAFgIAAgNIAAgCQAAgMgFgIQgFgGgKAAQgKAAgFAGg");
	this.shape_12.setTransform(-27.525,-9.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAQA2IAAg8QABgJgEgEQgEgFgIAAQgHAAgEAFQgFAFAAAKIAAA6IgkAAIAAhoIAkAAIAAARQAEgIAIgGQAIgFANgBQAPAAAKAKQAJAKAAAUIAABDg");
	this.shape_13.setTransform(-39.925,-7.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_14.setTransform(-52.175,-6.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgYIANAAIAAgXIAjAAIAAAXIAVAAIAAAYIgVAAIAAAqQAAAGADACQACADAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_15.setTransform(-62.225,-7.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AARA0IgSgfIgTAfIglAAIAjg0IgggzIApAAIAPAbIAQgbIAlAAIghAwIAkA3g");
	this.shape_16.setTransform(-71.775,-6.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgRIAAgBQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAGAIAMQAHANAAASIAAAJIhJAAQABAKAGAGQAGAFAIAAQAJAAAEgDQAFgDAAgGIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJAAQgHAAgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_17.setTransform(-83.175,-6.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_18.setTransform(39.875,-28.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_19.setTransform(29.975,-28.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggA0QgIgDgFgHQgFgIAAgKQABgTAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIABQgGgBgDAEQgEAEAAAEIgiAAQABgMAHgIQAGgIALgFQALgEANAAQAPAAAKAEQALAFAGAIQAGAJAAANIAABEIgjAAIAAgMQgEAFgHAFQgHAEgMAAQgKAAgIgDgAgJAMQgFACAAAHQAAAEADADQADACAGAAQAHAAAFgEQAFgDAAgHIAAgHIgJAAQgKABgFACg");
	this.shape_20.setTransform(19.425,-28.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgiAuQgMgJgBgSIAhAAQABAGADADQAEADAGAAQAHAAADgCQADgCAAgEQAAgEgEgCQgFgCgJgCQgOgCgJgDQgJgEgEgGQgEgGAAgLQAAgMAGgIQAGgHAKgEQAKgEANAAQASAAAMAIQANAHACATIghAAQgBgFgDgDQgDgCgFAAQgGAAgDACQgDACAAADQAAAFAEABIANADQAOACAKADQAJAEAFAGQAFAHAAALQgBATgMAIQgNAJgWAAQgVAAgNgJg");
	this.shape_21.setTransform(4.775,-28.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgiA1IAAhnIAjAAIAAAUQAFgMAIgFQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_22.setTransform(-4.425,-28.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_23.setTransform(-14.925,-28.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgiBGQgJgGgGgLQgGgMAAgSIAAgCQAAgRAGgMQAGgMAJgGQAKgHANAAQALABAIAEQAIAFAEAIIAAg8IAkAAIAACVIgkAAIAAgRQgEAJgIAFQgIAFgLABQgNgBgKgGgAgOAAQgFAHAAAOIAAACQAAAMAGAIQAFAGAIAAQAKAAAGgGQAFgIAAgNIAAgCQAAgNgFgHQgFgFgKgBQgKABgFAFg");
	this.shape_24.setTransform(-27.575,-30.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AggA0QgIgDgFgHQgFgIAAgKQABgTAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIABQgGgBgDAEQgEAEAAAEIgiAAQABgMAHgIQAGgIALgFQALgEANAAQAPAAAKAEQALAFAGAIQAGAJAAANIAABEIgjAAIAAgMQgEAFgHAFQgHAEgMAAQgKAAgIgDgAgJAMQgFACAAAHQAAAEADADQADACAGAAQAHAAAFgEQAFgDAAgHIAAgHIgJAAQgKABgFACg");
	this.shape_25.setTransform(-39.775,-28.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgaAwQgNgGgHgMQgIgLAAgSIAAgBQAAgQAIgMQAHgMANgHQANgHAPAAQAOAAAMAGQAMAGAIAMQAHALAAATIAAAIIhJAAQABALAGAGQAGAFAIAAQAJAAAEgEQAFgCAAgGIAiAAQgCARgOAKQgNAKgYAAQgQAAgMgHgAAUgKQAAgKgFgFQgEgGgJABQgHgBgGAGQgFAFgBAKIAlAAIAAAAg");
	this.shape_26.setTransform(-51.375,-28.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_27.setTransform(-60.25,-30.575);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgUBIIAAiPIApAAIAACPg");
	this.shape_28.setTransform(-70.675,-30.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAdBIIgIgbIguAAIgIAbIgmAAIAuiPIA0AAIAtCPgAANARIgPg2IgPA2IAeAAg");
	this.shape_29.setTransform(-81.675,-30.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.1,-47.8,182.3,95.6);


// stage content:
(lib.v1TechReport2025Demandbase300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(119.1,125.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(119.1,107.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).to({state:[{t:this.instance_1}]},15).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,y:107.4,alpha:1},15,cjs.Ease.cubicInOut).wait(92));

	// SUBTITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(118.85,184.05);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(118.85,146.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},69).to({state:[{t:this.instance_3}]},15).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({_off:true,y:146.7,alpha:1},15,cjs.Ease.cubicInOut).wait(42));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(88.95,226.15);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(88.95,210.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},99).to({state:[{t:this.instance_5}]},15).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({_off:true,y:210.8,alpha:1},15,cjs.Ease.cubicInOut).wait(12));

	// LOGO
	this.Logo__300x250_ = new lib.StackedWhiteRGB();
	this.Logo__300x250_.name = "Logo__300x250_";
	this.Logo__300x250_.setTransform(69.95,38.75,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.Logo__300x250_).wait(126));

	// RED_BAR
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(-256.55,242.5);

	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(150,242.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},14).wait(112));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true,x:150},14,cjs.Ease.cubicInOut).wait(112));

	// BACKGROUND
	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(148.9,124.65,1.2715,1.2717,0,0,0,-0.5,0);

	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(150.3,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},125).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,regX:0,scaleX:1,scaleY:1,x:150.3,y:125},125).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-256.5,88.2,599.8,198);
// library properties:
lib.properties = {
	id: 'AA1C4C5BF152BF458EBFE720CA30E170',
	width: 300,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_TechReport2025_Demandbase_300x250_atlas_1.jpg", id:"v1_TechReport2025_Demandbase_300x250_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AA1C4C5BF152BF458EBFE720CA30E170'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;