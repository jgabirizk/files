(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_TechReport2025_Demandbase_160x600_atlas_1", frames: [[0,0,334,1251]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v11_TechReport2025_staticlayered_160600 = function() {
	this.initialize(ss["v1_TechReport2025_Demandbase_160x600_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgsAsg/AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAiIgHgPIgYAAIgHAPIgMAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.2,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.425,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQgFgGgBgIQAAgLAOgHQgHgIAAgIQAAgGAGgFQAFgFAIABQAIAAAFADQAGAFgBAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgIAIgKAAQgJAAgHgEgAgIAEQgKAEAAAHQAAALAMAAQAHAAAEgGIgNgRgAgMgRQAAAFAHAGQAKgFAAgHQAAgHgIAAQgJgBAAAJg");
	this.shape_3.setTransform(-47.05,11.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQBAgBAAAtQAAAMgGAKQgHAKgKAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAOAAQAkAAAAgXQAAgYgkAAIgOAAgAgZgMIAHAAQAiAAAAgYQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.575,-4.5761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.9,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBWIAAirIAfAAIAACrg");
	this.shape_6.setTransform(-12.625,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhCIAYArIAXgrIASBCIgNAAIgIgjIgUAkg");
	this.shape_8.setTransform(-20.5,11.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIARAAQAaAAAAAVQgBAKgHAFQgHAEgLAAIgEAAIAAAZgAgIgBIAEAAQANAAAAgKQAAgLgNAAIgEAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIARgbIANAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.725,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgOAKgJQAKgKAOAAQARAAAKAMIAAABIgKAHIAAAAQgGgJgLAAQgIAAgHAGQgGAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIAAABQgKAMgRAAQgPAAgJgJg");
	this.shape_11.setTransform(-37.35,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgKQALgKANAAQAPAAAKAJQAJAKABAOQgBAOgJAKQgLAKgOAAQgNAAgLgJgAgPgPQgGAHAAAIQAAAKAGAHQAHAGAIAAQAJABAHgIQAFgGAAgKQAAgJgFgHQgHgGgJAAQgIAAgHAHg");
	this.shape_12.setTransform(-29.4,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_160600();
	this.instance.setTransform(-82,-307.1,0.491,0.491);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82,-307.1,164,614.3);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v11_TechReport2025_staticlayered_160600();
	this.instance.setTransform(-82,-307.1,0.491,0.491);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82,-307.1,164,614.3);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AsfAyIAAhjIY/AAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-5,160,10);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AsfAyIAAhjIY/AAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-5,160,10);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(45.225,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(37.575,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWAmQgLgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAGgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgJAGgOAAQgNAAgJgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQAEAHAFADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_2.setTransform(27.7,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAJAHQAIAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAADgDQAFgEAAgGIAAgBQAAgGgFgDQgDgDgGAAIgKAAg");
	this.shape_3.setTransform(18.7,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(10.725,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(2.625,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-8.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIghAAIAAAjIgTAAIAAhVIATAAIAAAkIAhAAIAAgkIAUAAIAABVg");
	this.shape_7.setTransform(-17.9,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-26.675,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-37.675,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-45.175,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAmQgJgFgFgKQgFgKAAgNIAAAAQAAgNAGgJQAFgKAKgGQAKgFAMAAQAJAAAJADQAHADAGAGQAFAHABALIgTAAQgBgIgFgEQgEgDgIAAQgHAAgFADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAFADQAGAEAHAAQAHAAAEgCQAFgDACgEQACgEAAgFIgTAAIAAgNIAnAAIAAAIQAAALgFAJQgEAJgKAEQgIAFgNAAQgNAAgLgGg");
	this.shape_11.setTransform(-54.25,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgfgrIA/ArIg/Asg");
	this.shape_12.setTransform(57.775,1.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.9,-10.1,121.9,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(45.225,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(37.575,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWAmQgLgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAGgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgJAGgOAAQgNAAgJgGgAgRgUQgGAHAAANIAAAAQAAAJADAGQAEAHAFADQAFAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgKAAgHAIg");
	this.shape_2.setTransform(27.7,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAJAHQAIAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAADgDQAFgEAAgGIAAgBQAAgGgFgDQgDgDgGAAIgKAAg");
	this.shape_3.setTransform(18.7,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(10.725,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(2.625,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-8.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIghAAIAAAjIgTAAIAAhVIATAAIAAAkIAhAAIAAgkIAUAAIAABVg");
	this.shape_7.setTransform(-17.9,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-26.675,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-37.675,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-45.175,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAmQgJgFgFgKQgFgKAAgNIAAAAQAAgNAGgJQAFgKAKgGQAKgFAMAAQAJAAAJADQAHADAGAGQAFAHABALIgTAAQgBgIgFgEQgEgDgIAAQgHAAgFADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAFADQAGAEAHAAQAHAAAEgCQAFgDACgEQACgEAAgFIgTAAIAAgNIAnAAIAAAIQAAALgFAJQgEAJgKAEQgIAFgNAAQgNAAgLgGg");
	this.shape_11.setTransform(-54.25,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgfgrIA/ArIg/Asg");
	this.shape_12.setTransform(57.775,1.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.9,-10.1,121.9,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIA7QgDgCgBgGQABgEADgDQADgDAEgBQAEABADADQADADAAAEQAAAGgDACQgDAEgEAAQgEAAgDgEgAgDAbQgDgIACgHQACgGADgGIAIgKIAIgLQADgHAAgHQAAgKgFgGQgFgFgJgBQgFABgFAEQgEADgEAHQgDAGAAAHIgQgEQABgHAFgHQAFgGAIgEQAIgEAKAAQAQAAAKAIQAKAGAAAOQAAAIgEAIQgEAGgGAFIgMAJQgGAFgDAGQgDAGAAAHg");
	this.shape.setTransform(31.725,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAwIgBgVQgHAKgIAGQgGAFgKAAQgMAAgGgHQgHgHAAgOIAAgvQAAgFgCgCQgCgDgFAAIgFAAIAAgCIAagIIADAAIAABCQAAAJAEAFQAFAEAIABQAFAAAGgEQAGgDAHgJIAAgxQAAgFgCgCQgCgDgFAAIgEAAIAAgCIAagIIACAAIAABMQAAAEADACQACADAFAAIAEAAIAAADIgaAHg");
	this.shape_1.setTransform(22.675,3.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALQAAAHABAIIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_2.setTransform(12.425,3.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglA/IgFgBIAFgPIAGAEIAGABQAHgBAFgEQAFgFADgIIAEgIIghhNIgFgIQgCgCgFAAIAAgCIAmAAIAAACQgGABgDACQgCACACAFIAWA6IAYg6QACgFgCgCQgCgCgGgBIAAgCIAaAAIAAACQgFAAgCACQgDADgCAFIgjBWQgGAOgHAHQgHAIgLAAIgGgBg");
	this.shape_3.setTransform(2.825,5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-10.975,3.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_5.setTransform(-18.975,2.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA9IAAgCQAJgBACgDQACgDgEgIIgJgWIgzAAIgJAWQgDAIABADQACADAKABIAAACIghAAIAAgCQAHgBAEgDQADgDAEgIIAthoIABAAIAuBoQAEAIAEADQAEADAHABIAAACgAARARIgXg3IgXA3IAuAAg");
	this.shape_6.setTransform(-29.3,1.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38,-13.9,76,27.9);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIA7QgDgCgBgGQABgEADgDQADgDAEgBQAEABADADQADADAAAEQAAAGgDACQgDAEgEAAQgEAAgDgEgAgDAbQgDgIACgHQACgGADgGIAIgKIAIgLQADgHAAgHQAAgKgFgGQgFgFgJgBQgFABgFAEQgEADgEAHQgDAGAAAHIgQgEQABgHAFgHQAFgGAIgEQAIgEAKAAQAQAAAKAIQAKAGAAAOQAAAIgEAIQgEAGgGAFIgMAJQgGAFgDAGQgDAGAAAHg");
	this.shape.setTransform(31.725,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAwIgBgVQgHAKgIAGQgGAFgKAAQgMAAgGgHQgHgHAAgOIAAgvQAAgFgCgCQgCgDgFAAIgFAAIAAgCIAagIIADAAIAABCQAAAJAEAFQAFAEAIABQAFAAAGgEQAGgDAHgJIAAgxQAAgFgCgCQgCgDgFAAIgEAAIAAgCIAagIIACAAIAABMQAAAEADACQACADAFAAIAEAAIAAADIgaAHg");
	this.shape_1.setTransform(22.675,3.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALQAAAHABAIIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_2.setTransform(12.425,3.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglA/IgFgBIAFgPIAGAEIAGABQAHgBAFgEQAFgFADgIIAEgIIghhNIgFgIQgCgCgFAAIAAgCIAmAAIAAACQgGABgDACQgCACACAFIAWA6IAYg6QACgFgCgCQgCgCgGgBIAAgCIAaAAIAAACQgFAAgCACQgDADgCAFIgjBWQgGAOgHAHQgHAIgLAAIgGgBg");
	this.shape_3.setTransform(2.825,5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-10.975,3.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAuIAAgCIAJgDQAEgCAAgGIAAg7QAAgFgCgCQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAaQADgMAHgHQAHgGAIgBIADABIAEABIgBAPIgEgCIgGAAQgGAAgGADQgGAEgDAJIAAAwQAAAGADACQAEACAJABIAAACg");
	this.shape_5.setTransform(-18.975,2.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA9IAAgCQAJgBACgDQACgDgEgIIgJgWIgzAAIgJAWQgDAIABADQACADAKABIAAACIghAAIAAgCQAHgBAEgDQADgDAEgIIAthoIABAAIAuBoQAEAIAEADQAEADAHABIAAACgAARARIgXg3IgXA3IAuAAg");
	this.shape_6.setTransform(-29.3,1.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38,-13.9,76,27.9);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape.setTransform(22.15,14.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOQgCAEgEAEQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_1.setTransform(10.725,16.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgFgLgBgQIAAgCQABgQAFgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAIAAQAIAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgFgGgIAAQgJAAgEAFg");
	this.shape_2.setTransform(-0.8,12.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_3.setTransform(-11.7,14.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_4.setTransform(-24.275,14.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_5.setTransform(-30.975,12.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAALAFQALAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_6.setTransform(-39,14.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAPBEIAAg3QAAgIgEgEQgDgDgHAAQgGAAgEAEQgFAEAAAJIAAA1IggAAIAAiHIAgAAIAAA5QAEgIAIgFQAHgFAMAAQANAAAIAJQAJAIAAARIAAA+g");
	this.shape_7.setTransform(-50,12.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_8.setTransform(-59.275,13.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOIgGAIQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_9.setTransform(20.775,-6.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgDgEQgDgEgIAAQgGAAgEAEQgFAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAGgFANAAQANAAAJAIQAIAJAAASIAAA8g");
	this.shape_10.setTransform(9.65,-8.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_11.setTransform(1.375,-10.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgGgLABgQIAAgCQgBgQAGgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAHAAQAJAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgEgGgKAAQgHAAgFAFg");
	this.shape_12.setTransform(-7.3,-9.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgDgEQgDgEgIAAQgGAAgFAEQgEAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAGgFAMAAQAOAAAJAIQAIAJAAASIAAA8g");
	this.shape_13.setTransform(-18.45,-8.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGANAAQANAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAIAAAEgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgKgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_14.setTransform(-29.45,-7.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_15.setTransform(-38.475,-8.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAOAvIgPgcIgRAcIghAAIAfgvIgdguIAlAAIAOAYIAOgYIAhAAIgeArIAhAyg");
	this.shape_16.setTransform(-47.05,-7.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGAOAAQAMAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAfAAQgDAQgMAJQgMAIgVAAQgPAAgKgFgAASgJQgBgJgDgFQgEgEgIAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_17.setTransform(-57.25,-7.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLAAgQIAAgBQABgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAeAAQgCAQgMAJQgMAIgWAAQgNAAgMgFgAASgJQAAgJgFgFQgDgEgJAAQgGAAgEAEQgGAFgBAJIAiAAIAAAAg");
	this.shape_18.setTransform(53.5,-30.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_19.setTransform(44.575,-30.625);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape_20.setTransform(35.075,-30.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAAAxQgTAAgLgIQgLgIgBgQIAeAAQAAAGADACQADADAGAAQAGAAADgCQADgCAAgEQAAgDgEgCIgNgDQgMgCgIgDQgIgEgEgFQgEgGAAgJQAAgLAGgHQAFgHAJgDQAKgDALAAQAQgBALAHQALAHACARIgdAAQgBgFgDgCQgDgCgEAAQgFAAgDACQgDACAAADQAAADAEACIALADQANABAJAEQAIADAFAFQAEAGAAAKQAAARgMAIQgKAHgSAAIgDAAg");
	this.shape_21.setTransform(21.925,-30.5752);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_22.setTransform(13.625,-30.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_23.setTransform(4.2,-30.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgFgLAAgQIAAgCQAAgQAFgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAIAAQAIAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgFgGgIAAQgJAAgEAFg");
	this.shape_24.setTransform(-7.2,-32.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgHAAgDACg");
	this.shape_25.setTransform(-18.175,-30.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgGgLgBgQIAAgBQAAgOAHgLQAHgLALgGQAMgGAOAAQANAAALAFQAKAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAJAAADgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgMgFgAASgJQAAgJgFgFQgEgEgHAAQgHAAgEAEQgGAFAAAJIAhAAIAAAAg");
	this.shape_26.setTransform(-28.6,-30.575);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_27.setTransform(-36.65,-32.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSBAIAAh/IAlAAIAAB/g");
	this.shape_28.setTransform(-46.025,-32.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAaBAIgHgYIgqAAIgHAYIgiAAIAph/IAvAAIApB/gAAMAPIgNgxIgPAxIAcAAg");
	this.shape_29.setTransform(-55.925,-32.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.6,-48.3,129.3,96.6);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape.setTransform(22.15,14.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOQgCAEgEAEQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_1.setTransform(10.725,16.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgFgLgBgQIAAgCQABgQAFgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAIAAQAIAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgFgGgIAAQgJAAgEAFg");
	this.shape_2.setTransform(-0.8,12.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLgBgQIAAgBQAAgOAIgLQAGgLAMgGQALgGAOAAQANAAAKAFQALAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgLgFgAASgJQgBgJgEgFQgEgEgHAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_3.setTransform(-11.7,14.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_4.setTransform(-24.275,14.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_5.setTransform(-30.975,12.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAALAFQALAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_6.setTransform(-39,14.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAPBEIAAg3QAAgIgEgEQgDgDgHAAQgGAAgEAEQgFAEAAAJIAAA1IggAAIAAiHIAgAAIAAA5QAEgIAIgFQAHgFAMAAQANAAAIAJQAJAIAAARIAAA+g");
	this.shape_7.setTransform(-50,12.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_8.setTransform(-59.275,13.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgkA4QgMgJgCgQIAgAAQABAFAEADQAEAEAIAAQAKAAAFgGQAEgFAAgJIAAgOIgGAIQgEAEgGADQgFACgHAAQgLAAgJgFQgJgFgFgKQgGgKAAgOIAAgCQAAgNAGgLQAFgKAJgFQAJgGALAAQAKAAAHAEQAHAFAEAHIAAgNIAhAAIAABVQgBAVgNALQgNALgZAAQgXgBgMgJgAgMgjQgFAGAAAKIAAABQAAAKAFAGQAFAEAIAAQAIAAAFgEQAFgGAAgKIAAgCQAAgJgFgGQgEgGgJAAQgIAAgFAGg");
	this.shape_9.setTransform(20.775,-6.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgDgEQgDgEgIAAQgGAAgEAEQgFAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAGgFANAAQANAAAJAIQAIAJAAASIAAA8g");
	this.shape_10.setTransform(9.65,-8.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPBEIAAhdIAfAAIAABdgAgMgnQgFgEAAgHQAAgIAFgEQAFgFAHAAQAHAAAFAFQAFAEABAIQgBAHgFAEQgFAFgHAAQgHAAgFgFg");
	this.shape_11.setTransform(1.375,-10.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgGgLABgQIAAgCQgBgQAGgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAHAAQAJAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgEgGgKAAQgHAAgFAFg");
	this.shape_12.setTransform(-7.3,-9.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPAwIAAg2QAAgHgDgEQgDgEgIAAQgGAAgFAEQgEAEAAAKIAAAzIggAAIAAhdIAgAAIAAAPQAEgHAIgFQAGgFAMAAQAOAAAJAIQAIAJAAASIAAA8g");
	this.shape_13.setTransform(-18.45,-8.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGANAAQANAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAIAAAEgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgKgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_14.setTransform(-29.45,-7.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgKAyQgJgIAAgQIAAgpIgLAAIAAgWIALAAIAAgUIAfAAIAAAUIATAAIAAAWIgTAAIAAAlQAAAGADACQACACAFAAIAFAAIAEgBIAAAYIgIACIgKABQgPAAgIgIg");
	this.shape_15.setTransform(-38.475,-8.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAOAvIgPgcIgRAcIghAAIAfgvIgdguIAlAAIAOAYIAOgYIAhAAIgeArIAhAyg");
	this.shape_16.setTransform(-47.05,-7.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAsQgMgGgHgKQgGgLAAgQIAAgBQgBgOAIgLQAGgLAMgGQALgGAOAAQAMAAALAFQALAFAGALQAHAKABARIAAAIIhCAAQABAJAFAFQAFAFAIAAQAHAAAEgDQAEgDABgFIAfAAQgDAQgMAJQgMAIgVAAQgPAAgKgFgAASgJQgBgJgDgFQgEgEgIAAQgHAAgFAEQgEAFgBAJIAhAAIAAAAg");
	this.shape_17.setTransform(-57.25,-7.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLAAgQIAAgBQABgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAeAAQgCAQgMAJQgMAIgWAAQgNAAgMgFgAASgJQAAgJgFgFQgDgEgJAAQgGAAgEAEQgGAFgBAJIAiAAIAAAAg");
	this.shape_18.setTransform(53.5,-30.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_19.setTransform(44.575,-30.625);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgGAAgEACg");
	this.shape_20.setTransform(35.075,-30.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAAAxQgTAAgLgIQgLgIgBgQIAeAAQAAAGADACQADADAGAAQAGAAADgCQADgCAAgEQAAgDgEgCIgNgDQgMgCgIgDQgIgEgEgFQgEgGAAgJQAAgLAGgHQAFgHAJgDQAKgDALAAQAQgBALAHQALAHACARIgdAAQgBgFgDgCQgDgCgEAAQgFAAgDACQgDACAAADQAAADAEACIALADQANABAJAEQAIADAFAFQAEAGAAAKQAAARgMAIQgKAHgSAAIgDAAg");
	this.shape_21.setTransform(21.925,-30.5752);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgeAwIAAhdIAfAAIAAASQAEgKAIgFQAIgFAKAAIAAAeQgOAAgIAFQgIAFAAAKIAAAtg");
	this.shape_22.setTransform(13.625,-30.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgHgLABgQIAAgBQAAgOAGgLQAHgLALgGQAMgGANAAQANAAAMAFQAKAFAHALQAGAKABARIAAAIIhCAAQABAJAFAFQAFAFAHAAQAIAAAFgDQADgDABgFIAfAAQgDAQgMAJQgMAIgWAAQgOAAgLgFgAASgJQAAgJgEgFQgFgEgIAAQgGAAgFAEQgEAFgCAJIAiAAIAAAAg");
	this.shape_23.setTransform(4.2,-30.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgeBAQgJgGgFgKQgFgLAAgQIAAgCQAAgQAFgKQAFgLAJgFQAJgGALAAQALAAAGAEQAIAFADAHIAAg3IAgAAIAACHIggAAIAAgQQgEAIgHAFQgHAFgKAAQgLAAgJgFgAgMAAQgFAHAAAMIAAABQAAAMAFAGQAFAGAIAAQAIAAAFgGQAFgGAAgMIAAgBQAAgMgFgGQgFgGgIAAQgJAAgEAFg");
	this.shape_24.setTransform(-7.2,-32.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgdAvQgHgDgEgHQgFgGAAgKQABgQANgGQANgIAWAAIAJAAIAAgCQABgHgDgEQgCgEgIAAQgGAAgCAEQgDADgBAEIgeAAQABgLAGgHQAFgIAKgEQAKgDAMAAQANAAAKADQAJAEAFAIQAFAIABAMIAAA8IggAAIAAgLQgDAGgHADQgGAEgLAAQgIAAgIgCgAgIALQgFACAAAGQAAAEADACQADADAFAAQAGAAAFgEQAEgEAAgGIAAgFIgIAAIgDAAQgHAAgDACg");
	this.shape_25.setTransform(-18.175,-30.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgYAsQgLgGgHgKQgGgLgBgQIAAgBQAAgOAHgLQAHgLALgGQAMgGAOAAQANAAALAFQAKAFAGALQAHAKAAARIAAAIIhBAAQABAJAFAFQAFAFAHAAQAJAAADgDQAEgDABgFIAeAAQgCAQgMAJQgMAIgVAAQgOAAgMgFgAASgJQAAgJgFgFQgEgEgHAAQgHAAgEAEQgGAFAAAJIAhAAIAAAAg");
	this.shape_26.setTransform(-28.6,-30.575);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgPBEIAAiHIAfAAIAACHg");
	this.shape_27.setTransform(-36.65,-32.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSBAIAAh/IAlAAIAAB/g");
	this.shape_28.setTransform(-46.025,-32.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAaBAIgHgYIgqAAIgHAYIgiAAIAph/IAvAAIApB/gAAMAPIgNgxIgPAxIAcAAg");
	this.shape_29.setTransform(-55.925,-32.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.6,-48.3,129.3,96.6);


// stage content:
(lib.v1TechReport2025Demandbase160x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(82.6,224.85);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(82.6,140.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).to({state:[{t:this.instance_1}]},15).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({_off:true,y:140.85,alpha:1},15,cjs.Ease.cubicInOut).wait(92));

	// SUBTITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(56.5,228.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(56.5,183.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},69).to({state:[{t:this.instance_3}]},15).wait(42));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({_off:true,y:183.1,alpha:1},15,cjs.Ease.cubicInOut).wait(42));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(78.5,250.7);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(78.5,217.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},99).to({state:[{t:this.instance_5}]},15).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(99).to({_off:false},0).to({_off:true,y:217.7,alpha:1},15,cjs.Ease.cubicInOut).wait(12));

	// LOGO
	this.Logo__160x600_ = new lib.StackedWhiteRGB();
	this.Logo__160x600_.name = "Logo__160x600_";
	this.Logo__160x600_.setTransform(80.05,35.85,1.2,1.2);

	this.timeline.addTween(cjs.Tween.get(this.Logo__160x600_).wait(126));

	// RED_BAR
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(-145,595);

	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(80,595);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},14).wait(112));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true,x:80},14,cjs.Ease.cubicInOut).wait(112));

	// BACKGROUND
	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(79.35,303.15,1.2195,1.2195,0,0,0,-0.1,-0.1);

	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(80,304.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},125).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:80,y:304.1},125).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-145,228.8,324.5,449.09999999999997);
// library properties:
lib.properties = {
	id: '05C45FA0E18BEE478C2FCC3EB34FE658',
	width: 160,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_TechReport2025_Demandbase_160x600_atlas_1.jpg", id:"v1_TechReport2025_Demandbase_160x600_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['05C45FA0E18BEE478C2FCC3EB34FE658'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;