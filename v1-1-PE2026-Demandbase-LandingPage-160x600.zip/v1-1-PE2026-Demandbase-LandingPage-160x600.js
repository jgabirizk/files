(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1", frames: [[0,0,297,611],[299,0,297,611],[598,0,296,611]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.fore = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.mount = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.sky = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.8)","rgba(0,0,0,0.239)","rgba(0,0,0,0)"],[0,0.878,1],0,-237.4,0,237.4).s().p("EgMfAlGMAAAhKLIY/AAMAAABKLg");
	this.shape.setTransform(80,237.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(0,0,160,474.8), null);


(lib.Tween21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.sky();
	this.instance.setTransform(-148,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148,-305.5,296,611);


(lib.Tween20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.sky();
	this.instance.setTransform(-148,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148,-305.5,296,611);


(lib.Tween19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mount();
	this.instance.setTransform(-148.5,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-305.5,297,611);


(lib.Tween18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.mount();
	this.instance.setTransform(-148.5,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-305.5,297,611);


(lib.Tween17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.fore();
	this.instance.setTransform(-148.5,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-305.5,297,611);


(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.fore();
	this.instance.setTransform(-148.5,-305.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-148.5,-305.5,297,611);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("AsfAyIAAhjIY/AAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-5,160,10);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("AsfAyIAAhjIY/AAIAABjg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-5,160,10);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiACAQg1g1AAhLQAAhKA1g1QA1g1BLAAQAQAAANACIgPAUIgOgBQg+AAgtAsQgtAsAAA+QAAA8AtAsQAtAsA+AAQBAAAAsgsQAtgsAAg8QAAgvgcgnQgaglgrgRIgGgYQA6AQAkAwQAmAwAAA9QAABLg1A1Qg2A1hLAAQhLAAg1g1gAg8gTIBbh3IAhCTg");
	this.shape.setTransform(41.85,-0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAoIgIgRIgdAAIgIARIgPAAIAmhQIAnBQgAAKALIgKgWIgJAWIATAAg");
	this.shape_1.setTransform(-7.45,14);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSgGIAAAuIgOAAIAAhQIAzAvIAAguIAOAAIAABQg");
	this.shape_2.setTransform(1.7,14.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAjQgHgGAAgJQAAgOAQgIQgJgLAAgIQAAgJAHgFQAGgGALAAQAIAAAHAFQAGAGAAAIQAAANgSAJIAOAOIAIgMIAMAAIgOAUIAPASIgPAAIgHgJQgJALgNAAQgLAAgHgHgAgSAKQgEAEAAAEQAAANAPAAQAJAAAEgHIgQgUQgFACgDAEgAgPgVQAAAGAJAIQANgIAAgHQAAgJgKAAQgMAAAAAKg");
	this.shape_3.setTransform(-56.475,14.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBoIAAjPIAyAAQBNAAAAA2QAAAPgIALQgHALgNAGQAoAMAAAmQAAAdgVAPQgVAQgmAAgAgeBIIARAAQArAAAAgcQAAgQgMgGQgKgGgVAAIgRAAgAgegPIAIAAQAWAAAJgGQAKgHAAgPQAAgPgLgHQgJgGgWAAIgHAAg");
	this.shape_4.setTransform(-52.325,-5.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA6BqIgTgtIhPAAIgUAtIgoAAIBkjTIBlDTgAAYAbIgYg6IgZA6IAxAAg");
	this.shape_5.setTransform(-32.3,-5.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTBoIAAjPIAnAAIAADPg");
	this.shape_6.setTransform(-15.175,-5.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxgSIAAB5IgmAAIAAjSICIB9IAAh6IAnAAIAADUg");
	this.shape_7.setTransform(4.55,-5.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYgDIgKArIgOAAIAThRIAdA1IAcg1IAVBRIgPAAIgKgrIgYAsg");
	this.shape_8.setTransform(-24.625,14.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAoIAAhPIATAAQAgAAAAAZQAAAMgJAGQgJAGgOAAIgEAAIAAAegAgKgBIAEAAQAQAAAAgNQAAgNgQAAIgEAAg");
	this.shape_9.setTransform(-14.575,14.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAoIAAgiIgegtIARAAIATAgIAUggIARAAIgeAtIAAAig");
	this.shape_10.setTransform(10.45,14.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAeQgMgMAAgSQAAgRAMgMQAMgLARAAQATAAAMAPIABAAIgLAKIgBgBQgFgLgPAAQgKAAgIAIQgIAIABALQAAAMAGAIQAIAIALAAQAOAAAGgMIABgBIALAKIgBABQgLAPgUAAQgSAAgLgLg");
	this.shape_11.setTransform(-44.85,14.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcAeQgMgMAAgSQAAgQAMgNQALgMARAAQASAAALAMQAMAMABARQgBASgMAMQgLAMgSAAQgRAAgLgMgAgSgTQgHAJAAAKQAAAMAHAIQAHAIALAAQAMAAAHgIQAHgIAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAJg");
	this.shape_12.setTransform(-35.3,14.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(45.725,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(38.075,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQADAHAFADQAGAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgLAAgFAIg");
	this.shape_2.setTransform(28.2,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_3.setTransform(19.2,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(11.225,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(3.125,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-8.425,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_7.setTransform(-17.4,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-26.175,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-37.175,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-44.675,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHABALIgTAAQgCgIgEgEQgFgDgIAAQgHAAgFADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgJAEQgKAFgNAAQgMAAgKgGg");
	this.shape_11.setTransform(-53.75,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape_12.setTransform(57.875,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(45.725,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(38.075,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQADAHAFADQAGAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgLAAgFAIg");
	this.shape_2.setTransform(28.2,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_3.setTransform(19.2,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(11.225,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(3.125,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-8.425,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_7.setTransform(-17.4,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-26.175,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-37.175,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-44.675,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHABALIgTAAQgCgIgEgEQgFgDgIAAQgHAAgFADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgJAEQgKAFgNAAQgMAAgKgGg");
	this.shape_11.setTransform(-53.75,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape_12.setTransform(57.875,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcA3QgMgHgFgOQgGgNAAgSIAAgDQABgTAHgOQAHgOAMgHQAMgHAPgBQAVAAALAKQAMAIACASIggAAQgBgEgDgDQgDgDgGAAQgJAAgFAJQgGAIAAAPQAEgGAHgEQAFgEALAAQALAAAKAFQAJAEAFAJQAFAHABANQgBANgFAKQgGAJgLAFQgMAGgPAAQgSAAgMgIgAgJAIQgFAFAAAHQAAAIAFAFQAEAFAHAAQAHAAAEgFQAFgFAAgIQAAgHgFgFQgEgFgHAAQgHAAgEAFg");
	this.shape.setTransform(39.375,23.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgwA+IAAgFIArgtQAIgKAFgHQAGgIAAgIQAAgGgEgEQgDgDgGAAQgGgBgEAFQgEAFgBAKIggAAQACgWAMgMQANgMAVAAQAPABALAEQAKAFAFAJQAFAJAAALQAAAMgGAKQgHAKgKAJIgRARIApAAIAAAag");
	this.shape_1.setTransform(28.225,23.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdA4QgNgHgGgOQgHgNAAgTIAAgFQAAgTAHgNQAIgOAMgGQANgHAPgBQAQAAANAHQAMAHAIANQAHANAAAUIAAAEQAAATgHAOQgHANgNAIQgMAHgRAAQgRAAgMgHgAgPgbQgFAIAAARIAAAEQAAARAFAJQAFAIAKAAQALAAAFgJQAFgIAAgRIAAgEQAAgQgFgJQgFgIgLAAQgKAAgFAIg");
	this.shape_2.setTransform(17.025,23.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgwA+IAAgFIArgtQAIgKAFgHQAGgIAAgIQAAgGgEgEQgDgDgGAAQgGgBgEAFQgEAFgBAKIggAAQACgWAMgMQANgMAVAAQAPABALAEQAKAFAFAJQAFAJAAALQAAAMgGAKQgHAKgKAJIgRARIApAAIAAAag");
	this.shape_3.setTransform(5.475,23.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_4.setTransform(-6.325,24.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAtIAAhYIAdAAIAAASQAEgKAHgEQAHgFAKAAIAAAcQgOAAgGAFQgIAEAAAKIAAAqg");
	this.shape_5.setTransform(-13.1,25.4477);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYApQgLgFgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAOABALAFQALAGAGAKQAHAKAAAOIAAABQAAAOgHAKQgGALgLAFQgLAGgOAAQgNAAgLgGgAgMgRQgEAGAAALIAAABQAAALAEAGQAEAGAIAAQAJAAAEgGQAFgGAAgLIAAgBQAAgLgFgGQgEgGgJAAQgHAAgFAGg");
	this.shape_6.setTransform(-22.225,25.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgvA9IAAh2IAfAAIAAAOQADgIAHgDQAGgFAKgBQALABAIAFQAJAFAEAKQAGALAAAPIAAABQAAAOgGAKQgEALgJAFQgIAFgLAAQgKAAgGgEQgHgFgDgGIAAArgAgNgfQgFAGABALIAAACQgBALAFAFQAFAGAIAAQAIAAAEgGQAFgFAAgLIAAgBQAAgMgFgGQgFgFgHAAQgIAAgFAFg");
	this.shape_7.setTransform(-32.75,26.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWAqQgLgGgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAMAAAKAFQAKAFAGAKQAHAKAAAQIAAAHIg+AAQABAJAFAFQAFAFAHAAQAHAAAEgDQADgDABgFIAdAAQgCAPgMAJQgLAIgUAAQgNAAgLgFgAARgJQAAgIgEgEQgEgEgHAAQgGAAgFAEQgEAEgBAIIAfAAIAAAAg");
	this.shape_8.setTransform(-43.525,25.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAPA9IgXgsIgIAAIAAAsIgjAAIAAh5IAwAAQAXAAAMAKQANAKAAATIAAAAQAAANgGAIQgGAHgKADIAdAzgAgQgEIALAAQAIAAAEgEQAEgEAAgHIAAgBQAAgHgEgDQgFgEgHAAIgLAAg");
	this.shape_9.setTransform(-53.625,23.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbA7IAPgmIgkhPIAhAAIARAvIARgvIAeAAIgwB1g");
	this.shape_10.setTransform(51.575,4.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_11.setTransform(43.125,2.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOBBIAAhYIAdAAIAABYgAgLglQgFgDAAgIQAAgGAFgFQAFgEAGgBQAHABAFAEQAEAFABAGQgBAIgEADQgFAFgHAAQgGAAgFgFg");
	this.shape_12.setTransform(37.475,1.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAqQgHgDgDgIQgEgHAAgMIAAg4IAeAAIAAA0QAAAHADAEQADAEAHgBQAGAAAEgDQAEgFAAgJIAAgxIAeAAIAABYIgeAAIAAgOQgEAHgHAEQgFAEgLABQgJgBgHgDg");
	this.shape_13.setTransform(29.625,3.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AARA8IAAgrQgDAHgHAFQgHAEgJAAQgLAAgIgFQgJgFgFgKQgFgKAAgPIAAgBQAAgPAFgLQAFgKAJgFQAIgFALAAQAJAAAHAEQAHAEADAHIAAgNIAfAAIAAB1gAgLgfQgFAGAAAMIAAABQAAAMAFAEQAEAGAHAAQAJAAAEgGQAFgEAAgMIAAgCQAAgKgEgHQgFgFgIgBQgIABgEAFg");
	this.shape_14.setTransform(18.675,4.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqA9IAAh5IBSAAIAAAbIgvAAIAAAVIAmAAIAAAYIgmAAIAAAWIAyAAIAAAbg");
	this.shape_15.setTransform(8.55,1.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAqQgLgGgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAMAAAKAFQAKAFAGAKQAHAKAAAQIAAAHIg+AAQABAJAFAFQAFAFAHAAQAHAAAEgDQADgDABgFIAdAAQgCAPgMAJQgLAIgUAAQgNAAgLgFgAARgJQAAgIgEgEQgEgEgHAAQgGAAgFAEQgEAEgBAIIAfAAIAAAAg");
	this.shape_16.setTransform(-5.375,3.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_17.setTransform(-13.875,2.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgbAsQgHgDgEgGQgEgFAAgKQAAgPAMgGQANgHAVAAIAJAAIAAgCQAAgHgCgDQgDgEgHAAQgFAAgDADQgCADgBAEIgdAAQABgKAGgHQAFgIAJgDQAJgEAMAAQAMAAAJAEQAJADAFAIQAFAHAAAMIAAA5IgdAAIAAgLQgDAFgHAEQgFAEgLAAQgIAAgHgDgAgIAKQgEADAAAFQAAAEACACQADACAFAAQAGAAAEgDQAFgEAAgFIAAgGIgIAAQgJAAgEACg");
	this.shape_18.setTransform(-22.15,3.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgQAtIgghYIAgAAIASA4IASg4IAdAAIggBYg");
	this.shape_19.setTransform(-31.55,3.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgOBBIAAhYIAdAAIAABYgAgLglQgFgDAAgIQAAgGAFgFQAFgEAGgBQAHABAFAEQAEAFABAGQgBAIgEADQgFAFgHAAQgGAAgFgFg");
	this.shape_20.setTransform(-39.075,1.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgcAtIAAhYIAdAAIAAASQAEgKAHgEQAHgFAKAAIAAAcQgOAAgGAFQgIAEAAAKIAAAqg");
	this.shape_21.setTransform(-45.05,3.1977);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgvA9IAAh5IAvAAQAYAAAMALQAMAKgBAUIAAAAQAAATgMAKQgMAKgXAAIgMAAIAAApgAgMgDIAKAAQAIAAAEgEQAEgEAAgHIAAgBQAAgIgEgDQgEgEgIAAIgKAAg");
	this.shape_22.setTransform(-54.099,1.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgOBAIAAh/IAdAAIAAB/g");
	this.shape_23.setTransform(-7.75,-20.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgbAsQgHgDgEgGQgEgFAAgKQAAgPAMgGQANgHAVAAIAJAAIAAgCQAAgHgCgDQgDgEgHAAQgFAAgDADQgCADgBAEIgdAAQABgKAGgHQAFgIAJgDQAJgEAMAAQAMAAAJAEQAJADAFAIQAFAHAAAMIAAA5IgdAAIAAgLQgDAFgHAEQgFAEgLAAQgIAAgHgDgAgIAKQgEADAAAFQAAAEACACQADACAFAAQAGAAAEgDQAFgEAAgFIAAgGIgIAAQgJAAgEACg");
	this.shape_24.setTransform(-15.4,-19.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgGA9QgHgFgDgHIAAAOIgfAAIAAh/IAfAAIAAA0QADgGAHgFQAGgEAKAAQAKgBAJAGQAIAFAGAKQAFAKAAAPIAAABQAAAQgFAKQgGAKgIAFQgJAFgKAAQgKAAgGgEgAgNABQgFAFABAMIAAABQgBAMAFAFQAFAGAIAAQAIAAAEgGQAFgGAAgLIAAgBQgBgMgEgFQgFgGgHAAQgIAAgFAGg");
	this.shape_25.setTransform(-25.35,-20.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgYApQgLgFgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAOABALAFQALAGAGAKQAHAKAAAOIAAABQAAAOgHAKQgGALgLAFQgLAGgOAAQgNAAgLgGgAgMgRQgEAGAAALIAAABQAAALAEAGQAEAGAIAAQAJAAAEgGQAFgGAAgLIAAgBQAAgLgFgGQgEgGgJAAQgHAAgFAGg");
	this.shape_26.setTransform(-36.325,-19.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgOBAIAAh/IAdAAIAAB/g");
	this.shape_27.setTransform(-44.1,-20.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AggA3QgOgIgIgOQgGgOgBgSIAAgBQABgSAHgOQAJgOAPgIQAOgIARAAQAOAAANAFQAMAFAIAJQAIAKACAQIgjAAQgBgIgGgFQgFgEgKAAQgMAAgHAJQgHAJgBAQIAAABQABAKADAIQACAIAHAFQAFAEAKAAQAJAAAEgCQAGgDACgEQADgEAAgFIgWAAIAAgXIA4AAIAAAOQAAAPgGAMQgHANgNAHQgOAHgTAAQgUAAgOgIg");
	this.shape_28.setTransform(-53.3,-20.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-35.8,124.1,71.69999999999999);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcA3QgMgHgFgOQgGgNAAgSIAAgDQABgTAHgOQAHgOAMgHQAMgHAPgBQAVAAALAKQAMAIACASIggAAQgBgEgDgDQgDgDgGAAQgJAAgFAJQgGAIAAAPQAEgGAHgEQAFgEALAAQALAAAKAFQAJAEAFAJQAFAHABANQgBANgFAKQgGAJgLAFQgMAGgPAAQgSAAgMgIgAgJAIQgFAFAAAHQAAAIAFAFQAEAFAHAAQAHAAAEgFQAFgFAAgIQAAgHgFgFQgEgFgHAAQgHAAgEAFg");
	this.shape.setTransform(39.375,23.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgwA+IAAgFIArgtQAIgKAFgHQAGgIAAgIQAAgGgEgEQgDgDgGAAQgGgBgEAFQgEAFgBAKIggAAQACgWAMgMQANgMAVAAQAPABALAEQAKAFAFAJQAFAJAAALQAAAMgGAKQgHAKgKAJIgRARIApAAIAAAag");
	this.shape_1.setTransform(28.225,23.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdA4QgNgHgGgOQgHgNAAgTIAAgFQAAgTAHgNQAIgOAMgGQANgHAPgBQAQAAANAHQAMAHAIANQAHANAAAUIAAAEQAAATgHAOQgHANgNAIQgMAHgRAAQgRAAgMgHgAgPgbQgFAIAAARIAAAEQAAARAFAJQAFAIAKAAQALAAAFgJQAFgIAAgRIAAgEQAAgQgFgJQgFgIgLAAQgKAAgFAIg");
	this.shape_2.setTransform(17.025,23.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgwA+IAAgFIArgtQAIgKAFgHQAGgIAAgIQAAgGgEgEQgDgDgGAAQgGgBgEAFQgEAFgBAKIggAAQACgWAMgMQANgMAVAAQAPABALAEQAKAFAFAJQAFAJAAALQAAAMgGAKQgHAKgKAJIgRARIApAAIAAAag");
	this.shape_3.setTransform(5.475,23.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_4.setTransform(-6.325,24.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAtIAAhYIAdAAIAAASQAEgKAHgEQAHgFAKAAIAAAcQgOAAgGAFQgIAEAAAKIAAAqg");
	this.shape_5.setTransform(-13.1,25.4477);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYApQgLgFgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAOABALAFQALAGAGAKQAHAKAAAOIAAABQAAAOgHAKQgGALgLAFQgLAGgOAAQgNAAgLgGgAgMgRQgEAGAAALIAAABQAAALAEAGQAEAGAIAAQAJAAAEgGQAFgGAAgLIAAgBQAAgLgFgGQgEgGgJAAQgHAAgFAGg");
	this.shape_6.setTransform(-22.225,25.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgvA9IAAh2IAfAAIAAAOQADgIAHgDQAGgFAKgBQALABAIAFQAJAFAEAKQAGALAAAPIAAABQAAAOgGAKQgEALgJAFQgIAFgLAAQgKAAgGgEQgHgFgDgGIAAArgAgNgfQgFAGABALIAAACQgBALAFAFQAFAGAIAAQAIAAAEgGQAFgFAAgLIAAgBQAAgMgFgGQgFgFgHAAQgIAAgFAFg");
	this.shape_7.setTransform(-32.75,26.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWAqQgLgGgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAMAAAKAFQAKAFAGAKQAHAKAAAQIAAAHIg+AAQABAJAFAFQAFAFAHAAQAHAAAEgDQADgDABgFIAdAAQgCAPgMAJQgLAIgUAAQgNAAgLgFgAARgJQAAgIgEgEQgEgEgHAAQgGAAgFAEQgEAEgBAIIAfAAIAAAAg");
	this.shape_8.setTransform(-43.525,25.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAPA9IgXgsIgIAAIAAAsIgjAAIAAh5IAwAAQAXAAAMAKQANAKAAATIAAAAQAAANgGAIQgGAHgKADIAdAzgAgQgEIALAAQAIAAAEgEQAEgEAAgHIAAgBQAAgHgEgDQgFgEgHAAIgLAAg");
	this.shape_9.setTransform(-53.625,23.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbA7IAPgmIgkhPIAhAAIARAvIARgvIAeAAIgwB1g");
	this.shape_10.setTransform(51.575,4.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_11.setTransform(43.125,2.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOBBIAAhYIAdAAIAABYgAgLglQgFgDAAgIQAAgGAFgFQAFgEAGgBQAHABAFAEQAEAFABAGQgBAIgEADQgFAFgHAAQgGAAgFgFg");
	this.shape_12.setTransform(37.475,1.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAqQgHgDgDgIQgEgHAAgMIAAg4IAeAAIAAA0QAAAHADAEQADAEAHgBQAGAAAEgDQAEgFAAgJIAAgxIAeAAIAABYIgeAAIAAgOQgEAHgHAEQgFAEgLABQgJgBgHgDg");
	this.shape_13.setTransform(29.625,3.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AARA8IAAgrQgDAHgHAFQgHAEgJAAQgLAAgIgFQgJgFgFgKQgFgKAAgPIAAgBQAAgPAFgLQAFgKAJgFQAIgFALAAQAJAAAHAEQAHAEADAHIAAgNIAfAAIAAB1gAgLgfQgFAGAAAMIAAABQAAAMAFAEQAEAGAHAAQAJAAAEgGQAFgEAAgMIAAgCQAAgKgEgHQgFgFgIgBQgIABgEAFg");
	this.shape_14.setTransform(18.675,4.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqA9IAAh5IBSAAIAAAbIgvAAIAAAVIAmAAIAAAYIgmAAIAAAWIAyAAIAAAbg");
	this.shape_15.setTransform(8.55,1.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAqQgLgGgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAMAAAKAFQAKAFAGAKQAHAKAAAQIAAAHIg+AAQABAJAFAFQAFAFAHAAQAHAAAEgDQADgDABgFIAdAAQgCAPgMAJQgLAIgUAAQgNAAgLgFgAARgJQAAgIgEgEQgEgEgHAAQgGAAgFAEQgEAEgBAIIAfAAIAAAAg");
	this.shape_16.setTransform(-5.375,3.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKAvQgIgHAAgQIAAgmIgKAAIAAgVIAKAAIAAgTIAeAAIAAATIARAAIAAAVIgRAAIAAAjQAAAFACACQACADAFAAIAEgBIAEgBIAAAXIgHACIgJABQgPAAgIgIg");
	this.shape_17.setTransform(-13.875,2.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgbAsQgHgDgEgGQgEgFAAgKQAAgPAMgGQANgHAVAAIAJAAIAAgCQAAgHgCgDQgDgEgHAAQgFAAgDADQgCADgBAEIgdAAQABgKAGgHQAFgIAJgDQAJgEAMAAQAMAAAJAEQAJADAFAIQAFAHAAAMIAAA5IgdAAIAAgLQgDAFgHAEQgFAEgLAAQgIAAgHgDgAgIAKQgEADAAAFQAAAEACACQADACAFAAQAGAAAEgDQAFgEAAgFIAAgGIgIAAQgJAAgEACg");
	this.shape_18.setTransform(-22.15,3.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgQAtIgghYIAgAAIASA4IASg4IAdAAIggBYg");
	this.shape_19.setTransform(-31.55,3.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgOBBIAAhYIAdAAIAABYgAgLglQgFgDAAgIQAAgGAFgFQAFgEAGgBQAHABAFAEQAEAFABAGQgBAIgEADQgFAFgHAAQgGAAgFgFg");
	this.shape_20.setTransform(-39.075,1.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgcAtIAAhYIAdAAIAAASQAEgKAHgEQAHgFAKAAIAAAcQgOAAgGAFQgIAEAAAKIAAAqg");
	this.shape_21.setTransform(-45.05,3.1977);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgvA9IAAh5IAvAAQAYAAAMALQAMAKgBAUIAAAAQAAATgMAKQgMAKgXAAIgMAAIAAApgAgMgDIAKAAQAIAAAEgEQAEgEAAgHIAAgBQAAgIgEgDQgEgEgIAAIgKAAg");
	this.shape_22.setTransform(-54.099,1.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgOBAIAAh/IAdAAIAAB/g");
	this.shape_23.setTransform(-7.75,-20.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgbAsQgHgDgEgGQgEgFAAgKQAAgPAMgGQANgHAVAAIAJAAIAAgCQAAgHgCgDQgDgEgHAAQgFAAgDADQgCADgBAEIgdAAQABgKAGgHQAFgIAJgDQAJgEAMAAQAMAAAJAEQAJADAFAIQAFAHAAAMIAAA5IgdAAIAAgLQgDAFgHAEQgFAEgLAAQgIAAgHgDgAgIAKQgEADAAAFQAAAEACACQADACAFAAQAGAAAEgDQAFgEAAgFIAAgGIgIAAQgJAAgEACg");
	this.shape_24.setTransform(-15.4,-19.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgGA9QgHgFgDgHIAAAOIgfAAIAAh/IAfAAIAAA0QADgGAHgFQAGgEAKAAQAKgBAJAGQAIAFAGAKQAFAKAAAPIAAABQAAAQgFAKQgGAKgIAFQgJAFgKAAQgKAAgGgEgAgNABQgFAFABAMIAAABQgBAMAFAFQAFAGAIAAQAIAAAEgGQAFgGAAgLIAAgBQgBgMgEgFQgFgGgHAAQgIAAgFAGg");
	this.shape_25.setTransform(-25.35,-20.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgYApQgLgFgGgKQgGgKgBgPIAAgBQABgNAGgLQAGgKALgGQALgFANgBQAOABALAFQALAGAGAKQAHAKAAAOIAAABQAAAOgHAKQgGALgLAFQgLAGgOAAQgNAAgLgGgAgMgRQgEAGAAALIAAABQAAALAEAGQAEAGAIAAQAJAAAEgGQAFgGAAgLIAAgBQAAgLgFgGQgEgGgJAAQgHAAgFAGg");
	this.shape_26.setTransform(-36.325,-19.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgOBAIAAh/IAdAAIAAB/g");
	this.shape_27.setTransform(-44.1,-20.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AggA3QgOgIgIgOQgGgOgBgSIAAgBQABgSAHgOQAJgOAPgIQAOgIARAAQAOAAANAFQAMAFAIAJQAIAKACAQIgjAAQgBgIgGgFQgFgEgKAAQgMAAgHAJQgHAJgBAQIAAABQABAKADAIQACAIAHAFQAFAEAKAAQAJAAAEgCQAGgDACgEQADgEAAgFIgWAAIAAgXIA4AAIAAAOQAAAPgGAMQgHANgNAHQgOAHgTAAQgUAAgOgIg");
	this.shape_28.setTransform(-53.3,-20.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-35.8,124.1,71.69999999999999);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape.setTransform(10.725,22.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAsIAAgDQAFAAADgDQAEgCAAgFIAAg3QAAgEgDgDQgCgBgEgBIgEAAIAAgCIAcgIIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBARIgFgCIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJAAIAAADg");
	this.shape_1.setTransform(2.575,22.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgFgKABgMQAAgNAEgLQAGgKAJgGQAJgGAMAAQALAAAHAEQAIAFAEAJQADAIAAALIg4AAIAAABIAAACQgBAKAEAIQAEAJAHAEQAGAEAKAAQAJAAAGgEQAGgEAEgGIABABQgCAIgEAGQgEAGgIAEQgHADgKAAQgMAAgIgGgAATgMQABgHgDgGQgCgGgEgEQgEgEgGgBQgEAAgFAEQgEAEgDAGQgDAGgBAIIAmAAIAAAAg");
	this.shape_2.setTransform(-5.45,22.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgCgEgBIAAgCIAnAAIAAACQgGABgCACQgDACACAFIAVAzIAQgpIgEgKQgCgFgDgCQgCgCgFgBIAAgCIAmAAIAAACQgGABgCACQgCACABAFIAVAzIAUgzQACgEgCgDQgCgCgFgBIAAgCIAXAAIAAACQgEAAgCACQgCADgCAFIggBLg");
	this.shape_3.setTransform(-20.825,22.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgEgKgBgMQAAgNAGgLQAFgKAJgGQAJgGAMAAQALAAAIAEQAHAFAEAJQADAIAAALIg4AAIAAABIAAACQAAAKADAIQAEAJAHAEQAHAEAJAAQAJAAAGgEQAGgEADgGIACABQgCAIgEAGQgFAGgHAEQgHADgKAAQgMAAgIgGgAATgMQAAgHgCgGQgCgGgEgEQgEgEgGgBQgFAAgEAEQgFAEgCAGQgDAGgBAIIAmAAIAAAAg");
	this.shape_4.setTransform(-32.25,22.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAJAsIAAgDQAEAAADgDQADgCAAgFIAAgvQAAgHgEgEQgDgEgIgBQgFABgFACQgEADgGAHIAAAyQAAAFACACQADADAFAAIAAADIgmAAIAAgDQAFAAADgDQADgCAAgFIAAg3QgBgEgCgDQgCgBgEgBIgEAAIAAgCIAcgIIACAAIAAATQAGgJAHgFQAHgFAIAAQAMAAAGAHQAGAHAAANIAAAvQAAAFADACQADADAFAAIAAADg");
	this.shape_5.setTransform(-41.65,22.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape_6.setTransform(-54.975,22.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAJAsIAAgCQAEgBADgDQADgCAAgFIAAgvQAAgHgEgEQgDgFgIAAQgEAAgFADQgFADgGAHIAAAyQAAAFADACQACADAFABIAAACIgmAAIAAgCQAEgBADgDQAEgCAAgFIAAg3QgBgEgCgCQgCgDgEAAIgEAAIAAgDIAbgHIADAAIAAATQAHgJAGgFQAHgFAIAAQAMAAAGAHQAGAHAAAMIAAAwQAAAFADACQADADAFABIAAACg");
	this.shape_7.setTransform(16.75,2.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRA+IAAgCQAEgBADgCQAEgCAAgGIAAg3QgBgEgCgCQgCgCgEgBIgEAAIAAgCIAagIIADAAIAABKQAAAGACACQADACAFABIAAACgAgHgpQgEgEAAgFQAAgFAEgDQADgDAFAAQAFAAAEADQADADAAAFQAAAFgDAEQgEADgFAAQgFAAgDgDg");
	this.shape_8.setTransform(9.1,0.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAQA9IAAgTQgEAJgHAFQgGAGgJgBQgLAAgHgFQgIgGgFgJQgDgKAAgMQgBgQAGgJQAFgLAJgFQAJgGAKAAQAGAAAHADQAFACAEAFIAAgXQAAgEgDgDQgCgCgEAAIgEAAIAAgDIAbgHIADAAIAABmQAAAEACADQADACAEAAIAEAAIAAADIgbAHgAgQgRQgFAEgDAJQgCAGAAALQgBAJADAJQADAIAFAGQAFAFAIAAQAFAAAGgDQAFgFADgGIAAggQAAgHgDgGQgCgFgEgFQgGgDgGAAQgGAAgFAFg");
	this.shape_9.setTransform(-1.95,1.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgDQAEgCAAgFIAAg3QAAgEgDgCQgCgDgEAAIgEAAIAAgDIAcgHIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBAQIgFgBIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJABIAAACg");
	this.shape_10.setTransform(-10.525,2.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape_11.setTransform(-18.275,2.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgCgEgBIAAgCIAnAAIAAACQgGABgCACQgDACACAFIAVAyIAQgoIgEgKQgCgFgDgCQgCgCgFgBIAAgCIAmAAIAAACQgGABgCACQgCACABAFIAVAyIAUgyQACgEgCgDQgCgCgFgBIAAgCIAXAAIAAACQgEAAgCACQgCADgCAFIggBLg");
	this.shape_12.setTransform(-30.075,3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgDQAEgCAAgFIAAg3QAAgEgDgCQgCgDgEAAIgEAAIAAgDIAcgHIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBAQIgFgBIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJABIAAACg");
	this.shape_13.setTransform(-40.375,2.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAoQgJgGgFgKQgFgJAAgNQAAgNAFgLQAFgKAKgGQAJgGAMAAQAMAAAJAFQAJAGAFAJQAFAKAAANQAAANgFALQgFAKgKAGQgJAGgMAAQgMAAgJgFgAgMgjQgFAEgDAIQgCAIAAAKIABAPQACAJADAGQADAHAFAEQAFAEAFAAQAHAAAFgEQAEgFADgHQACgIAAgLIgBgPQgCgIgDgGQgDgHgFgEQgFgFgFAAQgHAAgEAFg");
	this.shape_14.setTransform(-48.775,2.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AggA9IAAgCQAGAAADgDQADgCAAgGIAAhDIgOAAIAAgEIAOAAIAAgGQAAgKAFgIQAEgGAIgEQAHgEAIABQAIAAAGABQAGADADAGIgOAJQgBgHgCgDQgDgFgFAAQgFAAgDAEQgCADgBAFQgBAGAAAGIAAAJIAWAAIAAAEIgWAAIAABDQAAAGACACQAEADAIAAIAAACg");
	this.shape_15.setTransform(-55.85,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgfA5QgKgGAAgJQAAgGADgDQACgEAEgDQAEgDAEAAQgEgDgDgEQgCgDAAgEQAAgFAEgEQACgEAHgDQgHgDgEgHQgEgGAAgIQAAgJAEgHQAEgGAJgEQAIgEAKAAQAHAAAIADIAaAAIAAAEIgSAAQAFAEADAGQAEAFAAAIQgBAIgEAHQgFAGgHAEQgIAEgKAAIgJgBIgJgDIgEAEIgBAEQAAADADACQADADAGABIAaACQAMAAAIAGQAHAFAAAKQAAAJgGAGQgGAGgKAEQgLADgMAAQgRAAgLgFgAgZAdQgCADAAAEQABAHADAFQAEAFAGACQAIADAHAAQAIAAAHgDQAGgBAEgEQAEgEAAgEQAAgGgEgDQgEgEgLgBIgXgCIgFgBIgEgBIgFAFgAgNgyQgEAGAAAKQAAAMAFAIQAFAHAHAAQAHAAAFgGQAEgFABgLQgBgIgCgGQgCgGgEgEQgFgDgEAAQgHAAgFAGg");
	this.shape_16.setTransform(9.85,-15.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAIAsIAAgCQAFgBADgCQADgDAAgFIAAgvQAAgHgEgEQgEgFgGABQgGAAgEACQgGADgGAGIAAAzQABAFADADQADACAEABIAAACIgmAAIAAgCQAEgBADgCQADgDABgFIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgDIAbgHIACAAIAAATQAHgJAHgFQAHgFAIAAQAMAAAGAHQAGAHAAAMIAAAwQABAFACADQADACAFABIAAACg");
	this.shape_17.setTransform(0.35,-16.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgRA+IAAgCQAEgBADgCQADgCABgGIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgCIAagIIACAAIAABKQABAGADACQADACAEABIAAACgAgHgpQgDgEgBgFQABgFADgDQAEgDAEAAQAFAAADADQAEADAAAFQAAAFgEAEQgDADgFAAQgEAAgEgDg");
	this.shape_18.setTransform(-7.3,-18.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgCQAEgDAAgFIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgDIAcgHIACAAIAAAYQADgMAHgGQAGgGAIAAIADAAIAEACIgBAPIgFgCIgFAAQgGAAgGADQgFAFgDAHIAAAsQAAAFADADQADACAJABIAAACg");
	this.shape_19.setTransform(-13.125,-16.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgFgKAAgMQABgNAFgLQAFgKAJgGQAKgGALAAQALAAAHAEQAIAFADAJQAFAIAAALIg5AAIgBABIAAACQABAKADAIQAEAJAHAEQAHAEAJAAQAJAAAGgEQAGgEADgGIADABQgCAIgFAGQgEAGgIAEQgHADgJAAQgMAAgJgGgAAUgMQAAgHgDgGQgCgGgEgEQgEgEgGgBQgFAAgEAEQgFAEgCAGQgDAGgBAIIAnAAIAAAAg");
	this.shape_20.setTransform(-21.15,-16.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgDgEAAIAAgCIAnAAIAAACQgGAAgCADQgDACACAFIAVAyIAQgnIgEgLQgCgFgDgCQgCgDgFAAIAAgCIAmAAIAAACQgGAAgCADQgCACABAFIAVAyIAUgyQACgEgCgDQgCgDgFAAIAAgCIAXAAIAAACQgEABgCACQgCACgCAFIggBLg");
	this.shape_21.setTransform(-32.575,-16.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgVAoQgJgGgFgKQgFgJAAgNQAAgNAFgLQAFgKAKgGQAJgGAMAAQAMAAAJAFQAJAGAFAJQAFAKAAANQAAANgFALQgFAKgKAGQgJAGgMAAQgMAAgJgFgAgMgjQgFAEgDAIQgCAIAAAKIABAPQACAJADAGQADAHAFAEQAFAEAFAAQAHAAAFgEQAEgFADgHQACgIAAgLIgBgPQgCgIgDgGQgDgHgFgEQgFgFgFAAQgHAAgEAFg");
	this.shape_22.setTransform(-44.375,-16.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgvA5IAAgDQAJAAADgDQAEgCAAgHIAAhTQAAgHgEgCQgDgDgJAAIAAgDIAyAAQANAAAKAEQAKADAGAHQAFAHABALQgBALgFAHQgGAGgKADQgKAEgNAAIgQAAIAAAjQABAHADACQAEADAGAAIAAADgAgNACIANAAQAOAAAHgGQAHgIAAgMQAAgMgHgIQgIgHgNAAIgNAAg");
	this.shape_23.setTransform(-54.45,-18.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.8,-32.9,123.6,65.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape.setTransform(10.725,22.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAsIAAgDQAFAAADgDQAEgCAAgFIAAg3QAAgEgDgDQgCgBgEgBIgEAAIAAgCIAcgIIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBARIgFgCIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJAAIAAADg");
	this.shape_1.setTransform(2.575,22.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgFgKABgMQAAgNAEgLQAGgKAJgGQAJgGAMAAQALAAAHAEQAIAFAEAJQADAIAAALIg4AAIAAABIAAACQgBAKAEAIQAEAJAHAEQAGAEAKAAQAJAAAGgEQAGgEAEgGIABABQgCAIgEAGQgEAGgIAEQgHADgKAAQgMAAgIgGgAATgMQABgHgDgGQgCgGgEgEQgEgEgGgBQgEAAgFAEQgEAEgDAGQgDAGgBAIIAmAAIAAAAg");
	this.shape_2.setTransform(-5.45,22.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgCgEgBIAAgCIAnAAIAAACQgGABgCACQgDACACAFIAVAzIAQgpIgEgKQgCgFgDgCQgCgCgFgBIAAgCIAmAAIAAACQgGABgCACQgCACABAFIAVAzIAUgzQACgEgCgDQgCgCgFgBIAAgCIAXAAIAAACQgEAAgCACQgCADgCAFIggBLg");
	this.shape_3.setTransform(-20.825,22.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgEgKgBgMQAAgNAGgLQAFgKAJgGQAJgGAMAAQALAAAIAEQAHAFAEAJQADAIAAALIg4AAIAAABIAAACQAAAKADAIQAEAJAHAEQAHAEAJAAQAJAAAGgEQAGgEADgGIACABQgCAIgEAGQgFAGgHAEQgHADgKAAQgMAAgIgGgAATgMQAAgHgCgGQgCgGgEgEQgEgEgGgBQgFAAgEAEQgFAEgCAGQgDAGgBAIIAmAAIAAAAg");
	this.shape_4.setTransform(-32.25,22.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAJAsIAAgDQAEAAADgDQADgCAAgFIAAgvQAAgHgEgEQgDgEgIgBQgFABgFACQgEADgGAHIAAAyQAAAFACACQADADAFAAIAAADIgmAAIAAgDQAFAAADgDQADgCAAgFIAAg3QgBgEgCgDQgCgBgEgBIgEAAIAAgCIAcgIIACAAIAAATQAGgJAHgFQAHgFAIAAQAMAAAGAHQAGAHAAANIAAAvQAAAFADACQADADAFAAIAAADg");
	this.shape_5.setTransform(-41.65,22.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape_6.setTransform(-54.975,22.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAJAsIAAgCQAEgBADgDQADgCAAgFIAAgvQAAgHgEgEQgDgFgIAAQgEAAgFADQgFADgGAHIAAAyQAAAFADACQACADAFABIAAACIgmAAIAAgCQAEgBADgDQAEgCAAgFIAAg3QgBgEgCgCQgCgDgEAAIgEAAIAAgDIAbgHIADAAIAAATQAHgJAGgFQAHgFAIAAQAMAAAGAHQAGAHAAAMIAAAwQAAAFADACQADADAFABIAAACg");
	this.shape_7.setTransform(16.75,2.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRA+IAAgCQAEgBADgCQAEgCAAgGIAAg3QgBgEgCgCQgCgCgEgBIgEAAIAAgCIAagIIADAAIAABKQAAAGACACQADACAFABIAAACgAgHgpQgEgEAAgFQAAgFAEgDQADgDAFAAQAFAAAEADQADADAAAFQAAAFgDAEQgEADgFAAQgFAAgDgDg");
	this.shape_8.setTransform(9.1,0.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAQA9IAAgTQgEAJgHAFQgGAGgJgBQgLAAgHgFQgIgGgFgJQgDgKAAgMQgBgQAGgJQAFgLAJgFQAJgGAKAAQAGAAAHADQAFACAEAFIAAgXQAAgEgDgDQgCgCgEAAIgEAAIAAgDIAbgHIADAAIAABmQAAAEACADQADACAEAAIAEAAIAAADIgbAHgAgQgRQgFAEgDAJQgCAGAAALQgBAJADAJQADAIAFAGQAFAFAIAAQAFAAAGgDQAFgFADgGIAAggQAAgHgDgGQgCgFgEgFQgGgDgGAAQgGAAgFAFg");
	this.shape_9.setTransform(-1.95,1.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgDQAEgCAAgFIAAg3QAAgEgDgCQgCgDgEAAIgEAAIAAgDIAcgHIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBAQIgFgBIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJABIAAACg");
	this.shape_10.setTransform(-10.525,2.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMAtIgBgWQgBAHgFAFQgEAFgFACQgGADgGAAQgLAAgGgGQgGgGgBgJQAAgJAFgGQAEgGAIgDQAJgDAOgDIALgCIAAgGQAAgMgFgHQgFgHgIAAQgGABgFADQgEAEgBAGQgBAGADAGIgPAFQgEgJADgIQADgIAJgFQAJgFANAAQAOAAAJAIQAIAIAAAOIAAAoQAAAEADADQACACAEAAIAEAAIAAADIgbAHgAAAgBQgLABgFAFQgGAGAAAJQAAAGAEAEQAEAFAHAAQAEAAADgDQAFgDADgFQADgFAAgHIAAgPg");
	this.shape_11.setTransform(-18.275,2.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgCgEgBIAAgCIAnAAIAAACQgGABgCACQgDACACAFIAVAyIAQgoIgEgKQgCgFgDgCQgCgCgFgBIAAgCIAmAAIAAACQgGABgCACQgCACABAFIAVAyIAUgyQACgEgCgDQgCgCgFgBIAAgCIAXAAIAAACQgEAAgCACQgCADgCAFIggBLg");
	this.shape_12.setTransform(-30.075,3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgDQAEgCAAgFIAAg3QAAgEgDgCQgCgDgEAAIgEAAIAAgDIAcgHIACAAIAAAZQADgMAHgHQAGgGAIAAIADAAIAEABIgBAQIgFgBIgFgBQgGAAgGADQgFAFgDAGIAAAtQAAAFADACQADADAJABIAAACg");
	this.shape_13.setTransform(-40.375,2.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAoQgJgGgFgKQgFgJAAgNQAAgNAFgLQAFgKAKgGQAJgGAMAAQAMAAAJAFQAJAGAFAJQAFAKAAANQAAANgFALQgFAKgKAGQgJAGgMAAQgMAAgJgFgAgMgjQgFAEgDAIQgCAIAAAKIABAPQACAJADAGQADAHAFAEQAFAEAFAAQAHAAAFgEQAEgFADgHQACgIAAgLIgBgPQgCgIgDgGQgDgHgFgEQgFgFgFAAQgHAAgEAFg");
	this.shape_14.setTransform(-48.775,2.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AggA9IAAgCQAGAAADgDQADgCAAgGIAAhDIgOAAIAAgEIAOAAIAAgGQAAgKAFgIQAEgGAIgEQAHgEAIABQAIAAAGABQAGADADAGIgOAJQgBgHgCgDQgDgFgFAAQgFAAgDAEQgCADgBAFQgBAGAAAGIAAAJIAWAAIAAAEIgWAAIAABDQAAAGACACQAEADAIAAIAAACg");
	this.shape_15.setTransform(-55.85,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgfA5QgKgGAAgJQAAgGADgDQACgEAEgDQAEgDAEAAQgEgDgDgEQgCgDAAgEQAAgFAEgEQACgEAHgDQgHgDgEgHQgEgGAAgIQAAgJAEgHQAEgGAJgEQAIgEAKAAQAHAAAIADIAaAAIAAAEIgSAAQAFAEADAGQAEAFAAAIQgBAIgEAHQgFAGgHAEQgIAEgKAAIgJgBIgJgDIgEAEIgBAEQAAADADACQADADAGABIAaACQAMAAAIAGQAHAFAAAKQAAAJgGAGQgGAGgKAEQgLADgMAAQgRAAgLgFgAgZAdQgCADAAAEQABAHADAFQAEAFAGACQAIADAHAAQAIAAAHgDQAGgBAEgEQAEgEAAgEQAAgGgEgDQgEgEgLgBIgXgCIgFgBIgEgBIgFAFgAgNgyQgEAGAAAKQAAAMAFAIQAFAHAHAAQAHAAAFgGQAEgFABgLQgBgIgCgGQgCgGgEgEQgFgDgEAAQgHAAgFAGg");
	this.shape_16.setTransform(9.85,-15.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAIAsIAAgCQAFgBADgCQADgDAAgFIAAgvQAAgHgEgEQgEgFgGABQgGAAgEACQgGADgGAGIAAAzQABAFADADQADACAEABIAAACIgmAAIAAgCQAEgBADgCQADgDABgFIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgDIAbgHIACAAIAAATQAHgJAHgFQAHgFAIAAQAMAAAGAHQAGAHAAAMIAAAwQABAFACADQADACAFABIAAACg");
	this.shape_17.setTransform(0.35,-16.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgRA+IAAgCQAEgBADgCQADgCABgGIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgCIAagIIACAAIAABKQABAGADACQADACAEABIAAACgAgHgpQgDgEgBgFQABgFADgDQAEgDAEAAQAFAAADADQAEADAAAFQAAAFgEAEQgDADgFAAQgEAAgEgDg");
	this.shape_18.setTransform(-7.3,-18.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgdAsIAAgCQAFgBADgCQAEgDAAgFIAAg3QAAgEgDgCQgCgCgEgBIgEAAIAAgDIAcgHIACAAIAAAYQADgMAHgGQAGgGAIAAIADAAIAEACIgBAPIgFgCIgFAAQgGAAgGADQgFAFgDAHIAAAsQAAAFADADQADACAJABIAAACg");
	this.shape_19.setTransform(-13.125,-16.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSAnQgJgGgFgJQgFgKAAgMQABgNAFgLQAFgKAJgGQAKgGALAAQALAAAHAEQAIAFADAJQAFAIAAALIg5AAIgBABIAAACQABAKADAIQAEAJAHAEQAHAEAJAAQAJAAAGgEQAGgEADgGIADABQgCAIgFAGQgEAGgIAEQgHADgJAAQgMAAgJgGgAAUgMQAAgHgDgGQgCgGgEgEQgEgEgGgBQgFAAgEAEQgFAEgCAGQgDAGgBAIIAnAAIAAAAg");
	this.shape_20.setTransform(-21.15,-16.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAZAsIgYg6IgYA6IgCAAIgghLQgCgFgCgCQgDgDgEAAIAAgCIAnAAIAAACQgGAAgCADQgDACACAFIAVAyIAQgnIgEgLQgCgFgDgCQgCgDgFAAIAAgCIAmAAIAAACQgGAAgCADQgCACABAFIAVAyIAUgyQACgEgCgDQgCgDgFAAIAAgCIAXAAIAAACQgEABgCACQgCACgCAFIggBLg");
	this.shape_21.setTransform(-32.575,-16.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgVAoQgJgGgFgKQgFgJAAgNQAAgNAFgLQAFgKAKgGQAJgGAMAAQAMAAAJAFQAJAGAFAJQAFAKAAANQAAANgFALQgFAKgKAGQgJAGgMAAQgMAAgJgFgAgMgjQgFAEgDAIQgCAIAAAKIABAPQACAJADAGQADAHAFAEQAFAEAFAAQAHAAAFgEQAEgFADgHQACgIAAgLIgBgPQgCgIgDgGQgDgHgFgEQgFgFgFAAQgHAAgEAFg");
	this.shape_22.setTransform(-44.375,-16.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgvA5IAAgDQAJAAADgDQAEgCAAgHIAAhTQAAgHgEgCQgDgDgJAAIAAgDIAyAAQANAAAKAEQAKADAGAHQAFAHABALQgBALgFAHQgGAGgKADQgKAEgNAAIgQAAIAAAjQABAHADACQAEADAGAAIAAADgAgNACIANAAQAOAAAHgGQAHgIAAgMQAAgMgHgIQgIgHgNAAIgNAAg");
	this.shape_23.setTransform(-54.45,-18.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.8,-32.9,123.6,65.8);


// stage content:
(lib.v11PE2026DemandbaseLandingPage160x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// SUBTITLE
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(80.15,254.55);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(80.15,214.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},54).to({state:[{t:this.instance_1}]},14).wait(53));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({_off:true,y:214.1,alpha:1},14,cjs.Ease.cubicInOut).wait(53));

	// TITLE
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(79.9,167.05);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(79.9,135.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},29).to({state:[{t:this.instance_3}]},15).wait(77));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).to({_off:true,y:135.4,alpha:1},15,cjs.Ease.cubicInOut).wait(77));

	// CTA
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(78.5,304.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(78.5,269);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},79).to({state:[{t:this.instance_5}]},14).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(79).to({_off:false},0).to({_off:true,y:269,alpha:1},14,cjs.Ease.cubicInOut).wait(28));

	// LOGO
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(80,38.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(121));

	// RED_BAR
	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(-84,595);
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(80,595);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},4).to({state:[{t:this.instance_8}]},14).wait(103));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({_off:false},0).to({_off:true,x:80},14,cjs.Ease.cubicInOut).wait(103));

	// SHADOW
	this.instance_9 = new lib.Rectangle();
	this.instance_9.setTransform(80,237.4,1,1,0,0,0,80,237.4);
	this.instance_9.alpha = 0.6406;
	this.instance_9.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(121));

	// FOREGROUND
	this.instance_10 = new lib.Tween16("synched",0);
	this.instance_10.setTransform(104.3,299.15);

	this.instance_11 = new lib.Tween17("synched",0);
	this.instance_11.setTransform(146.5,294.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true,x:146.5,y:294.5},120).wait(1));

	// MOUNTAIN
	this.instance_12 = new lib.Tween18("synched",0);
	this.instance_12.setTransform(146.5,316.1);

	this.instance_13 = new lib.Tween19("synched",0);
	this.instance_13.setTransform(146.5,297);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,y:297},120).wait(1));

	// BACKGROUND
	this.instance_14 = new lib.Tween20("synched",0);
	this.instance_14.setTransform(135,294.5);

	this.instance_15 = new lib.Tween21("synched",0);
	this.instance_15.setTransform(146,294.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_15}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true,x:146},120).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgODgwbIcHAAMAAABg3I8HAAg");
	this.shape.setTransform(80,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgODAwcMAAAhg3IcHAAMAAABg3g");
	this.shape_1.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(121));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-84,289,379,332.6);
// library properties:
lib.properties = {
	id: '623F7813A6641B42A1DC217EA7E5930C',
	width: 160,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1.png", id:"v1_1_PE2026_Demandbase_LandingPage_160x600_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['623F7813A6641B42A1DC217EA7E5930C'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;