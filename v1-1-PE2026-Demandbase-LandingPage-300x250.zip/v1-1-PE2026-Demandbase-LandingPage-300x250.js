(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1", frames: [[0,0,483,262],[0,528,482,262],[0,264,483,262]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Foreground72x = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Mountains72x = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Sky72x = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.647)","rgba(0,0,0,0.196)","rgba(0,0,0,0)"],[0,0.878,1],-117.5,0,117.5,0).s().p("AyWTsMAAAgnXMAktAAAMAAAAnXg");
	this.shape.setTransform(117.5,126);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(0,0,235,252), null);


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgsAsg/AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAiIgHgPIgYAAIgHAPIgMAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.2,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.425,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQgFgGgBgIQAAgLAOgHQgHgIAAgIQAAgGAGgFQAFgFAIABQAIAAAFADQAGAFgBAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgIAIgKAAQgJAAgHgEgAgIAEQgKAEAAAHQAAALAMAAQAHAAAEgGIgNgRgAgMgRQAAAFAHAGQAKgFAAgHQAAgHgIAAQgJgBAAAJg");
	this.shape_3.setTransform(-47.05,11.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQBAgBAAAtQAAAMgGAKQgHAKgKAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAOAAQAkAAAAgXQAAgYgkAAIgOAAgAgZgMIAHAAQAiAAAAgYQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.575,-4.5761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.9,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBWIAAirIAfAAIAACrg");
	this.shape_6.setTransform(-12.625,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhCIAYArIAXgrIASBCIgNAAIgIgjIgUAkg");
	this.shape_8.setTransform(-20.5,11.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIARAAQAaAAAAAVQgBAKgHAFQgHAEgLAAIgEAAIAAAZgAgIgBIAEAAQANAAAAgKQAAgLgNAAIgEAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIARgbIANAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.725,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgOAKgJQAKgKAOAAQARAAAKAMIAAABIgKAHIAAAAQgGgJgLAAQgIAAgHAGQgGAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIAAABQgKAMgRAAQgPAAgJgJg");
	this.shape_11.setTransform(-37.35,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgKQALgKANAAQAPAAAKAJQAJAKABAOQgBAOgJAKQgLAKgOAAQgNAAgLgJgAgPgPQgGAHAAAIQAAAKAGAHQAHAGAIAAQAJABAHgIQAFgGAAgKQAAgJgFgHQgHgGgJAAQgIAAgHAHg");
	this.shape_12.setTransform(-29.4,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Sky72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Sky72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mountains72x();
	this.instance.setTransform(-241,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241,-131,482,262);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mountains72x();
	this.instance.setTransform(-241,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241,-131,482,262);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Foreground72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Foreground72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBLIAAiVMAu3AAAIAACVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-7.5,300,15);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBLIAAiVMAu3AAAIAACVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-7.5,300,15);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.825,1.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.525,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.875,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgGgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQAEAHAEADQAGAEAGAAQAIAAAFgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgFgEgIAAQgLAAgFAIg");
	this.shape_3.setTransform(28,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQAEgEAAgGIAAgBQAAgGgEgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.025,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.625,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgSAAIAAhVIASAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.6,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.375,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.375,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.875,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHAAALIgTAAQgBgIgEgEQgGgDgHAAQgGAAgGADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQACgEABgFIgUAAIAAgNIAnAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-53.95,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.825,1.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.525,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.875,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgGgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQAEAHAEADQAGAEAGAAQAIAAAFgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgFgEgIAAQgLAAgFAIg");
	this.shape_3.setTransform(28,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQAEgEAAgGIAAgBQAAgGgEgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.025,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.625,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgSAAIAAhVIASAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.6,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.375,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.375,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.875,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHAAALIgTAAQgBgIgEgEQgGgDgHAAQgGAAgGADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQACgEABgFIgUAAIAAgNIAnAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-53.95,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglBHQgPgKgHgRQgHgRAAgXIAAgEQAAgZAKgSQAJgSAQgJQAQgKATAAQAaAAAQAMQAPAMACAXIgpAAQgBgHgEgDQgDgDgJgBQgMAAgGALQgHALgBAUQAFgIAJgGQAHgEAPAAQAOgBAMAHQAMAFAHALQAHALAAAQQAAAQgIANQgIANgOAGQgOAHgVAAQgXAAgQgKgAgNAKQgFAHAAAJQAAAKAFAHQAGAGAJAAQAKAAAFgGQAGgHAAgJQAAgKgGgHQgFgGgKgBQgJABgGAGg");
	this.shape.setTransform(46.875,26.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BQIAAgHIA4g6QAKgMAIgKQAGgLAAgJQAAgIgDgFQgEgFgJAAQgIAAgFAGQgEAGgCAOIgpAAQABgeARgPQARgPAbAAQATAAANAHQAOAGAHALQAGALAAAPQAAAQgIANQgIAMgOANIgVAVIA1AAIAAAig");
	this.shape_1.setTransform(32.4,26.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgmBIQgQgJgIgRQgKgSABgZIAAgGQAAgZAJgQQAKgSAQgJQAQgJAUAAQAVAAAQAJQARAIAJARQAKARAAAaIAAAFQAAAZgJASQgKARgQAKQgRAJgVAAQgWAAgQgJgAgUgjQgGALAAAVIAAAGQAAAWAGALQAHAKAOAAQAOAAAGgKQAGgLABgWIAAgGQgBgVgGgLQgHgLgOAAQgNAAgHALg");
	this.shape_2.setTransform(17.85,26.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BQIAAgHIA3g6QAMgMAGgKQAIgLgBgJQAAgIgDgFQgFgFgIAAQgIAAgEAGQgGAGgBAOIgpAAQABgeARgPQAQgPAcAAQATAAANAHQAOAGAGALQAHALAAAPQAAAQgIANQgIAMgNANIgXAVIA1AAIAAAig");
	this.shape_3.setTransform(2.85,26.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMA9QgLgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAnAAIAAAYIAWAAIAAAbIgWAAIAAAvQAAAGACADQADADAGAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgKgKg");
	this.shape_4.setTransform(-12.45,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AglA6IAAhyIAmAAIAAAXQAGgNAJgGQAJgGANABIAAAkQgSAAgJAGQgKAGAAANIAAA2g");
	this.shape_5.setTransform(-21.175,28.2231);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfA1QgPgGgHgOQgJgNAAgSIAAgCQAAgSAJgNQAHgOAPgHQAOgHARAAQASAAAOAHQAOAHAJANQAHANABATIAAABQgBASgHAOQgJANgOAHQgOAHgSAAQgRAAgOgHgAgQgWQgGAHAAAPIAAABQAAAPAGAHQAGAIAKAAQALAAAGgIQAGgHAAgPIAAgBQAAgOgGgIQgFgIgMAAQgKAAgGAIg");
	this.shape_6.setTransform(-33,28.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BOIAAiYIAoAAIAAARQAFgJAIgFQAJgGANAAQANAAALAGQALAHAGANQAHANAAAUIAAACQAAATgHANQgGANgLAHQgLAGgOAAQgNAAgIgFQgJgFgEgJIAAA3gAgRgoQgFAHAAAPIAAACQAAAPAFAGQAHAHAKAAQALAAAFgHQAGgHAAgOIAAgCQAAgPgGgHQgGgIgKAAQgKAAgHAIg");
	this.shape_7.setTransform(-46.65,30.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdA2QgOgHgIgNQgIgNAAgTIAAgCQAAgSAIgNQAIgOAOgHQAOgHARAAQAQAAANAGQANAGAIANQAIANAAAVIAAAJIhPAAQAAAMAHAGQAGAGAKAAQAJAAAFgEQAFgDABgGIAkAAQgCATgPALQgPAKgaAAQgRAAgOgGgAAWgMQAAgKgFgGQgFgFgKAAQgIAAgGAFQgFAGgCAKIApAAIAAAAg");
	this.shape_8.setTransform(-60.575,28.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAUBPIgfg5IgLAAIAAA5IgtAAIAAidIA+AAQAeAAAQANQARANAAAYIAAABQAAARgIAKQgHAJgNAFIAlBBgAgWgGIAPAAQALAAAFgFQAGgEgBgKIAAgBQABgJgGgFQgGgEgJAAIgQAAg");
	this.shape_9.setTransform(-73.7,26.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjBNIATgyIguhnIArAAIAWA+IAWg+IAmAAIg+CZg");
	this.shape_10.setTransform(62.325,6.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNA9QgKgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAmAAIAAAYIAXAAIAAAbIgXAAIAAAvQAAAGAEADQADADAFAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgLgKg");
	this.shape_11.setTransform(51.4,3.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgSBTIAAhyIAlAAIAABygAgPgwQgFgFAAgJQAAgJAFgGQAHgFAIAAQAJAAAHAFQAFAGAAAJQAAAJgFAFQgHAGgJAAQgIAAgHgGg");
	this.shape_12.setTransform(44.05,1.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AglA2QgJgEgFgKQgFgJAAgPIAAhKIAnAAIAABEQAAAKAEAEQAEAFAJAAQAHAAAGgFQAFgGAAgLIAAhBIAoAAIAAByIgoAAIAAgRQgFAJgIAFQgIAGgPAAQgLAAgIgFg");
	this.shape_13.setTransform(33.9,4.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAWBOIAAg4QgEAIgJAGQgJAGgMAAQgOAAgLgGQgLgGgGgOQgHgNAAgTIAAgBQAAgUAHgNQAGgOALgHQALgGAOAAQAMAAAJAFQAJAFAEAJIAAgQIAoAAIAACYgAgPgoQgGAHAAAPIAAACQAAAPAGAGQAGAHAJAAQALAAAGgHQAGgHAAgOIAAgCQAAgPgFgHQgGgIgLAAQgKAAgGAIg");
	this.shape_14.setTransform(19.775,5.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag3BPIAAidIBsAAIAAAjIg/AAIAAAbIAyAAIAAAfIgyAAIAAAdIBCAAIAAAjg");
	this.shape_15.setTransform(6.675,2.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdA2QgOgHgIgNQgIgNAAgTIAAgCQAAgSAIgNQAIgOAOgHQAOgHARAAQAQAAANAGQANAGAIANQAIANAAAVIAAAJIhPAAQAAAMAHAGQAGAGAKAAQAJAAAFgEQAFgDABgGIAkAAQgCATgPALQgPAKgaAAQgRAAgOgGgAAWgMQAAgKgFgGQgFgFgKAAQgIAAgGAFQgFAGgCAKIApAAIAAAAg");
	this.shape_16.setTransform(-11.375,4.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgNA9QgKgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAmAAIAAAYIAXAAIAAAbIgXAAIAAAvQAAAGAEADQADADAFAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgLgKg");
	this.shape_17.setTransform(-22.4,3.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjA5QgJgEgFgHQgGgIAAgMQABgUAQgIQAQgJAbAAIALAAIAAgCQABgJgDgFQgEgFgJAAQgHABgDADQgEAEAAAGIglAAQABgOAHgJQAHgJAMgFQAMgEAPAAQAQAAALAEQAMAFAGAJQAHAKAAAPIAABKIgnAAIAAgOQgEAHgIAEQgHAFgOAAQgKAAgJgDgAgKANQgGADAAAHQAAAFAEADQADADAHAAQAIAAAFgFQAFgEAAgIIAAgHIgKAAQgLAAgFADg");
	this.shape_18.setTransform(-33.075,4.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUA6IgrhyIAqAAIAYBIIAXhIIAmAAIgqByg");
	this.shape_19.setTransform(-45.175,4.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSBTIAAhyIAlAAIAABygAgPgwQgFgFAAgJQAAgJAFgGQAHgFAIAAQAJAAAHAFQAFAGAAAJQAAAJgFAFQgHAGgJAAQgIAAgHgGg");
	this.shape_20.setTransform(-54.95,1.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AglA6IAAhyIAmAAIAAAXQAGgNAJgGQAJgGANABIAAAkQgSAAgJAGQgKAGAAANIAAA2g");
	this.shape_21.setTransform(-62.625,4.1231);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag9BPIAAidIA8AAQAgABAPANQAQAOgBAZIAAABQAAAYgQANQgPANgeAAIgQAAIAAA1gAgQgEIANAAQAKAAAGgFQAGgFAAgKIAAgBQAAgKgGgEQgGgFgJAAIgOAAg");
	this.shape_22.setTransform(-74.2992,2.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTBTIAAilIAnAAIAAClg");
	this.shape_23.setTransform(-14.4,-22.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgjA5QgJgEgFgHQgGgIAAgMQABgUAQgIQAQgJAbAAIALAAIAAgCQABgJgDgFQgEgFgJAAQgHABgDADQgEAEAAAGIglAAQABgOAHgJQAHgJAMgFQAMgEAPAAQAQAAALAEQAMAFAGAJQAHAKAAAPIAABKIgnAAIAAgOQgEAHgIAEQgHAFgOAAQgKAAgJgDgAgKANQgGADAAAHQAAAFAEADQADADAHAAQAIAAAFgFQAFgEAAgIIAAgHIgKAAQgLAAgFADg");
	this.shape_24.setTransform(-24.275,-19.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgIBOQgJgFgFgJIAAASIgnAAIAAilIAnAAIAABEQAGgJAJgGQAHgFANAAQAOgBALAHQALAHAHANQAGAMAAAUIAAABQAAAVgGANQgHANgLAGQgLAHgOAAQgNAAgIgGgAgQABQgHAHAAAOIAAACQAAAPAHAIQAFAHALAAQAKAAAGgHQAGgIAAgPIAAgBQAAgPgGgHQgGgHgKAAQgLAAgFAHg");
	this.shape_25.setTransform(-37.15,-22.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgfA1QgPgGgHgOQgJgNAAgSIAAgCQAAgSAJgNQAHgOAPgHQAOgHARAAQASAAAOAHQAOAHAIANQAJANAAATIAAABQAAASgJAOQgIANgOAHQgOAHgSAAQgRAAgOgHgAgQgWQgGAHAAAPIAAABQAAAPAGAHQAGAIAKAAQALAAAGgIQAGgHAAgPIAAgBQAAgOgGgIQgFgIgMAAQgKAAgGAIg");
	this.shape_26.setTransform(-51.35,-19.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgTBTIAAilIAmAAIAAClg");
	this.shape_27.setTransform(-61.4,-22.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgqBHQgSgKgJgSQgKgTAAgXIAAgBQAAgYALgSQALgSASgKQATgKAXAAQASAAAQAGQAQAFALAOQAKANACATIgtAAQgCgKgHgGQgHgGgMAAQgQAAgJAMQgKAMAAAVIAAABQAAANAEALQADAKAIAGQAIAGANAAQALAAAHgDQAGgDAEgGQADgFAAgHIgdAAIAAgfIBKAAIAAATQAAAUgJAQQgJAQgRAJQgRAJgZAAQgaAAgTgKg");
	this.shape_28.setTransform(-73.275,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-41.1,167.9,82.30000000000001);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglBHQgPgKgHgRQgHgRAAgXIAAgEQAAgZAKgSQAJgSAQgJQAQgKATAAQAaAAAQAMQAPAMACAXIgpAAQgBgHgEgDQgDgDgJgBQgMAAgGALQgHALgBAUQAFgIAJgGQAHgEAPAAQAOgBAMAHQAMAFAHALQAHALAAAQQAAAQgIANQgIANgOAGQgOAHgVAAQgXAAgQgKgAgNAKQgFAHAAAJQAAAKAFAHQAGAGAJAAQAKAAAFgGQAGgHAAgJQAAgKgGgHQgFgGgKgBQgJABgGAGg");
	this.shape.setTransform(46.875,26.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BQIAAgHIA4g6QAKgMAIgKQAGgLAAgJQAAgIgDgFQgEgFgJAAQgIAAgFAGQgEAGgCAOIgpAAQABgeARgPQARgPAbAAQATAAANAHQAOAGAHALQAGALAAAPQAAAQgIANQgIAMgOANIgVAVIA1AAIAAAig");
	this.shape_1.setTransform(32.4,26.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgmBIQgQgJgIgRQgKgSABgZIAAgGQAAgZAJgQQAKgSAQgJQAQgJAUAAQAVAAAQAJQARAIAJARQAKARAAAaIAAAFQAAAZgJASQgKARgQAKQgRAJgVAAQgWAAgQgJgAgUgjQgGALAAAVIAAAGQAAAWAGALQAHAKAOAAQAOAAAGgKQAGgLABgWIAAgGQgBgVgGgLQgHgLgOAAQgNAAgHALg");
	this.shape_2.setTransform(17.85,26.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BQIAAgHIA3g6QAMgMAGgKQAIgLgBgJQAAgIgDgFQgFgFgIAAQgIAAgEAGQgGAGgBAOIgpAAQABgeARgPQAQgPAcAAQATAAANAHQAOAGAGALQAHALAAAPQAAAQgIANQgIAMgNANIgXAVIA1AAIAAAig");
	this.shape_3.setTransform(2.85,26.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMA9QgLgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAnAAIAAAYIAWAAIAAAbIgWAAIAAAvQAAAGACADQADADAGAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgKgKg");
	this.shape_4.setTransform(-12.45,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AglA6IAAhyIAmAAIAAAXQAGgNAJgGQAJgGANABIAAAkQgSAAgJAGQgKAGAAANIAAA2g");
	this.shape_5.setTransform(-21.175,28.2231);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfA1QgPgGgHgOQgJgNAAgSIAAgCQAAgSAJgNQAHgOAPgHQAOgHARAAQASAAAOAHQAOAHAJANQAHANABATIAAABQgBASgHAOQgJANgOAHQgOAHgSAAQgRAAgOgHgAgQgWQgGAHAAAPIAAABQAAAPAGAHQAGAIAKAAQALAAAGgIQAGgHAAgPIAAgBQAAgOgGgIQgFgIgMAAQgKAAgGAIg");
	this.shape_6.setTransform(-33,28.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BOIAAiYIAoAAIAAARQAFgJAIgFQAJgGANAAQANAAALAGQALAHAGANQAHANAAAUIAAACQAAATgHANQgGANgLAHQgLAGgOAAQgNAAgIgFQgJgFgEgJIAAA3gAgRgoQgFAHAAAPIAAACQAAAPAFAGQAHAHAKAAQALAAAFgHQAGgHAAgOIAAgCQAAgPgGgHQgGgIgKAAQgKAAgHAIg");
	this.shape_7.setTransform(-46.65,30.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdA2QgOgHgIgNQgIgNAAgTIAAgCQAAgSAIgNQAIgOAOgHQAOgHARAAQAQAAANAGQANAGAIANQAIANAAAVIAAAJIhPAAQAAAMAHAGQAGAGAKAAQAJAAAFgEQAFgDABgGIAkAAQgCATgPALQgPAKgaAAQgRAAgOgGgAAWgMQAAgKgFgGQgFgFgKAAQgIAAgGAFQgFAGgCAKIApAAIAAAAg");
	this.shape_8.setTransform(-60.575,28.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAUBPIgfg5IgLAAIAAA5IgtAAIAAidIA+AAQAeAAAQANQARANAAAYIAAABQAAARgIAKQgHAJgNAFIAlBBgAgWgGIAPAAQALAAAFgFQAGgEgBgKIAAgBQABgJgGgFQgGgEgJAAIgQAAg");
	this.shape_9.setTransform(-73.7,26.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjBNIATgyIguhnIArAAIAWA+IAWg+IAmAAIg+CZg");
	this.shape_10.setTransform(62.325,6.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNA9QgKgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAmAAIAAAYIAXAAIAAAbIgXAAIAAAvQAAAGAEADQADADAFAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgLgKg");
	this.shape_11.setTransform(51.4,3.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgSBTIAAhyIAlAAIAABygAgPgwQgFgFAAgJQAAgJAFgGQAHgFAIAAQAJAAAHAFQAFAGAAAJQAAAJgFAFQgHAGgJAAQgIAAgHgGg");
	this.shape_12.setTransform(44.05,1.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AglA2QgJgEgFgKQgFgJAAgPIAAhKIAnAAIAABEQAAAKAEAEQAEAFAJAAQAHAAAGgFQAFgGAAgLIAAhBIAoAAIAAByIgoAAIAAgRQgFAJgIAFQgIAGgPAAQgLAAgIgFg");
	this.shape_13.setTransform(33.9,4.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAWBOIAAg4QgEAIgJAGQgJAGgMAAQgOAAgLgGQgLgGgGgOQgHgNAAgTIAAgBQAAgUAHgNQAGgOALgHQALgGAOAAQAMAAAJAFQAJAFAEAJIAAgQIAoAAIAACYgAgPgoQgGAHAAAPIAAACQAAAPAGAGQAGAHAJAAQALAAAGgHQAGgHAAgOIAAgCQAAgPgFgHQgGgIgLAAQgKAAgGAIg");
	this.shape_14.setTransform(19.775,5.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag3BPIAAidIBsAAIAAAjIg/AAIAAAbIAyAAIAAAfIgyAAIAAAdIBCAAIAAAjg");
	this.shape_15.setTransform(6.675,2.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdA2QgOgHgIgNQgIgNAAgTIAAgCQAAgSAIgNQAIgOAOgHQAOgHARAAQAQAAANAGQANAGAIANQAIANAAAVIAAAJIhPAAQAAAMAHAGQAGAGAKAAQAJAAAFgEQAFgDABgGIAkAAQgCATgPALQgPAKgaAAQgRAAgOgGgAAWgMQAAgKgFgGQgFgFgKAAQgIAAgGAFQgFAGgCAKIApAAIAAAAg");
	this.shape_16.setTransform(-11.375,4.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgNA9QgKgJAAgVIAAgyIgOAAIAAgbIAOAAIAAgYIAmAAIAAAYIAXAAIAAAbIgXAAIAAAvQAAAGAEADQADADAFAAIAGgBIAFgBIAAAeIgJACIgNABQgSAAgLgKg");
	this.shape_17.setTransform(-22.4,3.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjA5QgJgEgFgHQgGgIAAgMQABgUAQgIQAQgJAbAAIALAAIAAgCQABgJgDgFQgEgFgJAAQgHABgDADQgEAEAAAGIglAAQABgOAHgJQAHgJAMgFQAMgEAPAAQAQAAALAEQAMAFAGAJQAHAKAAAPIAABKIgnAAIAAgOQgEAHgIAEQgHAFgOAAQgKAAgJgDgAgKANQgGADAAAHQAAAFAEADQADADAHAAQAIAAAFgFQAFgEAAgIIAAgHIgKAAQgLAAgFADg");
	this.shape_18.setTransform(-33.075,4.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUA6IgrhyIAqAAIAYBIIAXhIIAmAAIgqByg");
	this.shape_19.setTransform(-45.175,4.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSBTIAAhyIAlAAIAABygAgPgwQgFgFAAgJQAAgJAFgGQAHgFAIAAQAJAAAHAFQAFAGAAAJQAAAJgFAFQgHAGgJAAQgIAAgHgGg");
	this.shape_20.setTransform(-54.95,1.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AglA6IAAhyIAmAAIAAAXQAGgNAJgGQAJgGANABIAAAkQgSAAgJAGQgKAGAAANIAAA2g");
	this.shape_21.setTransform(-62.625,4.1231);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag9BPIAAidIA8AAQAgABAPANQAQAOgBAZIAAABQAAAYgQANQgPANgeAAIgQAAIAAA1gAgQgEIANAAQAKAAAGgFQAGgFAAgKIAAgBQAAgKgGgEQgGgFgJAAIgOAAg");
	this.shape_22.setTransform(-74.2992,2.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTBTIAAilIAnAAIAAClg");
	this.shape_23.setTransform(-14.4,-22.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgjA5QgJgEgFgHQgGgIAAgMQABgUAQgIQAQgJAbAAIALAAIAAgCQABgJgDgFQgEgFgJAAQgHABgDADQgEAEAAAGIglAAQABgOAHgJQAHgJAMgFQAMgEAPAAQAQAAALAEQAMAFAGAJQAHAKAAAPIAABKIgnAAIAAgOQgEAHgIAEQgHAFgOAAQgKAAgJgDgAgKANQgGADAAAHQAAAFAEADQADADAHAAQAIAAAFgFQAFgEAAgIIAAgHIgKAAQgLAAgFADg");
	this.shape_24.setTransform(-24.275,-19.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgIBOQgJgFgFgJIAAASIgnAAIAAilIAnAAIAABEQAGgJAJgGQAHgFANAAQAOgBALAHQALAHAHANQAGAMAAAUIAAABQAAAVgGANQgHANgLAGQgLAHgOAAQgNAAgIgGgAgQABQgHAHAAAOIAAACQAAAPAHAIQAFAHALAAQAKAAAGgHQAGgIAAgPIAAgBQAAgPgGgHQgGgHgKAAQgLAAgFAHg");
	this.shape_25.setTransform(-37.15,-22.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgfA1QgPgGgHgOQgJgNAAgSIAAgCQAAgSAJgNQAHgOAPgHQAOgHARAAQASAAAOAHQAOAHAIANQAJANAAATIAAABQAAASgJAOQgIANgOAHQgOAHgSAAQgRAAgOgHgAgQgWQgGAHAAAPIAAABQAAAPAGAHQAGAIAKAAQALAAAGgIQAGgHAAgPIAAgBQAAgOgGgIQgFgIgMAAQgKAAgGAIg");
	this.shape_26.setTransform(-51.35,-19.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgTBTIAAilIAmAAIAAClg");
	this.shape_27.setTransform(-61.4,-22.425);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgqBHQgSgKgJgSQgKgTAAgXIAAgBQAAgYALgSQALgSASgKQATgKAXAAQASAAAQAGQAQAFALAOQAKANACATIgtAAQgCgKgHgGQgHgGgMAAQgQAAgJAMQgKAMAAAVIAAABQAAANAEALQADAKAIAGQAIAGANAAQALAAAHgDQAGgDAEgGQADgFAAgHIgdAAIAAgfIBKAAIAAATQAAAUgJAQQgJAQgRAJQgRAJgZAAQgaAAgTgKg");
	this.shape_28.setTransform(-73.275,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-41.1,167.9,82.30000000000001);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOAwIgBgYQgCAHgEAFQgFAGgFADQgGADgHAAQgLAAgGgGQgHgHAAgKQAAgNAJgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgHABgFAEQgFAEgBAGQgBAGADAHIgOAEQgEgJADgJQADgIAKgFQAJgFAMgBQAPABAIAIQAJAJAAAPIAAArQAAAEACACQADADAEAAIAEAAIAAADIgZAHgAAAgBQgNACgGAFQgGAGAAAJQABAIADAEQAFAFAHAAQAFAAAFgDQAFgDADgGQADgGABgIIAAgQg");
	this.shape.setTransform(18,13.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAZQADgLAHgHQAHgGAIgBIADABIAEABIgBAOIgEgBIgGAAQgGAAgGADQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_1.setTransform(9.575,13.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_2.setTransform(1.275,13.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPQgCgFgCgCQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_3.setTransform(-14.875,13.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-26.825,13.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQAEgCAAgGIAAgyQAAgIgEgFQgFgFgIAAQgGAAgGAEQgFADgHAHIAAA2QAAAGADACIAJADIAAADIgnAAIAAgDIAJgDQADgCAAgGIAAg7QAAgEgCgDQgDgCgEgBIgFAAIAAgCIAagIIADAAIAAAVQAIgKAHgFQAGgFAJgBQAMAAAHAIQAGAHABANIAAAzQAAAGADACIAIADIAAADg");
	this.shape_5.setTransform(-36.6,13.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AANAwIAAgYQgBAHgFAFQgEAGgFADQgHADgHAAQgLAAgHgGQgGgHgBgKQAAgNAKgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgHABgFAEQgFAEgBAGQgBAGADAHIgNAEQgFgJADgJQADgIAJgFQAKgFAMgBQAOABAJAIQAIAJABAPIAAArQAAAEACACQACADAFAAIAFAAIAAADIgaAHgAAAgBQgNACgFAFQgHAGAAAJQAAAIAFAEQAEAFAIAAQAFAAADgDQAFgDAEgGQAEgGAAgIIAAgQg");
	this.shape_6.setTransform(-50.45,13.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQAEgCAAgGIAAgyQgBgIgDgFQgFgFgIAAQgFAAgHAEQgFADgHAHIAAA2QAAAGADACIAJADIAAADIgnAAIAAgDIAJgDQADgCAAgGIAAg7QAAgEgCgDQgDgCgFgBIgDAAIAAgCIAZgIIADAAIAAAVQAHgKAIgFQAHgFAIgBQAMAAAHAIQAGAHAAANIAAAzQABAGADACIAIADIAAADg");
	this.shape_7.setTransform(-64.85,13.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBBIAAgCIAJgEQADgCAAgFIAAg7QAAgFgCgDQgCgCgFAAIgEAAIAAgCIAZgIIACAAIAABPQAAAFAEACIAIAEIAAACgAgHgtQgDgEAAgEQAAgFADgDQAEgDAEAAQAEAAAEADQADADAAAFQAAAEgDAEQgEACgEAAQgEAAgEgCg");
	this.shape_8.setTransform(-72.725,11.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AATBBIgBgWQgEAKgHAGQgHAGgKAAQgKAAgJgGQgIgGgEgKQgFgKAAgNQABgRAFgKQAGgLAJgGQAKgGALAAQAGAAAGAEQAHADADAFIAAgbQAAgEgCgCQgDgDgEAAIgEAAIAAgCIAagIIACAAIAABuQAAAEACACQADADAEAAIAFAAIAAADIgZAHgAgSgSQgFAFgEAIQgDAIAAAKQAAAIABAHQACAHAEAGQACAGAGAEQAEADAIABQAGgBAGgEQAHgFACgIIAAgiQAAgGgDgGQgCgGgGgEQgEgEgIgBQgHAAgGAGg");
	this.shape_9.setTransform(65.6,-9.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_10.setTransform(56.775,-7.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANAwIAAgYQgCAHgEAFQgEAGgGADQgGADgHAAQgLAAgGgGQgHgHgBgKQAAgNAKgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgIABgEAEQgFAEgBAGQgBAGADAHIgNAEQgFgJADgJQADgIAKgFQAJgFAMgBQAPABAIAIQAIAJABAPIAAArQAAAEACACQADADAEAAIAEAAIAAADIgZAHgAAAgBQgNACgFAFQgHAGAAAJQAAAIAEAEQAFAFAIAAQAFAAAEgDQAEgDAEgGQAEgGAAgIIAAgQg");
	this.shape_11.setTransform(48.9,-7.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPQgCgFgCgCQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_12.setTransform(36.525,-7.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_13.setTransform(25.875,-7.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_14.setTransform(17.225,-7.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgfBBIAAgDQAFAAAEgCQADgCABgGIAAhHIgQAAIAAgFIAQAAIAAgHQAAgLAEgIQAFgGAHgEQAGgEAJAAQAHAAAGACQAFADAEAEIgMAJQgCgFgDgEQgDgDgEgBQgIAAgDAHQgDAGAAALIAAALIAXAAIAAAFIgXAAIAABHQgBAGAEACQAEACAKAAIAAADg");
	this.shape_15.setTransform(9.95,-9.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggA7QgKgFAAgKQAAgGADgEQACgFAEgCQAEgDAFgBQgFgDgCgDQgDgEAAgDQAAgGAEgEQADgEAFgDQgGgFgEgGQgEgGAAgJQAAgJAEgHQAFgHAIgEQAIgEALgBQAIABAHADIAcAAIAAAEIgTAAQAFAFADAFQADAHAAAHQAAAJgEAHQgFAHgIAEQgIAEgKAAIgKgBQgFgBgEgCIgEAEIgCAFQAAADADADQADADAHAAIAbACQANABAIAGQAHAFAAALQAAAJgGAHQgGAGgKADQgLADgNAAQgSABgLgHgAgaAeQgDAEAAAEQAAAIAEAEQAEAGAHACQAHADAIAAQAJAAAHgDQAIgCAEgDQAEgFAAgFQABgFgFgFQgEgEgMgBIgZgCIgFgBIgEgBIgFAGgAgPg0QgFAFAAALQAAANAGAIQAGAHAIABQAJAAAFgHQAFgGABgLQAAgIgDgGQgDgGgFgFQgFgDgFAAQgJAAgFAHg");
	this.shape_16.setTransform(-3.025,-5.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQADgCABgGIAAgyQAAgJgEgEQgFgFgIAAQgGAAgFADQgHAEgGAHIAAA2QAAAGAEACIAIADIAAADIgnAAIAAgDIAIgDQAEgCAAgGIAAg7QAAgEgCgDQgCgCgFAAIgFAAIAAgDIAagIIADAAIAAAVQAHgKAIgFQAGgGAKAAQAMAAAGAIQAHAHAAANIAAAzQAAAGADACIAIADIAAADg");
	this.shape_17.setTransform(-12.95,-7.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSBBIAAgDIAJgCQADgCAAgGIAAg8QAAgEgCgDQgCgCgFAAIgEAAIAAgCIAZgIIACAAIAABPQAAAGAEACIAIACIAAADgAgHgtQgDgEAAgFQAAgEADgDQAEgDAEAAQAEAAAEADQADADAAAEQAAAFgDAEQgEACgEAAQgEAAgEgCg");
	this.shape_18.setTransform(-20.825,-9.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_19.setTransform(-26.775,-7.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_20.setTransform(-35.075,-7.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPIgEgHQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_21.setTransform(-47.025,-7.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_22.setTransform(-59.325,-7.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgwA8IAAgDIAJgBQAEgBACgDQABgDAAgFIAAhXQAAgIgEgCQgEgEgIAAIAAgCIAyAAQAOAAAKADQALAEAGAIQAGAHAAAMQAAALgGAHQgGAHgLADQgKAEgOAAIgRAAIAAAlQAAAFABADQACADAEABIAIABIAAADgAgPACIAPAAQAPgBAIgGQAIgIAAgMQAAgOgIgHQgIgIgPAAIgPAAg");
	this.shape_23.setTransform(-69.725,-8.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.3,-24.4,154.6,48.9);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOAwIgBgYQgCAHgEAFQgFAGgFADQgGADgHAAQgLAAgGgGQgHgHAAgKQAAgNAJgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgHABgFAEQgFAEgBAGQgBAGADAHIgOAEQgEgJADgJQADgIAKgFQAJgFAMgBQAPABAIAIQAJAJAAAPIAAArQAAAEACACQADADAEAAIAEAAIAAADIgZAHgAAAgBQgNACgGAFQgGAGAAAJQABAIADAEQAFAFAHAAQAFAAAFgDQAFgDADgGQADgGABgIIAAgQg");
	this.shape.setTransform(18,13.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFgBIgEAAIAAgCIAagIIADAAIAAAZQADgLAHgHQAHgGAIgBIADABIAEABIgBAOIgEgBIgGAAQgGAAgGADQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_1.setTransform(9.575,13.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_2.setTransform(1.275,13.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPQgCgFgCgCQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_3.setTransform(-14.875,13.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_4.setTransform(-26.825,13.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQAEgCAAgGIAAgyQAAgIgEgFQgFgFgIAAQgGAAgGAEQgFADgHAHIAAA2QAAAGADACIAJADIAAADIgnAAIAAgDIAJgDQADgCAAgGIAAg7QAAgEgCgDQgDgCgEgBIgFAAIAAgCIAagIIADAAIAAAVQAIgKAHgFQAGgFAJgBQAMAAAHAIQAGAHABANIAAAzQAAAGADACIAIADIAAADg");
	this.shape_5.setTransform(-36.6,13.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AANAwIAAgYQgBAHgFAFQgEAGgFADQgHADgHAAQgLAAgHgGQgGgHgBgKQAAgNAKgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgHABgFAEQgFAEgBAGQgBAGADAHIgNAEQgFgJADgJQADgIAJgFQAKgFAMgBQAOABAJAIQAIAJABAPIAAArQAAAEACACQACADAFAAIAFAAIAAADIgaAHgAAAgBQgNACgFAFQgHAGAAAJQAAAIAFAEQAEAFAIAAQAFAAADgDQAFgDAEgGQAEgGAAgIIAAgQg");
	this.shape_6.setTransform(-50.45,13.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQAEgCAAgGIAAgyQgBgIgDgFQgFgFgIAAQgFAAgHAEQgFADgHAHIAAA2QAAAGADACIAJADIAAADIgnAAIAAgDIAJgDQADgCAAgGIAAg7QAAgEgCgDQgDgCgFgBIgDAAIAAgCIAZgIIADAAIAAAVQAHgKAIgFQAHgFAIgBQAMAAAHAIQAGAHAAANIAAAzQABAGADACIAIADIAAADg");
	this.shape_7.setTransform(-64.85,13.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgSBBIAAgCIAJgEQADgCAAgFIAAg7QAAgFgCgDQgCgCgFAAIgEAAIAAgCIAZgIIACAAIAABPQAAAFAEACIAIAEIAAACgAgHgtQgDgEAAgEQAAgFADgDQAEgDAEAAQAEAAAEADQADADAAAFQAAAEgDAEQgEACgEAAQgEAAgEgCg");
	this.shape_8.setTransform(-72.725,11.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AATBBIgBgWQgEAKgHAGQgHAGgKAAQgKAAgJgGQgIgGgEgKQgFgKAAgNQABgRAFgKQAGgLAJgGQAKgGALAAQAGAAAGAEQAHADADAFIAAgbQAAgEgCgCQgDgDgEAAIgEAAIAAgCIAagIIACAAIAABuQAAAEACACQADADAEAAIAFAAIAAADIgZAHgAgSgSQgFAFgEAIQgDAIAAAKQAAAIABAHQACAHAEAGQACAGAGAEQAEADAIABQAGgBAGgEQAHgFACgIIAAgiQAAgGgDgGQgCgGgGgEQgEgEgIgBQgHAAgGAGg");
	this.shape_9.setTransform(65.6,-9.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_10.setTransform(56.775,-7.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANAwIAAgYQgCAHgEAFQgEAGgGADQgGADgHAAQgLAAgGgGQgHgHgBgKQAAgNAKgHQAKgHAVgEIANgDIAAgGQAAgMgGgHQgFgIgJAAQgIABgEAEQgFAEgBAGQgBAGADAHIgNAEQgFgJADgJQADgIAKgFQAJgFAMgBQAPABAIAIQAIAJABAPIAAArQAAAEACACQADADAEAAIAEAAIAAADIgZAHgAAAgBQgNACgFAFQgHAGAAAJQAAAIAEAEQAFAFAIAAQAFAAAEgDQAEgDAEgGQAEgGAAgIIAAgQg");
	this.shape_11.setTransform(48.9,-7.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPQgCgFgCgCQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_12.setTransform(36.525,-7.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_13.setTransform(25.875,-7.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_14.setTransform(17.225,-7.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgfBBIAAgDQAFAAAEgCQADgCABgGIAAhHIgQAAIAAgFIAQAAIAAgHQAAgLAEgIQAFgGAHgEQAGgEAJAAQAHAAAGACQAFADAEAEIgMAJQgCgFgDgEQgDgDgEgBQgIAAgDAHQgDAGAAALIAAALIAXAAIAAAFIgXAAIAABHQgBAGAEACQAEACAKAAIAAADg");
	this.shape_15.setTransform(9.95,-9.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggA7QgKgFAAgKQAAgGADgEQACgFAEgCQAEgDAFgBQgFgDgCgDQgDgEAAgDQAAgGAEgEQADgEAFgDQgGgFgEgGQgEgGAAgJQAAgJAEgHQAFgHAIgEQAIgEALgBQAIABAHADIAcAAIAAAEIgTAAQAFAFADAFQADAHAAAHQAAAJgEAHQgFAHgIAEQgIAEgKAAIgKgBQgFgBgEgCIgEAEIgCAFQAAADADADQADADAHAAIAbACQANABAIAGQAHAFAAALQAAAJgGAHQgGAGgKADQgLADgNAAQgSABgLgHgAgaAeQgDAEAAAEQAAAIAEAEQAEAGAHACQAHADAIAAQAJAAAHgDQAIgCAEgDQAEgFAAgFQABgFgFgFQgEgEgMgBIgZgCIgFgBIgEgBIgFAGgAgPg0QgFAFAAALQAAANAGAIQAGAHAIABQAJAAAFgHQAFgGABgLQAAgIgDgGQgDgGgFgFQgFgDgFAAQgJAAgFAHg");
	this.shape_16.setTransform(-3.025,-5.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAKAvIAAgDQAFgBADgCQADgCABgGIAAgyQAAgJgEgEQgFgFgIAAQgGAAgFADQgHAEgGAHIAAA2QAAAGAEACIAIADIAAADIgnAAIAAgDIAIgDQAEgCAAgGIAAg7QAAgEgCgDQgCgCgFAAIgFAAIAAgDIAagIIADAAIAAAVQAHgKAIgFQAGgGAKAAQAMAAAGAIQAHAHAAANIAAAzQAAAGADACIAIADIAAADg");
	this.shape_17.setTransform(-12.95,-7.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSBBIAAgDIAJgCQADgCAAgGIAAg8QAAgEgCgDQgCgCgFAAIgEAAIAAgCIAZgIIACAAIAABPQAAAGAEACIAIACIAAADgAgHgtQgDgEAAgFQAAgEADgDQAEgDAEAAQAEAAAEADQADADAAAEQAAAFgDAEQgEACgEAAQgEAAgEgCg");
	this.shape_18.setTransform(-20.825,-9.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgdAvIAAgDIAJgDQAEgCAAgGIAAg7QAAgEgCgDQgDgCgFAAIgEAAIAAgDIAagIIADAAIAAAZQADgMAHgGQAHgHAIAAIADABIAEABIgBAOIgEgBIgGgBQgGAAgGAEQgGAFgDAIIAAAwQAAAGADACQAEACAJABIAAADg");
	this.shape_19.setTransform(-26.775,-7.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgSAqQgKgGgFgLQgEgKgBgNQABgOAFgLQAFgLAKgGQAJgHAMAAQALAAAIAFQAIAFAEAJQAEAJAAAMIg9AAIAAABIAAACQgBAMAEAIQAFAJAHAFQAHAFAKAAQAKAAAGgFQAHgEAEgGIACABQgCAHgFAGQgFAHgIADQgHAEgJAAQgMAAgJgGgAAWgMQAAgIgCgGQgDgHgEgEQgFgFgGAAQgGAAgFAEQgFAEgDAHQgDAGgCAJIAsAAIAAAAg");
	this.shape_20.setTransform(-35.075,-7.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAaAuIgZg8IgYA8IgDAAIghhPIgEgHQgDgDgFAAIAAgCIAmAAIAAACQgGAAgDADQgCACACAFIAXA6IASguIgFgMQgCgFgCgCQgDgDgFAAIAAgCIAlAAIAAACQgGAAgDADQgDACACAFIAXA6IAXg6QABgEgCgDQgCgDgGAAIAAgCIAaAAIAAACQgEAAgDADQgDACgCAFIggBPg");
	this.shape_21.setTransform(-47.025,-7.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgVAqQgKgGgFgKQgFgKAAgOQAAgOAGgLQAFgLAKgGQAJgHAMAAQAMAAAKAGQAJAGAFAKQAFALAAANQAAAOgFALQgFALgKAGQgKAHgMAAQgMAAgJgGgAgOglQgFAFgDAIQgDAJAAALIABAPIAFAPQAEAIAFAEQAGAFAGAAQAIAAAFgFQAGgFADgIQADgJAAgLQAAgHgCgIQgCgIgDgHQgDgHgGgFQgFgEgHgBQgHAAgGAFg");
	this.shape_22.setTransform(-59.325,-7.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgwA8IAAgDIAJgBQAEgBACgDQABgDAAgFIAAhXQAAgIgEgCQgEgEgIAAIAAgCIAyAAQAOAAAKADQALAEAGAIQAGAHAAAMQAAALgGAHQgGAHgLADQgKAEgOAAIgRAAIAAAlQAAAFABADQACADAEABIAIABIAAADgAgPACIAPAAQAPgBAIgGQAIgIAAgMQAAgOgIgHQgIgIgPAAIgPAAg");
	this.shape_23.setTransform(-69.725,-8.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.3,-24.4,154.6,48.9);


// stage content:
(lib.v11PE2026DemandbaseLandingPage300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// RED_BAR
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-162.3,242.5);
	this.instance._off = true;

	this.instance_1 = new lib.Tween8("synched",0);
	this.instance_1.setTransform(150,242.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},9).to({state:[{t:this.instance_1}]},15).wait(97));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({_off:true,x:150},15,cjs.Ease.cubicInOut).wait(97));

	// SUBTITLE
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(104.8,191.05);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween2("synched",0);
	this.instance_3.setTransform(104.8,167.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},59).to({state:[{t:this.instance_3}]},15).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({_off:false},0).to({_off:true,y:167.8,alpha:1},15,cjs.Ease.cubicInOut).wait(47));

	// TITLE
	this.instance_4 = new lib.Tween3("synched",0);
	this.instance_4.setTransform(111.9,135.45);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween4("synched",0);
	this.instance_5.setTransform(111.9,100.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},34).to({state:[{t:this.instance_5}]},15).wait(72));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({_off:false},0).to({_off:true,y:100.2,alpha:1},15,cjs.Ease.cubicInOut).wait(72));

	// CTA
	this.instance_6 = new lib.Tween5("synched",0);
	this.instance_6.setTransform(88.6,245.7);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween6("synched",0);
	this.instance_7.setTransform(88.6,209.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},84).to({state:[{t:this.instance_7}]},14).wait(23));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(84).to({_off:false},0).to({_off:true,y:209.7,alpha:1},14,cjs.Ease.cubicInOut).wait(23));

	// LOGO
	this.Logo__300x250_ = new lib.StackedWhiteRGB();
	this.Logo__300x250_.name = "Logo__300x250_";
	this.Logo__300x250_.setTransform(69.95,38.75,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.Logo__300x250_).wait(121));

	// SHADOW
	this.instance_8 = new lib.Rectangle();
	this.instance_8.setTransform(117.5,117.5,1,1,0,0,0,117.5,117.5);
	this.instance_8.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(121));

	// SHADOW_copy
	this.instance_9 = new lib.Rectangle();
	this.instance_9.setTransform(117.5,117.5,1,1,0,0,0,117.5,117.5);
	this.instance_9.alpha = 0.2383;
	this.instance_9.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(121));

	// BACKGROUND_FOREGROUND
	this.instance_10 = new lib.Tween9("synched",0);
	this.instance_10.setTransform(205,124);

	this.instance_11 = new lib.Tween10("synched",0);
	this.instance_11.setTransform(239.5,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true,x:239.5},120).wait(1));

	// BACKGROUND_MOUNTAINS
	this.instance_12 = new lib.Tween11("synched",0);
	this.instance_12.setTransform(236.65,128.5,1.2978,1.2977,0,0,0,-0.3,-0.4);

	this.instance_13 = new lib.Tween12("synched",0);
	this.instance_13.setTransform(239,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:239,y:124},120).wait(1));

	// BACKGROUND_SKY
	this.instance_14 = new lib.Tween13("synched",0);
	this.instance_14.setTransform(240.9,124);

	this.instance_15 = new lib.Tween14("synched",0);
	this.instance_15.setTransform(239.5,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_15}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true,x:239.5},120).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/1FMAx/AAAMAAAAqLMgx/AAAg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape_1.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(121));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-162.3,84,712.2,215);
// library properties:
lib.properties = {
	id: '54E46DF2D2699248BD4F468983A95DAC',
	width: 300,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1.png", id:"v1_1_PE2026_Demandbase_LandingPage_300x250_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['54E46DF2D2699248BD4F468983A95DAC'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;