(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ConsumerProducts_Demandbase_970x250_atlas_1", frames: [[0,0,2022,521]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v1ConcumerProductsPadiDemandbasestatics_970250 = function() {
	this.initialize(ss["ConsumerProducts_Demandbase_970x250_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v1ConcumerProductsPadiDemandbasestatics_970250();
	this.instance.setTransform(-492.85,-127,0.4875,0.4875);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-492.8,-127,985.7,254);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("EgnMAQaMAAAggzMBOZAAAMAAAAgzg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250.9,-105,501.8,210);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCCGIAAAuIgOAAIAAhQIA0AwIAAgvIAOAAIAABRgAkPCJIgJArIgOAAIAThQIAdA1IAdg1IAVBQIgQAAIgJgrIgZAtgAl+CrQgMgMABgSQgBgSAMgMQANgMAQAAQATAAAMAMQALALAAATQAAARgMAMQgMAMgSAAQgRAAgMgLgAlzB5QgIAIAAAMQAAAMAIAIQAIAIAKAAQAMAAAHgJQAIgIAAgLQAAgNgHgIQgIgIgMAAQgKAAgIAJgApPCwQgIgGAAgKQAAgOARgJQgKgKABgIQAAgJAGgFQAGgGALAAQAKAAAGAFQAGAFABAJQAAAMgTAJIANAQIAIgMIAOAAIgPAUIAQARIgQAAIgHgIQgKAKgMAAQgMAAgGgGgApLCfQAAAGAFADQAEAEAGAAQAKAAAEgIIgRgUIAAAAQgMAGAAAJgApEB3QAAAGAJAHQAOgGAAgIQAAgJgLAAQgMAAAAAKgAnZCqQgLgLAAgSQAAgSAMgMQAMgMARAAQATAAANAPIABABIgMAJIAAAAQgIgMgNAAQgLAAgIAJQgHAIAAAMQAAAMAHAIQAHAIAMAAQAOAAAHgMIAAgBIAMAKIgBAAQgMAQgUAAQgSAAgMgMgAEiB/Qg2g1ABhKQgBhLA2g1QA1g1BLAAQANAAAQACIgPAUIgOAAQg/AAgtArQgsAsgBA+QABA9AsArQAtAsA/AAQBAAAAsgsQAtgrAAg9QABgvgcgmQgagmgsgQIgFgZQA5ARAkAvQAmAxAAA9QAABKg2A1Qg1A1hLAAQhLAAg1g1gABhC0IAAghIgdguIARAAIATAgIAUggIARAAIgdAuIAAAhgAgzC0IgIgRIgeAAIgIARIgPAAIAmhQIAnBQgAhUCXIAUAAIgKgXgAiqC0IAAhPIASAAQAhAAAAAZQAAAMgKAHQgIAGgPAAIgEAAIAAAdgAicCKIAEABQARAAABgNQgBgNgRAAIgEAAgAgEhIIAAB5IglAAIAAjSICIB+IAAh7IAmAAIAADUgAiqAxIAAjPIAnAAIAADPgAkJAxIgTgsIhQAAIgTAsIgoAAIBljSIBlDSgAlcgcIAyAAIgYg7gApQAxIAAjPIAxAAQBPAAAAA2QAAAPgJALQgHALgMAGQAoAOgBAlQABAcgVAPQgVAQgoAAgAoqARIASAAQArAAAAgaQAAgQgLgHQgLgGgVAAIgSAAgAoqhGIAJAAQAVAAAKgGQALgHAAgPQAAgPgLgHQgKgGgWAAIgIAAgAFlgUIBdh3IAgCTg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape.setTransform(67.825,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVBAIgegxIgNAAIAAAxIgcAAIAAh/IAtAAQAPAAALAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAhA2gAgWgEIARAAQAKAAAFgFQAGgEgBgKIAAAAQABgKgGgEQgFgEgKAAIgRAAg");
	this.shape_1.setTransform(56.35,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_2.setTransform(41.575,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_3.setTransform(28.225,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_4.setTransform(16.325,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAhA2gAgWgEIAQAAQALAAAFgFQAGgEgBgKIAAAAQABgKgGgEQgFgEgLAAIgQAAg");
	this.shape_5.setTransform(4.25,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_6.setTransform(-12.975,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_7.setTransform(-26.4,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_8.setTransform(-39.525,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-55.975,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_10.setTransform(-67.175,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggA6QgPgJgHgOQgHgPgBgTIAAgBQAAgTAJgPQAIgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAIAKACAQIgdAAQgCgMgHgFQgIgGgLABQgKAAgIAFQgIAFgEAKQgEAJgBANIAAABQAAANAFAJQADAKAIAFQAIAGALAAQALAAAHgEQAGgEAEgGQADgGABgHIgeAAIAAgVIA6AAIAAANQAAARgHANQgHANgNAHQgOAHgTAAQgUAAgPgIg");
	this.shape_11.setTransform(-80.8,1.6727);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Agng2IBPA2IhPA3g");
	this.shape_12.setTransform(85.825,0.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.8,-14.2,179.7,28.4);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgdBUQgMgEgJgJQgJgJgCgPIAYgIQABAOAFAJQAGAKAJAEQAJAGAJAAQARgBAJgMQAJgMAAgUQAAgWgMgNQgLgNgUAAQgLAAgKAEQgJADgJAGIgDgBIAQhYIBVAAIAAAUIhSAAIgKA7QAJgIAKgFQAMgFAMAAQARAAANAIQANAHAIAMQAHAMAAARQAAARgHANQgIAOgPAHQgOAIgUAAQgOAAgNgFg");
	this.shape.setTransform(147.25,2.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6BZIAAgEIArgwIATgXQAKgMAGgMQAGgNAAgPQABgPgKgJQgJgJgOgBQgJAAgJAEQgIAEgGAHQgIAHgDAKIgDgBQACgNAHgKQAIgLALgGQAMgGAPgBQAXABAMAMQANANABAVQgBAUgKARQgLAPgTASIgtAnIA4AAQALABAHgCQAFgCAFgGQADgGADgLIAEAAIgIAvg");
	this.shape_1.setTransform(133.35,2.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkBOQgPgMgIgUQgHgVAAgZQAAgYAHgVQAIgUAPgNQAPgMAVAAQAWAAAPAMQAPANAIAUQAIAVAAAYQAAAZgIAVQgIAUgPAMQgPAMgWABQgVgBgPgMgAgXhJQgJAJgFARQgEAQAAAWQAAAOACAQQACAQAGAOQAFAOAJAJQAJAJAMAAQALAAAIgJQAJgJAGgRQAEgQAAgWQABgNgDgQQgCgQgGgOQgFgPgJgJQgJgJgMgBQgLABgJAJg");
	this.shape_2.setTransform(118.7,2.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag6BZIAAgEIAsgwIASgXQAKgMAGgMQAHgNAAgPQgBgPgIgJQgKgJgOgBQgJAAgIAEQgJAEgHAHQgGAHgEAKIgCgBQABgNAIgKQAHgLAMgGQALgGAPgBQAXABANAMQANANAAAVQgBAUgKARQgKAPgUASIgsAnIA3AAQALABAGgCQAGgCAEgGQAEgGADgLIADAAIgHAvg");
	this.shape_3.setTransform(103.6,2.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqBDIAAgDQAIgCAFgDQAFgDAAgIIAAhXQAAgGgDgDQgDgDgHgBIgHAAIAAgEIAmgKIAEAAIAAAkQAGgSAJgJQAKgJALAAIAFAAIAGACIgCAVIgGgCIgHgCQgKABgJAFQgIAHgFALIAABHQAAAIAFADQAGADANACIAAADg");
	this.shape_4.setTransform(85.925,4.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggA8QgMgIgIgPQgHgPgBgTQABgVAHgQQAIgQAOgJQAOgJASAAQARAAANAJQAOAIAIAPQAHAPAAATQAAAVgIAQQgIAQgOAJQgOAJgRAAQgSAAgOgJgAgVg2QgHAHgEAMQgEAMgBAQQABALACALQACAMAEALQAFAKAJAHQAHAGAKABQALgBAIgGQAIgHAEgNQAEgMAAgQQAAgKgCgMQgCgMgFgKQgFgKgIgHQgIgGgKgBQgKAAgJAHg");
	this.shape_5.setTransform(73.45,4.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgtBeIAAgEQAIgBAFgDQAFgDAAgJIAAhmIgWAAIAAgIIAWAAIAAgKQABgPAGgLQAGgKAKgGQAKgFANAAQAKAAAIADQAIADAFAHIgRANQgCgIgFgFQgEgFgGgBQgLABgFAJQgFAKAAAPIAAAPIAjAAIAAAIIgjAAIAABmQAAAJAFADQAGADANABIAAAEg");
	this.shape_6.setTransform(62.925,1.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgTBBQgKgEgIgHQgIgGgEgJIATgJQAEAOAJAJQAJAIAMABQAMgBAIgGQAHgGABgLQgBgMgIgGQgHgGgMgEIgVgIQgLgDgIgIQgIgIAAgNQAAgRAMgLQAMgKAUAAQALAAAJADQAKADAHAGQAHAGADAIIgSAIQgEgMgIgHQgIgIgKAAQgMAAgHAGQgGAGAAAKQAAAKAHAGQAIAFALAEIAWAIQALAFAIAHQAIAIAAAOQABAMgGAJQgGAKgLAFQgLAFgOAAQgKAAgLgEg");
	this.shape_7.setTransform(45.0019,4.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbA8QgNgJgHgPQgHgOgBgTQABgVAHgQQAIgQAOgJQAOgJARAAQAQAAALAHQALAIAGAMQAGANAAARIhYAAIAAACIAAADQgBARAGANQAGAMALAHQAKAHAPAAQAOAAAJgGQAKgHAFgJIADACQgDALgHAJQgHAIgLAGQgLAFgNAAQgSAAgNgJgAAggSQAAgLgEgKQgDgJgHgGQgGgHgKAAQgIAAgHAGQgHAFgFAKQgFAKgBAMIA/AAIAAAAg");
	this.shape_8.setTransform(32.275,4.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaBeIAAgDQAIgBAEgEQAGgDAAgIIAAhXQgBgGgDgEQgDgDgHAAIgGAAIAAgEIAlgLIADAAIAABzQABAIAEADQAFAEAHABIAAADgAgJhCQgGgFAAgHQAAgGAGgEQAEgFAGAAQAHAAAEAFQAFAEAAAGQAAAHgFAFQgEAEgHAAQgGAAgEgEg");
	this.shape_9.setTransform(22,1.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AguBWQgPgIgBgPQABgIADgGQAEgGAGgEQAGgEAGgCQgHgEgDgFQgDgFAAgFQAAgIAEgGQAFgHAIgEQgKgGgFgKQgGgJAAgMQAAgNAGgLQAHgKAMgGQALgFAQAAQAMgBAKAEIApAAIAAAHIgcAAQAIAGAEAKQAFAIAAALQAAANgHAJQgGALgMAFQgMAGgPABQgHgBgHgBQgHgBgHgEQgDAEgCAEQgDACAAAEQAAAFAFAEQAEAFAKAAIAoADQASABALAIQALAIABAPQgBANgIAKQgJAIgQAFQgPAGgTAAQgaAAgPgJgAgnArQgEAFAAAHQAAAKAGAIQAGAHAKAEQAKAEAMAAQANAAALgDQAKgEAHgFQAGgHAAgHQAAgJgGgFQgHgHgQgBIgmgDIgHgBIgGgBIgHAIgAgXhNQgHAKAAAOQAAATAIAMQAJAKANABQANAAAHgJQAIgKAAgPQAAgMgEgJQgEgJgHgGQgHgFgIAAQgNAAgIAJg");
	this.shape_10.setTransform(11.425,7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbA8QgNgJgHgPQgHgOgBgTQABgVAHgQQAIgQAOgJQAOgJARAAQAQAAALAHQALAIAGAMQAGANAAARIhYAAIAAACIAAADQgBARAGANQAGAMALAHQAKAHAPAAQAOAAAJgGQAKgHAFgJIADACQgDALgHAJQgHAIgLAGQgLAFgNAAQgSAAgNgJgAAggSQAAgLgEgKQgDgJgHgGQgGgHgKAAQgIAAgHAGQgHAFgFAKQgFAKgBAMIA/AAIAAAAg");
	this.shape_11.setTransform(-2.225,4.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOBIQgIgJAAgRIAAhbIgOAAIAAgEIAggfIAEAAIAAAbIAlAAIAAAIIglAAIAABaQgBALAFAGQAFAGAKAAQAHAAADgCIAHgEIABABQgBAEgEAEQgDAEgHADQgFADgJAAQgNAAgJgJg");
	this.shape_12.setTransform(-13.2,3.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AATBFIgBgjQgCAKgGAIQgHAHgIAFQgJAFgKAAQgPgBgKgIQgKgJAAgPQAAgTAOgLQAOgKAegFIATgFIAAgIQAAgSgIgLQgIgKgNAAQgLAAgGAHQgHAFgCAJQgBAJAEAKIgTAGQgHgOAFgMQAEgMANgIQANgHATAAQAVAAAMANQANAMAAAVIAAA/QAAAGADAEQAEADAGAAIAHAAIAAAEIglALgAAAgCQgTACgJAJQgJAIAAANQABALAGAGQAGAIALgBQAHAAAHgEQAHgFAFgIQAFgIAAgLIAAgYg");
	this.shape_13.setTransform(-23.8259,4.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqBDIAAgDQAIgCAFgDQAFgDAAgIIAAhXQAAgGgDgDQgDgDgHgBIgHAAIAAgEIAmgKIAEAAIAAAkQAGgSAJgJQAKgJALAAIAFAAIAGACIgCAVIgGgCIgHgCQgKABgJAFQgIAHgFALIAABHQAAAIAFADQAGADANACIAAADg");
	this.shape_14.setTransform(-36.075,4.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgOBIQgIgJAAgRIAAhbIgOAAIAAgEIAggfIAEAAIAAAbIAlAAIAAAIIglAAIAABaQgBALAFAGQAFAGAKAAQAHAAADgCIAHgEIABABQgBAEgEAEQgDAEgHADQgFADgJAAQgNAAgJgJg");
	this.shape_15.setTransform(-45.6,3.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgTBBQgKgEgIgHQgIgGgEgJIATgJQAEAOAJAJQAJAIAMABQAMgBAIgGQAHgGABgLQgBgMgIgGQgHgGgMgEIgVgIQgLgDgIgIQgIgIAAgNQAAgRAMgLQAMgKAUAAQALAAAJADQAKADAHAGQAHAGADAIIgSAIQgEgMgIgHQgIgIgKAAQgMAAgHAGQgGAGAAAKQAAAKAHAGQAIAFALAEIAWAIQALAFAIAHQAIAIAAAOQABAMgGAJQgGAKgLAFQgLAFgOAAQgKAAgLgEg");
	this.shape_16.setTransform(-56.1481,4.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag4BVQgMgGgHgLQgHgLAAgOQAAgTALgNQALgMATgFQgGgGgFgHQgFgHgDgHQgDgIAAgJQAAgSAMgLQANgLAVAAQAOAAAJAFQAKAFAFAIQAFAIABAKQAAANgLALQgKALgUAIIAwA2QAHgKADgOQADgOAAgQIAWADQgFAQgIAPQgIAOgJAMIARASQAHAJAHADQAHAEAGAAIAAAEIgqAAIgSgUQgKALgNAGQgMAHgOAAQgRAAgNgGgAg1AOQgGAKAAAMQAAAMAFAKQAFAJAJAGQAJAFAOAAQAKAAAIgEQAKgEAIgIIg4g/QgKAFgGAKgAgihMQgGAHAAAMQAAANAGAJQAHAKAIAJQAMgHAHgJQAFgJAAgMQAAgNgGgIQgGgIgMgBQgJABgGAGg");
	this.shape_17.setTransform(-76.775,2.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgTBBQgKgEgIgHQgIgGgEgJIATgJQAEAOAJAJQAJAIAMABQAMgBAIgGQAHgGABgLQgBgMgIgGQgHgGgMgEIgVgIQgLgDgIgIQgIgIAAgNQAAgRAMgLQAMgKAUAAQALAAAJADQAKADAHAGQAHAGADAIIgSAIQgEgMgIgHQgIgIgKAAQgMAAgHAGQgGAGAAAKQAAAKAHAGQAIAFALAEIAWAIQALAFAIAHQAIAIAAAOQABAMgGAJQgGAKgLAFQgLAFgOAAQgKAAgLgEg");
	this.shape_18.setTransform(-98.3481,4.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAbBeIgBghQgFAPgLAJQgKAJgOAAQgQgBgMgIQgMgJgGgOQgGgPgBgSQABgYAIgQQAIgQAOgIQANgIAQAAQAKAAAJAEQAJAFAFAHIAAgmQAAgHgDgDQgDgDgHAAIgGAAIAAgEIAlgLIAEAAIAACfQAAAGADAEQAEADAHAAIAGAAIAAAEIglALgAgagbQgIAHgFAMQgEAMAAAPQAAALACAKQACALAEAIQAFAJAHAFQAHAFAKABQALgBAIgGQAJgHAEgMIAAgxQAAgIgDgJQgEgKgIgGQgIgGgLAAQgKAAgIAIg");
	this.shape_19.setTransform(-111.175,1.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAPBDIAAgDQAHgBAFgEQAFgDAAgIIAAhJQAAgMgHgHQgGgHgLAAQgJAAgIAEQgJAGgKALIAABOQABAIAEADQAFAEAIABIAAADIg5AAIAAgDQAIgBAFgEQAFgDAAgIIAAhXQAAgGgEgDQgDgDgHgBIgGAAIAAgEIAmgKIADAAIAAAeQALgPALgIQAKgHANAAQARAAAKAKQAJAKAAAUIAABKQAAAIAFADQAFAEAHABIAAADg");
	this.shape_20.setTransform(-126.475,4.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgbA8QgNgJgHgPQgHgOgBgTQABgVAHgQQAIgQAOgJQAOgJARAAQAQAAALAHQALAIAGAMQAGANAAARIhYAAIAAACIAAADQgBARAGANQAGAMALAHQAKAHAPAAQAOAAAJgGQAKgHAFgJIADACQgDALgHAJQgHAIgLAGQgLAFgNAAQgSAAgNgJgAAggSQAAgLgEgKQgDgJgHgGQgGgHgKAAQgIAAgHAGQgHAFgFAKQgFAKgBAMIA/AAIAAAAg");
	this.shape_21.setTransform(-140.975,4.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgqBDIAAgDQAIgCAFgDQAFgDAAgIIAAhXQAAgGgDgDQgDgDgHgBIgHAAIAAgEIAmgKIAEAAIAAAkQAGgSAJgJQAKgJALAAIAFAAIAGACIgCAVIgGgCIgHgCQgKABgJAFQgIAHgFALIAABHQAAAIAFADQAGADANACIAAADg");
	this.shape_22.setTransform(-152.575,4.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNBIQgJgJAAgRIAAhbIgPAAIAAgEIAhgfIADAAIAAAbIAmAAIAAAIIgmAAIAABaQABALAEAGQAFAGAKAAQAGAAAFgCIAGgEIACABQgCAEgEAEQgEAEgFADQgHADgIAAQgOAAgHgJg");
	this.shape_23.setTransform(-162.1,3.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgvBPQgTgMgKgTQgLgUAAgYQAAgbAKgVQALgWAUgMQAUgMAaAAQAQAAAOAFQAOAFAJAIQAJAJAEALIgXAIQgEgSgNgKQgNgLgQAAQgRAAgOALQgNAKgHASQgIASAAAYQAAAXAJATQAJATAPAMQAPAMATAAQAKAAAJgDQAKgDAHgHIAAgtQABgLgGgFQgFgFgOgBIAAgDIBHAAIAAADQgMABgGAFQgFAGAAAKIAAAiQgGAJgKAHQgKAHgNAEQgOAEgPABQgZgBgTgLg");
	this.shape_24.setTransform(-182.075,2.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AhFBXIAAgEIAMgCQAFgCADgEQADgEAAgHIAAh/QAAgLgGgEQgGgEgLAAIAAgEIBIAAQAUAAAPAFQAPAFAJALQAIALAAARQAAAQgIALQgJAKgPAFQgPAFgUAAIgZAAIAAA2QgBAHADAEQADAEAFACIAMACIAAAEgAgWADIAWAAQAWAAALgLQAMgLAAgSQAAgTgMgLQgLgLgWgBIgWAAg");
	this.shape_25.setTransform(-199.9,2.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgjBPQgTgLgKgUQgLgTAAgZQAAgbALgVQAJgVAUgNQASgMAaAAQAYAAAQAKQARAKAGASIgYAIQgDgSgMgKQgMgLgPAAQgRAAgMAKQgNAKgHARQgHARAAAXQAAAXAIARQAJASAPAJQAPAKATAAQAUAAAQgKQAOgLAGgRIAEAAQgHAbgSAPQgTAPgaABQgYgBgRgLg");
	this.shape_26.setTransform(-216.5,2.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-227.2,-19.3,454.5,38.6);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqBDQgKgEgGgJQgHgJAAgOQAAgYATgKQATgKAhAAIAOAAIAAgDQAAgKgEgGQgEgGgKAAQgJABgEAEQgEAFgBAGIgsAAQACgQAIgLQAIgLAPgFQAOgFARAAQATAAAOAFQAOAFAHAMQAIALAAASIAABXIgtAAIAAgQQgFAIgKAGQgJAFgQAAQgMAAgLgEgAgMAQQgHADAAAIQAAAGAEAEQAEADAIAAQAKAAAGgFQAGgFABgJIAAgJIgNAAQgNAAgGAEg");
	this.shape.setTransform(173.175,4.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsBFIAAiHIAuAAIAAAbQAGgPALgHQALgHAPAAIAAAsQgVgBgLAHQgLAHAAAQIAABAg");
	this.shape_1.setTransform(161.025,4.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_2.setTransform(147.375,4.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaBdIAAi5IA1AAIAAC5g");
	this.shape_3.setTransform(129.925,2.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAlBdIgKgjIg8AAIgKAjIgyAAIA8i5IBEAAIA7C5gAARAWIgThHIgVBHIAoAAg");
	this.shape_4.setTransform(115.675,2.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAVBGIAAhOQAAgMgEgFQgFgGgKAAQgJAAgHAGQgGAHAAANIAABLIgvAAIAAiHIAvAAIAAAWQAFgLALgHQALgIAQAAQAVAAAMANQAMAMAAAaIAABYg");
	this.shape_5.setTransform(92.8,4.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_6.setTransform(76.875,4.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0BSQgSgOgDgXIAvAAQABAHAGAFQAFAFANAAQAOAAAHgIQAHgHAAgOIAAgUQgEAGgGAGQgFAGgJADQgHADgKABQgQAAgNgIQgOgHgHgPQgIgOAAgUIAAgDQAAgTAIgQQAHgOAOgIQANgIAQAAQAPAAAKAGQAKAHAGAKIAAgUIAvAAIAAB8QgBAfgTAPQgTAQgkAAQgjAAgQgNgAgRgzQgIAIABAOIAAADQgBAOAIAIQAGAHAMABQANgBAHgHQAHgIAAgOIAAgDQAAgOgHgIQgHgIgMAAQgNAAgGAIg");
	this.shape_7.setTransform(60.4,7.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_8.setTransform(39.575,4.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAWBiIAAhPQgBgMgEgFQgFgFgKAAQgJAAgHAFQgGAHAAANIAABMIgvAAIAAjDIAvAAIAABSQAFgLAMgHQAKgIARABQATAAANAMQALAMABAZIAABZg");
	this.shape_9.setTransform(23.75,1.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgPBIQgNgLAAgYIAAg7IgQAAIAAggIAQAAIAAgdIAuAAIAAAdIAbAAIAAAgIgbAAIAAA3QAAAHAEAEQADADAHAAIAHgBIAGgBIAAAjIgLADIgOABQgXAAgMgMg");
	this.shape_10.setTransform(10.35,3.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAWBGIAAhOQgBgMgEgFQgFgGgKAAQgKAAgGAGQgGAHAAANIAABLIgvAAIAAiHIAvAAIAAAWQAFgLALgHQALgIAQAAQAVAAAMANQAMAMAAAaIAABYg");
	this.shape_11.setTransform(-7.65,4.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXBjIAAiIIAuAAIAACIgAgRg5QgIgFABgMQgBgKAIgHQAGgGALAAQALAAAHAGQAHAHABAKQgBAMgHAFQgHAIgLgBQgLABgGgIg");
	this.shape_12.setTransform(-19.6,1.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_13.setTransform(-36.325,4.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiBAQgQgIgKgQQgJgPAAgXIAAgCQAAgWAKgQQAKgQAQgIQARgIASAAQASgBAOAGQAPAFAJANQAKAMABAVIgsAAQgBgKgFgFQgGgFgJAAQgMAAgHAJQgGAIAAARIAAABQAAASAGAJQAHAJANAAQAJAAAGgFQAHgGABgLIAqAAQgBARgIANQgHAMgQAHQgPAHgWAAQgTAAgQgHg");
	this.shape_14.setTransform(-51.6,4.9229);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAVBGIAAhOQAAgMgEgFQgFgGgKAAQgJAAgHAGQgGAHAAANIAABLIgvAAIAAiHIAvAAIAAAWQAFgLALgHQALgIAQAAQAVAAAMANQAMAMAAAaIAABYg");
	this.shape_15.setTransform(-67.3,4.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgqBDQgKgEgGgJQgHgJAAgOQAAgYATgKQATgKAhAAIAOAAIAAgDQAAgKgEgGQgEgGgKAAQgJABgEAEQgEAFgBAGIgsAAQACgQAIgLQAIgLAPgFQAOgFARAAQATAAAOAFQAOAFAHAMQAIALAAASIAABXIgtAAIAAgQQgFAIgKAGQgJAFgQAAQgMAAgLgEgAgMAQQgHADAAAIQAAAGAEAEQAEADAIAAQAKAAAGgFQAGgFABgJIAAgJIgNAAQgNAAgGAEg");
	this.shape_16.setTransform(-83.325,4.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgYBEIgyiHIAxAAIAcBXIAchXIAsAAIgyCHg");
	this.shape_17.setTransform(-97.625,4.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_18.setTransform(-112.675,4.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgWBiIAAjDIAtAAIAADDg");
	this.shape_19.setTransform(-124.275,1.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_20.setTransform(-135.875,4.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgsBFIAAiHIAuAAIAAAbQAGgPALgHQALgHAPAAIAAAsQgVgBgLAHQgLAHAAAQIAABAg");
	this.shape_21.setTransform(-148.775,4.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AA9BGIAAhQQAAgLgEgFQgFgFgIAAQgKAAgFAGQgGAGAAALIAABOIgtAAIAAhQQAAgLgEgFQgGgFgIAAQgJAAgGAGQgFAGAAALIAABOIgvAAIAAiHIAvAAIAAAUQAGgKAKgHQAKgHARAAQANAAAIAGQAJAGAGALQAIgMAMgGQAMgFANAAQAMAAAKAGQAKAFAGAMQAGALAAARIAABYg");
	this.shape_22.setTransform(-171.8,4.7729);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgWBjIAAiIIAtAAIAACIgAgSg5QgGgFAAgMQAAgKAGgHQAIgGAKAAQALAAAHAGQAHAHAAAKQAAAMgHAFQgHAIgLgBQgKABgIgIg");
	this.shape_23.setTransform(-187.75,1.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgqBDQgKgEgGgJQgHgJAAgOQAAgYATgKQATgKAhAAIAOAAIAAgDQAAgKgEgGQgEgGgKAAQgJABgEAEQgEAFgBAGIgsAAQACgQAIgLQAIgLAPgFQAOgFARAAQATAAAOAFQAOAFAHAMQAIALAAASIAABXIgtAAIAAgQQgFAIgKAGQgJAFgQAAQgMAAgLgEgAgMAQQgHADAAAIQAAAGAEAEQAEADAIAAQAKAAAGgFQAGgFABgJIAAgJIgNAAQgNAAgGAEg");
	this.shape_24.setTransform(-199.475,4.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgWBiIAAjDIAtAAIAADDg");
	this.shape_25.setTransform(-210.475,1.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgiBAQgQgIgKgQQgJgPAAgXIAAgCQAAgWAKgQQAKgQAQgIQARgIASAAQASgBAOAGQAOAFAKANQAKAMABAVIgrAAQgCgKgFgFQgGgFgKAAQgLAAgHAJQgGAIAAARIAAABQAAASAGAJQAHAJANAAQAJAAAGgFQAHgGABgLIAqAAQgBARgHANQgJAMgPAHQgOAHgXAAQgTAAgQgHg");
	this.shape_26.setTransform(-221.8,4.9229);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgiA/QgRgIgKgPQgJgQAAgWIAAgCQAAgVAKgQQAJgQARgJQARgIATAAQATAAAQAHQAPAHAKAQQAJAPAAAZIAAALIheAAQABAOAHAHQAIAHALAAQAMAAAFgEQAGgFABgHIArAAQgDAXgRANQgSAMgeAAQgVAAgQgIgAAagOQAAgMgGgHQgGgHgMAAQgJAAgHAHQgHAHgCAMIAxAAIAAAAg");
	this.shape_27.setTransform(-237.225,4.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAXBdIgkhCIgNAAIAABCIg1AAIAAi5IBJAAQAkAAATAPQAUAPAAAdIAAABQgBAUgJAMQgJALgPAFIAtBNgAgagHIARAAQANAAAHgGQAGgGAAgLIAAgBQAAgLgHgFQgGgFgMAAIgSAAg");
	this.shape_28.setTransform(-252.675,2.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-264.4,-19.8,528.9,39.6);


// stage content:
(lib.ConsumerProductsDemandbase970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// General_Headline
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(302.4,154);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({y:113.8,alpha:1},15,cjs.Ease.cubicInOut).wait(87));

	// General_Subheadline
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(265.75,193.05);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).to({y:148.8,alpha:1},15,cjs.Ease.cubicInOut).wait(62));

	// CTA
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(126.9,235.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({y:202.25,alpha:1},15,cjs.Ease.cubicInOut).wait(37));

	// Bain_Logo
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(100,56.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(121));

	// Red_Box
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(20.1,125.1,1.9715,1,0,0,0,-250.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:-250.9,regY:0,scaleX:1,x:19.95,y:125},19,cjs.Ease.cubicInOut).wait(102));

	// Background
	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(485.85,125,1.2162,1.2162);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:1,scaleY:1},120).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(371.5,95.6,713.9000000000001,183.9);
// library properties:
lib.properties = {
	id: 'FA798B93D997B944B314561821B1D0E7',
	width: 970,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"ConsumerProducts_Demandbase_970x250_atlas_1.jpg", id:"ConsumerProducts_Demandbase_970x250_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FA798B93D997B944B314561821B1D0E7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;