(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1", frames: [[0,238,824,117],[0,0,825,117],[0,119,825,117]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset7 = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset8 = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset9 = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Tween16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AghBBQgOgJgGgQQgHgQAAgUIAAgEQABgXAIgQQAIgQAPgJQAOgJASAAQAYAAAOALQANAKADAVIgmAAQgBgFgDgDQgDgDgIgBQgLABgGAJQgGAKgBASQAFgHAIgFQAGgEANAAQAOAAAKAFQALAFAGAKQAHAJAAAPQAAAQgHALQgHALgNAGQgNAHgTAAQgVgBgOgIgAgLAJQgFAGAAAIQAAAKAFAGQAFAGAIAAQAJgBAFgFQAFgGAAgJQAAgJgFgGQgFgGgJAAQgIAAgFAGg");
	this.shape.setTransform(159.675,1.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BJIAAgGIAzg2QAKgLAGgIQAGgKAAgIQAAgIgEgFQgDgEgIAAQgGAAgFAFQgFAGgBAMIglAAQAAgbAQgNQAPgOAZAAQASABALAFQAMAGAGALQAHAJgBANQAAAPgHAMQgHALgNALIgTAUIAvAAIAAAfg");
	this.shape_1.setTransform(146.55,1.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiBBQgPgIgIgQQgIgQAAgWIAAgFQAAgXAJgQQAIgPAQgIQAOgJASAAQATAAAPAIQAPAIAJAPQAIAQAAAXIAAAFQAAAWgIAQQgIARgPAIQgPAJgUAAQgUAAgOgJgAgRggQgHAKAAAUIAAAFQAAAUAHAJQAGAKAMAAQAMAAAHgKQAFgKAAgUIAAgEQAAgUgGgKQgGgKgNAAQgMAAgFAKg");
	this.shape_2.setTransform(133.3,1.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag5BJIAAgGIAzg2QAJgLAHgIQAGgKAAgIQAAgIgDgFQgEgEgIAAQgGAAgGAFQgEAGgBAMIgmAAQACgbAOgNQAQgOAZAAQASABALAFQANAGAFALQAHAJAAANQAAAPgIAMQgHALgMALIgUAUIAwAAIAAAfg");
	this.shape_3.setTransform(119.7,1.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_4.setTransform(105.775,2.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiA1IAAhoIAjAAIAAAVQAFgLAIgGQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_5.setTransform(97.875,3.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAwQgNgFgIgNQgHgMAAgQIAAgCQAAgQAHgMQAIgNANgGQANgHAPAAQAQAAANAGQANAHAIAMQAHAMAAARIAAABQAAAQgIAMQgHANgNAGQgNAHgQAAQgPAAgNgHgAgOgUQgGAGAAAOIAAABQAAANAGAHQAFAIAJAAQAKgBAFgHQAGgHAAgNIAAgBQAAgNgFgHQgGgHgKAAQgJAAgFAHg");
	this.shape_6.setTransform(87.125,3.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag3BHIAAiKIAkAAIAAAPQAEgIAIgFQAHgFAMAAQANAAAKAGQAKAGAFAMQAGAMAAASIAAACQAAARgGAMQgGAMgJAGQgKAGgNAAQgMgBgHgEQgIgFgEgIIAAAygAgPgkQgFAHAAANIAAABQAAAOAFAGQAGAGAJAAQAKAAAFgHQAFgFAAgNIAAgCQAAgOgFgGQgGgHgJAAQgJAAgGAHg");
	this.shape_7.setTransform(74.725,5.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgEAAgFIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_8.setTransform(62.075,3.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASBIIgcgzIgKAAIAAAzIgoAAIAAiOIA4AAQAbAAAPALQAPAMAAAWIAAABQAAAPgIAJQgHAIgLAEIAiA8gAgUgFIAOAAQAJAAAFgFQAFgEAAgJIAAAAQAAgJgFgEQgFgEgJAAIgOAAg");
	this.shape_9.setTransform(50.175,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AggBGIASguIgqhdIAnAAIAUA4IAUg4IAiAAIg4CLg");
	this.shape_10.setTransform(32.825,5.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_11.setTransform(22.875,2.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgFgFAAgIQAAgIAFgFQAFgGAIAAQAJAAAFAGQAGAFgBAIQABAIgGAFQgFAFgJAAQgIAAgFgFg");
	this.shape_12.setTransform(16.25,1.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgiAxQgIgEgEgJQgFgIAAgNIAAhEIAkAAIAAA+QAAAJADAEQADAFAJgBQAGAAAFgEQAFgGAAgKIAAg7IAkAAIAABoIgkAAIAAgQQgEAIgIAFQgHAFgNAAQgKABgIgFg");
	this.shape_13.setTransform(7.05,3.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAUBHIAAgzQgEAIgIAFQgIAFgLABQgNAAgKgGQgJgGgGgMQgGgMAAgRIAAgCQAAgRAGgNQAGgMAJgGQAKgGANAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAACKgAgOgkQgFAGAAAOIAAACQAAANAGAGQAFAGAIAAQAKAAAGgGQAFgGAAgOIAAgBQAAgNgFgHQgFgHgKAAQgKAAgFAHg");
	this.shape_14.setTransform(-5.825,5.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgyBIIAAiOIBiAAIAAAfIg6AAIAAAZIAuAAIAAAcIguAAIAAAaIA9AAIAAAgg");
	this.shape_15.setTransform(-17.75,1.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgEAAgFIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_16.setTransform(-34.175,3.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_17.setTransform(-44.225,2.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggAzQgIgCgFgIQgFgGAAgMQABgSAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIAAQgGAAgDAEQgEAEAAAFIgiAAQABgNAHgIQAGgJALgEQALgEANAAQAPAAAKAEQALAEAGAJQAGAJAAANIAABEIgjAAIAAgNQgEAHgHADQgHAFgMAAQgKAAgIgEgAgJAMQgFACAAAHQAAAEADADQADADAGgBQAHAAAFgDQAFgFAAgGIAAgGIgJAAQgKgBgFADg");
	this.shape_18.setTransform(-53.925,3.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSA0IgnhnIAmAAIAVBCIAWhCIAiAAIgmBng");
	this.shape_19.setTransform(-64.925,3.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgFgFAAgIQAAgIAFgFQAFgGAIAAQAIAAAGAGQAGAFgBAIQABAIgGAFQgGAFgIAAQgIAAgFgFg");
	this.shape_20.setTransform(-73.75,1.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgiA1IAAhoIAjAAIAAAVQAFgLAIgGQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_21.setTransform(-80.725,3.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag3BIIAAiOIA2AAQAdAAAOAMQAOAMAAAXIAAABQAAAWgPAMQgOAMgbgBIgOAAIAAAxgAgOgEIAMAAQAJAAAFgEQAFgFAAgJIAAgBQAAgJgFgDQgFgFgJAAIgMAAg");
	this.shape_22.setTransform(-91.325,1.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_23.setTransform(-105.15,1.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggAzQgIgCgFgIQgFgGAAgMQABgSAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIAAQgGAAgDAEQgEAEAAAFIgiAAQABgNAHgIQAGgJALgEQALgEANAAQAPAAAKAEQALAEAGAJQAGAJAAANIAABEIgjAAIAAgNQgEAHgHADQgHAFgMAAQgKAAgIgEgAgJAMQgFACAAAHQAAAEADADQADADAGgBQAHAAAFgDQAFgFAAgGIAAgGIgJAAQgKgBgFADg");
	this.shape_24.setTransform(-114.125,3.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHBIQgIgGgEgIIAAAQIgkAAIAAiWIAkAAIAAA+QAEgIAIgFQAHgFAMgBQANAAAKAHQAKAGAFAMQAGALAAASIAAABQAAATgGAMQgGAMgJAGQgKAFgNAAQgMAAgHgEgAgPABQgFAGAAANIAAACQAAANAFAIQAGAGAJAAQAKAAAFgHQAFgGAAgOIAAgBQAAgOgFgGQgGgHgJAAQgJAAgGAHg");
	this.shape_25.setTransform(-125.825,1.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgcAwQgNgFgIgNQgHgMAAgQIAAgCQAAgQAHgMQAIgNANgGQANgHAPAAQAQAAANAGQANAHAIAMQAHAMAAARIAAABQAAAQgIAMQgHANgNAGQgNAHgQAAQgPAAgNgHgAgOgUQgGAGAAAOIAAABQAAANAGAHQAFAIAJAAQAKgBAFgHQAGgHAAgNIAAgBQAAgNgFgHQgGgHgKAAQgJAAgFAHg");
	this.shape_26.setTransform(-138.725,3.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_27.setTransform(-147.85,1.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgmBAQgQgJgJgQQgIgRAAgVIAAgBQAAgWAJgQQAKgRARgJQARgJAUAAQARAAAPAFQAPAGAJALQAJAMACATIgpAAQgBgKgHgGQgGgFgLAAQgPAAgIALQgJALAAATIAAABQAAAMADAJQAEAKAHAFQAHAFAMABQAKgBAGgCQAGgEADgEQADgFAAgGIgbAAIAAgcIBDAAIAAARQAAASgHAPQgIAOgQAIQgPAIgYABQgXgBgRgJg");
	this.shape_28.setTransform(-158.675,1.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.5,-15.7,337.1,31.4);


(lib.Tween15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AghBBQgOgJgGgQQgHgQAAgUIAAgEQABgXAIgQQAIgQAPgJQAOgJASAAQAYAAAOALQANAKADAVIgmAAQgBgFgDgDQgDgDgIgBQgLABgGAJQgGAKgBASQAFgHAIgFQAGgEANAAQAOAAAKAFQALAFAGAKQAHAJAAAPQAAAQgHALQgHALgNAGQgNAHgTAAQgVgBgOgIgAgLAJQgFAGAAAIQAAAKAFAGQAFAGAIAAQAJgBAFgFQAFgGAAgJQAAgJgFgGQgFgGgJAAQgIAAgFAGg");
	this.shape.setTransform(159.675,1.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BJIAAgGIAzg2QAKgLAGgIQAGgKAAgIQAAgIgEgFQgDgEgIAAQgGAAgFAFQgFAGgBAMIglAAQAAgbAQgNQAPgOAZAAQASABALAFQAMAGAGALQAHAJgBANQAAAPgHAMQgHALgNALIgTAUIAvAAIAAAfg");
	this.shape_1.setTransform(146.55,1.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiBBQgPgIgIgQQgIgQAAgWIAAgFQAAgXAJgQQAIgPAQgIQAOgJASAAQATAAAPAIQAPAIAJAPQAIAQAAAXIAAAFQAAAWgIAQQgIARgPAIQgPAJgUAAQgUAAgOgJgAgRggQgHAKAAAUIAAAFQAAAUAHAJQAGAKAMAAQAMAAAHgKQAFgKAAgUIAAgEQAAgUgGgKQgGgKgNAAQgMAAgFAKg");
	this.shape_2.setTransform(133.3,1.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag5BJIAAgGIAzg2QAJgLAHgIQAGgKAAgIQAAgIgDgFQgEgEgIAAQgGAAgGAFQgEAGgBAMIgmAAQACgbAOgNQAQgOAZAAQASABALAFQANAGAFALQAHAJAAANQAAAPgIAMQgHALgMALIgUAUIAwAAIAAAfg");
	this.shape_3.setTransform(119.7,1.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_4.setTransform(105.775,2.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiA1IAAhoIAjAAIAAAVQAFgLAIgGQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_5.setTransform(97.875,3.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAwQgNgFgIgNQgHgMAAgQIAAgCQAAgQAHgMQAIgNANgGQANgHAPAAQAQAAANAGQANAHAIAMQAHAMAAARIAAABQAAAQgIAMQgHANgNAGQgNAHgQAAQgPAAgNgHgAgOgUQgGAGAAAOIAAABQAAANAGAHQAFAIAJAAQAKgBAFgHQAGgHAAgNIAAgBQAAgNgFgHQgGgHgKAAQgJAAgFAHg");
	this.shape_6.setTransform(87.125,3.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag3BHIAAiKIAkAAIAAAPQAEgIAIgFQAHgFAMAAQANAAAKAGQAKAGAFAMQAGAMAAASIAAACQAAARgGAMQgGAMgJAGQgKAGgNAAQgMgBgHgEQgIgFgEgIIAAAygAgPgkQgFAHAAANIAAABQAAAOAFAGQAGAGAJAAQAKAAAFgHQAFgFAAgNIAAgCQAAgOgFgGQgGgHgJAAQgJAAgGAHg");
	this.shape_7.setTransform(74.725,5.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgEAAgFIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_8.setTransform(62.075,3.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASBIIgcgzIgKAAIAAAzIgoAAIAAiOIA4AAQAbAAAPALQAPAMAAAWIAAABQAAAPgIAJQgHAIgLAEIAiA8gAgUgFIAOAAQAJAAAFgFQAFgEAAgJIAAAAQAAgJgFgEQgFgEgJAAIgOAAg");
	this.shape_9.setTransform(50.175,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AggBGIASguIgqhdIAnAAIAUA4IAUg4IAiAAIg4CLg");
	this.shape_10.setTransform(32.825,5.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_11.setTransform(22.875,2.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgFgFAAgIQAAgIAFgFQAFgGAIAAQAJAAAFAGQAGAFgBAIQABAIgGAFQgFAFgJAAQgIAAgFgFg");
	this.shape_12.setTransform(16.25,1.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgiAxQgIgEgEgJQgFgIAAgNIAAhEIAkAAIAAA+QAAAJADAEQADAFAJgBQAGAAAFgEQAFgGAAgKIAAg7IAkAAIAABoIgkAAIAAgQQgEAIgIAFQgHAFgNAAQgKABgIgFg");
	this.shape_13.setTransform(7.05,3.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAUBHIAAgzQgEAIgIAFQgIAFgLABQgNAAgKgGQgJgGgGgMQgGgMAAgRIAAgCQAAgRAGgNQAGgMAJgGQAKgGANAAQALAAAIAFQAIAEAEAIIAAgOIAkAAIAACKgAgOgkQgFAGAAAOIAAACQAAANAGAGQAFAGAIAAQAKAAAGgGQAFgGAAgOIAAgBQAAgNgFgHQgFgHgKAAQgKAAgFAHg");
	this.shape_14.setTransform(-5.825,5.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgyBIIAAiOIBiAAIAAAfIg6AAIAAAZIAuAAIAAAcIguAAIAAAaIA9AAIAAAgg");
	this.shape_15.setTransform(-17.75,1.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgaAwQgNgFgHgNQgIgMAAgQIAAgCQAAgQAIgMQAHgNANgGQANgHAPAAQAOAAAMAFQAMAHAIALQAHANAAASIAAAJIhJAAQABAKAGAFQAGAGAIAAQAJAAAEgDQAFgEAAgFIAiAAQgCASgOAKQgNAJgYAAQgQAAgMgHgAAUgLQAAgJgFgFQgEgFgJgBQgHABgGAFQgFAFgBAJIAlAAIAAAAg");
	this.shape_16.setTransform(-34.175,3.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgLA3QgKgIAAgTIAAgtIgNAAIAAgZIANAAIAAgWIAjAAIAAAWIAVAAIAAAZIgVAAIAAAqQAAAGADADQACACAFAAIAGgBIAFgBIAAAbIgJACIgLABQgRAAgJgJg");
	this.shape_17.setTransform(-44.225,2.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggAzQgIgCgFgIQgFgGAAgMQABgSAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIAAQgGAAgDAEQgEAEAAAFIgiAAQABgNAHgIQAGgJALgEQALgEANAAQAPAAAKAEQALAEAGAJQAGAJAAANIAABEIgjAAIAAgNQgEAHgHADQgHAFgMAAQgKAAgIgEgAgJAMQgFACAAAHQAAAEADADQADADAGgBQAHAAAFgDQAFgFAAgGIAAgGIgJAAQgKgBgFADg");
	this.shape_18.setTransform(-53.925,3.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSA0IgnhnIAmAAIAVBCIAWhCIAiAAIgmBng");
	this.shape_19.setTransform(-64.925,3.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgRBMIAAhoIAjAAIAABogAgNgrQgFgFAAgIQAAgIAFgFQAFgGAIAAQAIAAAGAGQAGAFgBAIQABAIgGAFQgGAFgIAAQgIAAgFgFg");
	this.shape_20.setTransform(-73.75,1.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgiA1IAAhoIAjAAIAAAVQAFgLAIgGQAJgFAMAAIAAAhQgQAAgJAGQgJAFAAAMIAAAxg");
	this.shape_21.setTransform(-80.725,3.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag3BIIAAiOIA2AAQAdAAAOAMQAOAMAAAXIAAABQAAAWgPAMQgOAMgbgBIgOAAIAAAxgAgOgEIAMAAQAJAAAFgEQAFgFAAgJIAAgBQAAgJgFgDQgFgFgJAAIgMAAg");
	this.shape_22.setTransform(-91.325,1.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_23.setTransform(-105.15,1.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggAzQgIgCgFgIQgFgGAAgMQABgSAOgHQAPgIAZABIAKAAIAAgDQAAgHgDgFQgDgFgIAAQgGAAgDAEQgEAEAAAFIgiAAQABgNAHgIQAGgJALgEQALgEANAAQAPAAAKAEQALAEAGAJQAGAJAAANIAABEIgjAAIAAgNQgEAHgHADQgHAFgMAAQgKAAgIgEgAgJAMQgFACAAAHQAAAEADADQADADAGgBQAHAAAFgDQAFgFAAgGIAAgGIgJAAQgKgBgFADg");
	this.shape_24.setTransform(-114.125,3.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHBIQgIgGgEgIIAAAQIgkAAIAAiWIAkAAIAAA+QAEgIAIgFQAHgFAMgBQANAAAKAHQAKAGAFAMQAGALAAASIAAABQAAATgGAMQgGAMgJAGQgKAFgNAAQgMAAgHgEgAgPABQgFAGAAANIAAACQAAANAFAIQAGAGAJAAQAKAAAFgHQAFgGAAgOIAAgBQAAgOgFgGQgGgHgJAAQgJAAgGAHg");
	this.shape_25.setTransform(-125.825,1.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgcAwQgNgFgIgNQgHgMAAgQIAAgCQAAgQAHgMQAIgNANgGQANgHAPAAQAQAAANAGQANAHAIAMQAHAMAAARIAAABQAAAQgIAMQgHANgNAGQgNAHgQAAQgPAAgNgHgAgOgUQgGAGAAAOIAAABQAAANAGAHQAFAIAJAAQAKgBAFgHQAGgHAAgNIAAgBQAAgNgFgHQgGgHgKAAQgJAAgFAHg");
	this.shape_26.setTransform(-138.725,3.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgRBLIAAiVIAjAAIAACVg");
	this.shape_27.setTransform(-147.85,1.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgmBAQgQgJgJgQQgIgRAAgVIAAgBQAAgWAJgQQAKgRARgJQARgJAUAAQARAAAPAFQAPAGAJALQAJAMACATIgpAAQgBgKgHgGQgGgFgLAAQgPAAgIALQgJALAAATIAAABQAAAMADAJQAEAKAHAFQAHAFAMABQAKgBAGgCQAGgEADgEQADgFAAgGIgbAAIAAgcIBDAAIAAARQAAASgHAPQgIAOgQAIQgPAIgYABQgXgBgRgJg");
	this.shape_28.setTransform(-158.675,1.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.5,-15.7,337.1,31.4);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset7();
	this.instance.setTransform(-412,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412,-58.5,824,117);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset7();
	this.instance.setTransform(-412,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412,-58.5,824,117);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset8();
	this.instance.setTransform(-412.5,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412.5,-58.5,825,117);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset8();
	this.instance.setTransform(-412.5,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412.5,-58.5,825,117);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset9();
	this.instance.setTransform(-412.5,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412.5,-58.5,825,117);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset9();
	this.instance.setTransform(-412.5,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-412.5,-58.5,825,117);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.647)","rgba(0,0,0,0.29)","rgba(0,0,0,0)"],[0,0.855,1],-281.4,0,281.5,0).s().p("Egr+AHCIAAuDMBX8AAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-281.4,-45,562.9,90);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("Eg43AAyIAAhjMBxvAAAIAABjg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-363.9,-5,727.9,10);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("Eg43AAyIAAhjMBxvAAAIAABjg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-363.9,-5,727.9,10);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhaBbQgmgmAAg1QAAg0AmgmQAmglA0AAQALAAAKACIgMANIgJAAQgrAAggAfQggAfAAArQAAArAgAfQAgAgArAAQAtAAAgggQAggfgBgrQAAgggTgcQgTgagegMIgFgSQApAMAaAiQAbAiAAArQAAA1gmAmQgmAlg1AAQg0AAgmglgAgqgNIBAhVIAXBog");
	this.shape.setTransform(29.65,-0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAQAdIgGgMIgUAAIgGAMIgKAAIAag5IAbA5gAAHAIIgHgQIgGAQIANAAg");
	this.shape_1.setTransform(-5.275,9.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgMgEIAAAgIgKAAIAAg4IAkAhIAAggIAKAAIAAA4g");
	this.shape_2.setTransform(1.2,9.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTAZQgFgFAAgHQAAgKAMgFQgHgHAAgGQAAgGAFgDQAFgFAHAAQAGAAAEAEQAFADAAAHQAAAIgNAHIAKAKIAFgJIAJABIgKAOIALAMIgLAAIgFgGQgGAHgJABQgHgBgGgEgAgPANQAAAIALAAQAFABADgGIgLgNQgIADAAAHgAgKgOQAAAEAGAFQAIgGAAgEQAAgHgGAAQgIAAAAAIg");
	this.shape_3.setTransform(-40,10);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgwBJIAAiRIAjAAQA2AAAAAmQAAAKgGAIQgFAIgJAEQAcAIABAbQAAAVgPAKQgPALgbAAgAgVAzIAMAAQAeAAAAgTQAAgVgeAAIgMAAgAgVgKIAGAAQAcAAABgUQAAgLgIgFQgGgEgQAAIgFAAg");
	this.shape_4.setTransform(-37.05,-3.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AApBLIgOgfIg3AAIgPAfIgcAAIBHiVIBHCVgAARAUIgRgpIgSApIAjAAg");
	this.shape_5.setTransform(-22.85,-4.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgNBJIAAiRIAbAAIAACRg");
	this.shape_6.setTransform(-10.75,-3.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgigMIAABUIgbAAIAAiTIBgBYIAAhWIAbAAIAACWg");
	this.shape_7.setTransform(3.225,-3.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRgCIgHAeIgKAAIAOg5IAUAmIAUgmIAPA5IgLAAIgHgeIgRAgg");
	this.shape_8.setTransform(-17.45,10);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAcIAAg3IANAAQAWAAAAASQAAAQgWAAIgDAAIAAAVgAgHAAIADAAQALAAAAgJQAAgKgLAAIgDAAg");
	this.shape_9.setTransform(-10.325,9.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgEAcIAAgXIgVggIAMAAIANAXIAOgXIAMAAIgVAgIAAAXg");
	this.shape_10.setTransform(7.425,9.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRAVQgIgIAAgNQAAgMAIgIQAJgIALAAQAOAAAJALIgIAHIgBgBQgDgIgLAAQgHAAgFAGQgGAGAAAHQABAJAEAFQAGAGAHAAQAKAAAEgIIABgBIAIAHIAAAAQgJALgOAAQgMAAgIgIg");
	this.shape_11.setTransform(-31.75,9.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAVQgIgIAAgNQAAgMAIgIQAJgJALAAQANABAIAHQAJAJgBAMQABAMgJAJQgJAJgMAAQgLAAgJgJgAgMgNQgGAGAAAHQAAAJAGAFQAFAGAHAAQAIAAAGgGQAEgGAAgIQAAgJgEgFQgGgGgIAAQgHAAgFAHg");
	this.shape_12.setTransform(-25,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.5,-12.9,85,25.9);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape.setTransform(50.675,1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_1.setTransform(43.025,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAmQgKgFgEgKQgGgKAAgNIAAAAQAAgMAGgKQAFgKAKgGQAKgFAMAAQANAAAKAFQAKAGAFAJQAGAKAAANIAAAAQAAANgGAKQgFAKgKAFQgKAGgNAAQgNAAgKgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQADAHAFADQAGAEAGAAQAHAAAGgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgGgEgHAAQgLAAgFAIg");
	this.shape_2.setTransform(33.15,1.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAeAAQAOAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQADgEAAgGIAAgBQAAgGgDgDQgEgDgGAAIgKAAg");
	this.shape_3.setTransform(24.15,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_4.setTransform(16.175,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_5.setTransform(8.075,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_6.setTransform(-3.475,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgTAAIAAhVIATAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_7.setTransform(-12.45,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_8.setTransform(-21.225,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-32.225,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_10.setTransform(-39.725,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHABALIgTAAQgCgIgEgEQgFgDgIAAQgHAAgFADQgGAEgCAGQgDAHAAAIIAAABQAAAIACAGQADAHAFADQAFAEAIAAQAHAAAFgCQAEgDADgEQACgEAAgFIgTAAIAAgNIAmAAIAAAIQAAALgFAJQgEAJgJAEQgKAFgNAAQgMAAgKgGg");
	this.shape_11.setTransform(-48.8,1.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape_12.setTransform(64.375,1.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.7,-10.1,122.9,20.299999999999997);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AANA1IgBgaQgBAIgFAGQgFAGgGADQgHADgHAAQgNAAgIgHQgHgHAAgLQAAgKAFgHQAFgHAKgEQALgEAQgDIAMgDIAAgHQABgOgGgIQgGgIgJAAQgIAAgFAFQgFAFgBAHQgBAGADAHIgSAGQgEgLADgJQAEgKALgFQAKgGAOAAQASAAAKAJQAKAKAAARIAAAuQAAAGADACQACADAGAAIAEAAIAAADIgfAJgAAAgCQgNACgGAGQgHAHAAAKQAAAIAEAFQAFAFAIAAQAFAAAEgEQAGgDADgGQAEgGgBgIIAAgSg");
	this.shape.setTransform(64.75,-26.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQgBgFgCgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAIgHQAHgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_1.setTransform(55.15,-27.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_2.setTransform(45.725,-26.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAdA0IgchFIgcBFIgDAAIglhZQgDgFgCgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgCADQgDADACAFIAYA8IATgvIgFgNQgCgFgDgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgDADQgDADACAFIAZA8IAYg8QABgFgCgDQgCgDgGAAIAAgDIAbAAIAAADQgEAAgDADQgDACgCAGIglBZg");
	this.shape_3.setTransform(27.625,-26.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_4.setTransform(14.175,-26.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAKA0IAAgDQAGgBADgCQAEgDAAgGIAAg3QAAgJgFgFQgEgFgIAAQgGAAgGADQgGADgHAIIAAA8QAAAGADADQAEACAFABIAAADIgtAAIAAgDQAGgBADgCQAEgDAAgGIAAhBQAAgFgDgDQgDgCgFgBIgEAAIAAgDIAggJIADAAIAAAXQAIgLAIgGQAIgGAKAAQAOAAAHAIQAHAJAAAOIAAA5QAAAGAEADQADACAFABIAAADg");
	this.shape_5.setTransform(3.125,-27.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AANA1IgBgaQgBAIgFAGQgFAGgGADQgHADgIAAQgMAAgIgHQgHgHAAgLQAAgKAFgHQAFgHAKgEQAKgEARgDIAMgDIAAgHQAAgOgFgIQgGgIgJAAQgIAAgFAFQgFAFgBAHQgBAGADAHIgRAGQgFgLADgJQAEgKAKgFQALgGAOAAQASAAAKAJQAKAKAAARIAAAuQAAAGADACQACADAGAAIAEAAIAAADIgfAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAEAFQAFAFAIAAQAFAAAEgEQAGgDADgGQADgGAAgIIAAgSg");
	this.shape_6.setTransform(-12.4,-26.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAKA0IAAgDQAGgBADgCQAEgDAAgGIAAg3QAAgJgFgFQgEgFgIAAQgGAAgGADQgGADgHAIIAAA8QAAAGADADQAEACAFABIAAADIgtAAIAAgDQAGgBADgCQAEgDAAgGIAAhBQAAgFgDgDQgDgCgFgBIgEAAIAAgDIAggJIADAAIAAAXQAIgLAIgGQAIgGAKAAQAOAAAHAIQAHAJAAAOIAAA5QAAAGAEADQADACAFABIAAADg");
	this.shape_7.setTransform(-28.575,-27.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_8.setTransform(-37.525,-29.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAUBIIgCgXQgEALgIAGQgHAHgLgBQgNAAgIgGQgKgHgFgLQgEgLgBgOQABgTAGgMQAGgMALgHQAKgGANAAQAHAAAGADQAIAEADAFIAAgbQAAgFgCgDQgDgDgFAAIgEAAIAAgDIAggKIADAAIAAB6QAAAFACADQAEACAFAAIADAAIAAADIgfAJgAgTgVQgGAGgDAKQgDAIAAAMQAAALADAKQADAKAFAHQAHAGAKAAQAGAAAGgEQAHgEACgJIAAglQAAgIgCgHQgDgHgGgEQgFgFgHAAQgHAAgHAFg");
	this.shape_9.setTransform(-50.5,-28.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgiA0IAAgDQAGgBAEgCQADgDAAgGIAAhBQAAgFgCgDQgDgCgFgBIgEAAIAAgDIAggJIADAAIAAAdQAEgOAHgHQAIgIAJAAIAEABIAFABIgCATIgFgCIgHgBQgGAAgHAEQgHAFgDAIIAAA1QgBAGAEADQAEACALABIAAADg");
	this.shape_10.setTransform(-60.55,-27.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANA1IgBgaQgBAIgFAGQgFAGgGADQgHADgIAAQgMAAgIgHQgHgHAAgLQAAgKAFgHQAFgHAKgEQAKgEARgDIAMgDIAAgHQAAgOgFgIQgGgIgJAAQgIAAgFAFQgFAFgBAHQgBAGADAHIgRAGQgFgLADgJQAEgKAKgFQALgGAOAAQASAAAKAJQAKAKAAARIAAAuQAAAGADACQACADAGAAIAEAAIAAADIgfAJgAAAgCQgNACgHAGQgGAHAAAKQAAAIAEAFQAFAFAIAAQAFAAAEgEQAGgDADgGQADgGAAgIIAAgSg");
	this.shape_11.setTransform(-69.55,-26.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAdA0IgchFIgcBFIgDAAIglhZQgDgFgCgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgCADQgDADACAFIAYA8IATgvIgFgNQgCgFgDgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgDADQgDADACAFIAZA8IAYg8QABgFgCgDQgCgDgGAAIAAgDIAbAAIAAADQgEAAgDADQgDACgCAGIglBZg");
	this.shape_12.setTransform(-83.475,-26.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgjA0IAAgDQAHgBADgCQAFgDAAgGIAAhBQgBgFgCgDQgDgCgFgBIgFAAIAAgDIAhgJIADAAIAAAdQAEgOAIgHQAHgIAJAAIAEABIAEABIgBATIgFgCIgGgBQgIAAgGAEQgHAFgDAIIAAA1QAAAGADADQAEACAKABIAAADg");
	this.shape_13.setTransform(-95.6,-27.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAvQgKgHgGgLQgGgMAAgOQAAgQAGgMQAGgNAMgHQAKgHAOAAQAOAAALAGQAKAHAGALQAGAMABAPQgBAPgGANQgGANgLAGQgLAHgOAAQgOAAgLgGgAgOgpQgGAFgDAJQgDAJAAANQAAAIACAKQABAJAEAIQAEAIAFAEQAGAGAHAAQAIAAAFgGQAGgFACgJQADgJAAgNQAAgIgCgKQgBgJgDgIQgFgIgFgEQgFgGgIAAQgHAAgFAGg");
	this.shape_14.setTransform(-105.5,-27);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AglBIIAAgCQAGgBAEgDQAEgCAAgHIAAhOIgRAAIAAgGIARAAIAAgHQAAgMAFgIQAGgJAIgEQAIgEALgBQAJAAAHADQAHADADAGIgQALQgBgHgDgFQgEgFgFAAQgFAAgEAEQgDAEgBAGQgCAHAAAIIAAAKIAbAAIAAAGIgbAAIAABOQAAAHADACQAFADAKABIAAACg");
	this.shape_15.setTransform(-113.825,-29.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgkBCQgMgGAAgLQAAgGACgFQADgFAFgDIAKgDQgGgEgCgDQgDgEABgFQAAgGADgFQAEgFAGgDQgHgFgFgHQgFgHABgKQAAgKAEgIQAGgIAJgFQAJgEANAAQAJAAAIADIAgAAIAAAGIgWAAQAHAEADAHQADAGABAJQAAAKgGAHQgFAJgJAEQgKAFgLgBIgLgBIgLgDIgEAFQgBACgBACQAAADAFAEQADADAHABIAfACQAOABAJAGQAIAGABAMQAAALgIAGQgHAIgLAEQgNAEgOAAQgVgBgMgGgAgdAiQgCADAAAFQgBAJAFAFQAEAGAJADQAHACAJAAQAKAAAHgCQAIgCAFgFQAEgEAAgGQAAgFgEgFQgGgEgLgCIgcgCIgGgBIgGgBIgEAGgAgPg7QgFAHAAALQgBAPAHAJQAGAJAIAAQAJgBAFgGQAGgIgBgLQAAgJgDgIQgCgHgFgEQgFgEgGgBQgIABgFAHg");
	this.shape_16.setTransform(-128.45,-25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAKA0IAAgDQAGgBADgCQAEgDAAgGIAAg3QAAgJgFgFQgEgFgIAAQgGAAgGADQgGADgHAIIAAA8QAAAGADADQAEACAFABIAAADIgtAAIAAgDQAGgBADgCQAEgDAAgGIAAhBQAAgFgDgDQgDgCgFgBIgEAAIAAgDIAggJIADAAIAAAXQAIgLAIgGQAIgGAKAAQAOAAAHAIQAHAJAAAOIAAA5QAAAGAEADQADACAFABIAAADg");
	this.shape_17.setTransform(-139.625,-27.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUBJIAAgDQAFgBAEgCQADgDAAgGIAAhBQAAgFgCgCQgDgDgFgBIgFAAIAAgCIAggKIADAAIAABYQAAAGADADQADACAGABIAAADgAgIgxQgEgEAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_18.setTransform(-148.575,-29.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgiA0IAAgDQAGgBADgCQAEgDAAgGIAAhBQAAgFgCgDQgDgCgFgBIgEAAIAAgDIAggJIADAAIAAAdQAEgOAHgHQAIgIAJAAIAEABIAFABIgCATIgFgCIgHgBQgGAAgHAEQgHAFgDAIIAAA1QgBAGAEADQAEACALABIAAADg");
	this.shape_19.setTransform(-155.4,-27.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAuQgLgHgFgLQgGgMAAgOQAAgPAGgNQAGgMALgHQALgHAOAAQANAAAIAFQAJAGAFAKQAEAKAAANIhDAAIAAABIAAACQAAAMAEAKQAFAKAIAFQAIAFALAAQAKAAAIgFQAHgFAEgHIACABQgCAJgFAHQgGAHgIAFQgJAEgLAAQgOAAgKgHgAAXgOQAAgIgDgIQgCgHgFgFQgFgFgGAAQgGAAgFAFQgGAEgDAHQgDAIgBAJIAtAAIAAAAg");
	this.shape_20.setTransform(-164.825,-26.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAdA0IgchFIgcBFIgDAAIglhZQgDgFgCgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgCADQgDADACAFIAYA8IATgvIgFgNQgCgFgDgDQgDgDgFAAIAAgDIAtAAIAAADQgHAAgDADQgDADACAFIAZA8IAYg8QABgFgCgDQgCgDgGAAIAAgDIAbAAIAAADQgEAAgDADQgDACgCAGIglBZg");
	this.shape_21.setTransform(-178.275,-26.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgZAvQgLgHgFgLQgGgMAAgOQAAgQAGgMQAGgNALgHQALgHAOAAQAPAAAKAGQAKAHAHALQAFAMAAAPQAAAPgFANQgHANgLAGQgLAHgOAAQgOAAgLgGgAgPgpQgFAFgDAJQgDAJAAANQAAAIACAKQACAJADAIQAEAIAGAEQAFAGAHAAQAHAAAGgGQAFgFAEgJQACgJAAgNQAAgIgBgKQgCgJgEgIQgEgIgFgEQgGgGgGAAQgIAAgGAGg");
	this.shape_22.setTransform(-192.2,-27);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ag3BDIAAgDQAJgBAFgCQAEgDAAgIIAAhjQAAgIgEgCQgFgEgJAAIAAgDIA6AAQAQAAAMAEQAMAEAHAJQAGAIAAANQAAAMgGAIQgHAIgMAEQgMAEgQAAIgSAAIAAAqQAAAIAEADQAFACAHABIAAADgAgPACIAPAAQAQAAAIgHQAJgJAAgOQAAgPgJgIQgIgJgQAAIgPAAg");
	this.shape_23.setTransform(-204.05,-28.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-212.3,-45.6,424.70000000000005,30.6);


// stage content:
(lib.v11PE2026DemandbaseLandingPage728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE
	this.instance = new lib.Tween15("synched",0);
	this.instance.setTransform(290.5,57.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.setTransform(290.5,28.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},29).to({state:[{t:this.instance_1}]},16).wait(76));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(29).to({_off:false},0).to({_off:true,y:28.4,alpha:1},16,cjs.Ease.cubicInOut).wait(76));

	// SUBTITLE
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(334.3,105.05);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(54).to({_off:false},0).to({y:85.1,alpha:1},16,cjs.Ease.cubicInOut).wait(51));

	// CTA
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(640.75,79.85);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(82).to({_off:false},0).to({y:61.95,alpha:1},15,cjs.Ease.cubicInOut).wait(24));

	// LOGO
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(62.5,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(121));

	// RED_BAR
	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(-388.1,85);
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(363.95,85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},4).to({state:[{t:this.instance_6}]},14).wait(103));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).to({_off:true,x:363.95},14,cjs.Ease.quadInOut).wait(103));

	// SHADOW
	this.instance_7 = new lib.Tween8("synched",0);
	this.instance_7.setTransform(281.45,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(121));

	// FOREGROUND
	this.instance_8 = new lib.Tween9("synched",0);
	this.instance_8.setTransform(366,44.5);

	this.instance_9 = new lib.Tween10("synched",0);
	this.instance_9.setTransform(404.5,44.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,x:404.5},120,cjs.Ease.quadInOut).wait(1));

	// MOUNTAIN
	this.instance_10 = new lib.Tween11("synched",0);
	this.instance_10.setTransform(404.5,58.5);

	this.instance_11 = new lib.Tween12("synched",0);
	this.instance_11.setTransform(404.5,44.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true,y:44.5},120,cjs.Ease.quadInOut).wait(1));

	// SKY
	this.instance_12 = new lib.Tween13("synched",0);
	this.instance_12.setTransform(412,44.5);

	this.instance_13 = new lib.Tween14("synched",0);
	this.instance_13.setTransform(404,44.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},120).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,x:404},120,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-388,31,1212,86);
// library properties:
lib.properties = {
	id: '5F6C62628EE2B84AB388304D5FA76A2F',
	width: 728,
	height: 90,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1.png", id:"v1_1_PE2026_Demandbase_LandingPage_728x90_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5F6C62628EE2B84AB388304D5FA76A2F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;