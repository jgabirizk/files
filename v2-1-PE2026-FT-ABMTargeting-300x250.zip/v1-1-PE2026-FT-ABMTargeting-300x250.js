(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1", frames: [[0,0,483,262],[0,528,482,262],[0,264,483,262]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Foreground72x = function() {
	this.initialize(ss["v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Mountains72x = function() {
	this.initialize(ss["v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Sky72x = function() {
	this.initialize(ss["v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.749)","rgba(0,0,0,0.369)","rgba(0,0,0,0)"],[0,0.855,1],-117.5,0,117.5,0).s().p("AyWSXMAAAgktMAktAAAMAAAAktg");
	this.shape.setTransform(117.5,128.9961,1,1.0978);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_2, new cjs.Rectangle(0,0,235,258), null);


(lib.StackedWhiteRGB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhqBrQgsgtAAg+QAAg+AsgsQAsgsA+AAQAOAAAKACIgNARIgLgBQg0AAglAlQglAkAAAzQAAAzAlAkQAlAlA0AAQA1AAAlglQAmgkAAgzQAAgmgXggQgXgggkgNIgEgVQAwANAeAoQAfApAAAyQAAA+gsAtQgsAsg/AAQg+AAgsgsgAgygPIBMhjIAbB5g");
	this.shape.setTransform(34.875,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAiIgHgPIgYAAIgHAPIgMAAIAfhDIAgBDgAAIAJIgIgSIgHASIAPAAg");
	this.shape_1.setTransform(-6.2,11.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPgFIAAAmIgMAAIAAhCIArAnIAAgmIAMAAIAABCg");
	this.shape_2.setTransform(1.425,11.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQgFgGgBgIQAAgLAOgHQgHgIAAgIQAAgGAGgFQAFgFAIABQAIAAAFADQAGAFgBAHQAAAKgPAIIALAMIAHgKIALAAIgMARIAMAOIgMAAIgGgHQgIAIgKAAQgJAAgHgEgAgIAEQgKAEAAAHQAAALAMAAQAHAAAEgGIgNgRgAgMgRQAAAFAHAGQAKgFAAgHQAAgHgIAAQgJgBAAAJg");
	this.shape_3.setTransform(-47.05,11.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIApAAQBAgBAAAtQAAAMgGAKQgHAKgKAEQAhAKAAAgQAAAYgRAMQgRANggAAgAgZA8IAOAAQAkAAAAgXQAAgYgkAAIgOAAgAgZgMIAHAAQAiAAAAgYQAAgXgjAAIgGAAg");
	this.shape_4.setTransform(-43.575,-4.5761);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAwBYIgQglIhBAAIgRAlIghAAIBTivIBUCvgAAVAXIgVgwIgVAwIAqAAg");
	this.shape_5.setTransform(-26.9,-4.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPBWIAAirIAfAAIAACrg");
	this.shape_6.setTransform(-12.625,-4.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpgPIAABlIgfAAIAAivIBxBpIAAhmIAgAAIAACwg");
	this.shape_7.setTransform(3.8,-4.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUgCIgIAjIgMAAIAQhCIAYArIAXgrIASBCIgNAAIgIgjIgUAkg");
	this.shape_8.setTransform(-20.5,11.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhIAAhBIARAAQAaAAAAAVQgBAKgHAFQgHAEgLAAIgEAAIAAAZgAgIgBIAEAAQANAAAAgKQAAgLgNAAIgEAAg");
	this.shape_9.setTransform(-12.15,11.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFAhIAAgcIgYglIAOAAIAPAbIARgbIANAAIgYAlIAAAcg");
	this.shape_10.setTransform(8.725,11.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAZQgKgKAAgPQAAgOAKgJQAKgKAOAAQARAAAKAMIAAABIgKAHIAAAAQgGgJgLAAQgIAAgHAGQgGAHAAAJQAAAKAGAHQAGAGAJAAQALABAGgKIAAgBIAKAIIAAABQgKAMgRAAQgPAAgJgJg");
	this.shape_11.setTransform(-37.35,11.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgKQALgKANAAQAPAAAKAJQAJAKABAOQgBAOgJAKQgLAKgOAAQgNAAgLgJgAgPgPQgGAHAAAIQAAAKAGAHQAHAGAIAAQAJABAHgIQAFgGAAgKQAAgJgFgHQgHgGgJAAQgIAAgHAHg");
	this.shape_12.setTransform(-29.4,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StackedWhiteRGB, new cjs.Rectangle(-50,-15.2,100,30.4), null);


(lib.Tween14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Sky72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Sky72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mountains72x();
	this.instance.setTransform(-241,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241,-131,482,262);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mountains72x();
	this.instance.setTransform(-241,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241,-131,482,262);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Foreground72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Foreground72x();
	this.instance.setTransform(-241.5,-131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-241.5,-131,483,262);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("A3bBLIAAiVMAu3AAAIAACVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-7.5,300,15);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.825,1.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.525,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.875,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgGgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQAEAHAEADQAGAEAGAAQAIAAAFgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgFgEgIAAQgLAAgFAIg");
	this.shape_3.setTransform(28,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQAEgEAAgGIAAgBQAAgGgEgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.025,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.625,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgSAAIAAhVIASAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.6,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.375,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.375,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.875,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHAAALIgTAAQgBgIgEgEQgGgDgHAAQgGAAgGADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQACgEABgFIgUAAIAAgNIAnAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-53.95,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbglIA3AlIg3Amg");
	this.shape.setTransform(57.825,1.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_1.setTransform(45.525,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_2.setTransform(37.875,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAmQgJgFgGgKQgFgKAAgNIAAAAQAAgMAFgKQAHgKAJgGQAKgFAMAAQANAAAKAFQAKAGAGAJQAFAKAAANIAAAAQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgLgGgAgQgUQgHAHAAANIAAAAQAAAJADAGQAEAHAEADQAGAEAGAAQAIAAAFgEQAFgDADgHQADgGAAgJIAAAAQAAgIgDgGQgDgHgFgDQgFgEgIAAQgLAAgFAIg");
	this.shape_3.setTransform(28,1.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeArIAAhVIAdAAQAPAAAIAHQAJAHAAANIAAABQAAAJgEAFQgEAGgHADQgHADgJAAIgLAAIAAAfgAgLgBIAKAAQAGAAAEgDQAEgEAAgGIAAgBQAAgGgEgDQgEgDgGAAIgKAAg");
	this.shape_4.setTransform(19,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_5.setTransform(11.025,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOArIgUghIgIAAIAAAhIgTAAIAAhVIAeAAQAJAAAIADQAHADAEAFQAEAHAAAJIAAAAQAAAGgCAFQgCAEgEACQgEADgFABIAWAlgAgOgDIALAAQAGAAAEgDQADgDAAgGIAAAAQAAgGgDgDQgEgDgGAAIgLAAg");
	this.shape_6.setTransform(2.925,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_7.setTransform(-8.625,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARArIAAgjIgiAAIAAAjIgSAAIAAhVIASAAIAAAkIAiAAIAAgkIATAAIAABVg");
	this.shape_8.setTransform(-17.6,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_9.setTransform(-26.375,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJArIAAhFIgXAAIAAgQIBBAAIAAAQIgXAAIAABFg");
	this.shape_10.setTransform(-37.375,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcArIAAhVIA3AAIAAAQIgkAAIAAAUIAdAAIAAAMIgdAAIAAAWIAmAAIAAAPg");
	this.shape_11.setTransform(-44.875,1.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAmQgKgFgFgKQgFgKAAgNIAAAAQAAgNAFgJQAGgKAKgGQAJgFAMAAQAKAAAIADQAJADAFAGQAGAHAAALIgTAAQgBgIgEgEQgGgDgHAAQgGAAgGADQgFAEgDAGQgDAHAAAIIAAABQAAAIADAGQACAHAGADQAEAEAIAAQAHAAAFgCQAEgDACgEQACgEABgFIgUAAIAAgNIAnAAIAAAIQAAALgFAJQgFAJgIAEQgKAFgNAAQgNAAgJgGg");
	this.shape_12.setTransform(-53.95,1.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-10.1,121.30000000000001,20.299999999999997);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAtQgHgIAAgPIAAgkIgLAAIAAgTIALAAIAAgRIAbAAIAAARIARAAIAAATIgRAAIAAAiQAAAFACACQADACAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNAAgIgGg");
	this.shape.setTransform(36.525,32.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgMAGgLQAGgJAKgFQALgGAMAAQALAAAJAFQAKAEAGAJQAGALAAAOIAAAHIg6AAQABAIAEAEQAEAFAIABQAGgBAEgDQADgDABgDIAbAAQgCAOgLAHQgKAIgTAAQgNAAgKgFgAAQgIQAAgIgEgEQgEgEgGAAQgGAAgFAEQgDAEgBAIIAdAAIAAAAg");
	this.shape_1.setTransform(28.8,32.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZA4IANglIghhKIAfAAIAQAtIAQgtIAcAAIgtBvg");
	this.shape_2.setTransform(19.775,34.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgJAtQgHgIAAgPIAAgkIgLAAIAAgTIALAAIAAgRIAbAAIAAARIARAAIAAATIgRAAIAAAiQAAAFACACQADACAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNAAgIgGg");
	this.shape_3.setTransform(8.675,32.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgEgGABQgFgBgEAEQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgEQAGgFAKAAQANAAAHAIQAIAHAAARIAAA1g");
	this.shape_4.setTransform(0.725,32.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgMAGgLQAGgJALgFQAJgGAMAAQAMAAAJAFQAKAEAGAJQAFALABAOIAAAHIg6AAQABAIAEAEQAFAFAGABQAIgBADgDQADgDABgDIAbAAQgCAOgLAHQgKAIgUAAQgMAAgKgFgAAQgIQgBgIgDgEQgDgEgIAAQgFAAgEAEQgEAEgCAIIAeAAIAAAAg");
	this.shape_5.setTransform(-9.05,32.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAmArIAAgxQAAgHgDgDQgDgCgFAAQgGgBgDAEQgEAEAAAGIAAAwIgbAAIAAgxQAAgHgDgDQgDgCgFAAQgGgBgDAEQgEAEAAAGIAAAwIgcAAIAAhTIAcAAIAAANQAEgGAGgEQAHgFAKAAQAIAAAFAEQAFADADAHQAGgHAHgDQAHgEAIAAQAIAAAGAEQAGADAEAHQADAHAAAKIAAA2g");
	this.shape_6.setTransform(-21.275,32.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgEgGABQgFgBgEAEQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgEQAGgFAKAAQANAAAHAIQAIAHAAARIAAA1g");
	this.shape_7.setTransform(-33.725,32.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWAnQgLgFgGgJQgGgKAAgOIAAgBQAAgMAGgLQAGgJALgFQAKgGAMAAQANAAAKAGQALAEAGAKQAGAKAAANIAAAAQAAAOgGAKQgGAKgLAEQgKAGgNAAQgMAAgKgFgAgLgQQgEAGAAAKIAAAAQAAAMAEAFQAEAGAHAAQAIAAAEgGQAFgGAAgKIAAgBQAAgKgEgGQgFgGgIABQgHgBgEAGg");
	this.shape_8.setTransform(-43.725,32.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbAqIAAhSIAcAAIAAARQAEgKAGgEQAHgFAKABIAAAbQgNgBgHAEQgHAFAAAJIAAAng");
	this.shape_9.setTransform(-51.825,32.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgiQgFgFAAgGQAAgGAFgFQAEgDAGAAQAHAAAEADQAEAFABAGQgBAGgEAFQgEAEgHAAQgGAAgEgEg");
	this.shape_10.setTransform(-57.775,31.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPAqIgehTIAeAAIARA1IARg1IAbAAIgfBTg");
	this.shape_11.setTransform(-64.875,32.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgEgGABQgFgBgEAEQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgEQAGgFAKAAQANAAAHAIQAIAHAAARIAAA1g");
	this.shape_12.setTransform(-74.425,32.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgMAGgLQAGgJALgFQAJgGAMAAQAMAAAJAFQAKAEAGAJQAFALABAOIAAAHIg6AAQABAIAEAEQAFAFAGABQAIgBADgDQADgDABgDIAbAAQgCAOgLAHQgKAIgUAAQgMAAgKgFgAAQgIQgBgIgDgEQgDgEgIAAQgFAAgEAEQgEAEgCAIIAeAAIAAAAg");
	this.shape_13.setTransform(-84.2,32.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AggAyQgLgIgBgPIAdAAQAAAFADADQAEAEAHgBQAJAAAFgEQADgGAAgHIAAgNIgFAIQgEADgFACQgEADgHAAQgJgBgJgFQgHgEgFgJQgFgIAAgNIAAgBQAAgNAFgIQAFgKAHgFQAJgEAJAAQAKAAAFAEQAHADADAGIAAgLIAdAAIAABLQAAATgMAKQgMAKgWAAQgUAAgLgJgAgLgfQgDAFAAAJIAAABQAAAJADAFQAFAEAGAAQAIAAAFgEQAEgFAAgJIAAgBQAAgJgEgFQgEgFgIAAQgIAAgEAFg");
	this.shape_14.setTransform(-4.15,14.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgEgGABQgFgBgEAEQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgEQAGgFAKAAQANAAAHAIQAIAHAAARIAAA1g");
	this.shape_15.setTransform(-14.025,12.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_16.setTransform(-21.375,11.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgbAkQgJgHgBgNIAaAAQABAEADACQACADAFAAQAFAAADgCQADgCAAgDQAAgDgEgCQgDgCgIgBQgLgBgHgDQgIgDgCgEQgEgGAAgJQAAgJAFgGQAFgGAIgDQAIgDAKAAQAOAAAKAGQAKAGACAPIgaAAQgBgEgDgCQgCgCgEAAQgEAAgDABQgDACAAAEQAAADAEABQADACAHABQALABAIACQAHADAEAFQAEAFAAAJQAAAPgKAHQgKAHgRAAQgSAAgKgIg");
	this.shape_17.setTransform(-27.9,13);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_18.setTransform(-34.325,11.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgZAqQgGgDgEgFQgEgHgBgIQABgPAMgFQALgGAUgBIAIAAIAAgBQABgHgDgDQgCgDgHgBQgFABgDACQgCADAAAEIgbAAQAAgKAFgGQAGgHAJgEQAJgDAKAAQAMAAAIADQAJAEAEAHQAFAGgBAMIAAA1IgbAAIAAgKQgDAFgGADQgFAEgKAAQgIAAgGgCgAgHAJQgEADAAAFQAAAEADABQACADAFAAQAFAAAEgEQAEgDAAgGIAAgEIgIAAQgHAAgEABg");
	this.shape_19.setTransform(-41.55,13);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgbAqIAAhSIAcAAIAAARQAEgKAGgEQAHgFAKABIAAAbQgNgBgHAEQgHAEAAAKIAAAng");
	this.shape_20.setTransform(-48.975,12.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgaA5QgIgFgFgKQgFgJAAgPIAAgBQAAgOAFgJQAFgKAIgFQAIgFAKAAQAIAAAHAEQAGAEADAGIAAgwIAdAAIAAB3IgdAAIAAgNQgDAGgHAFQgGAEgJAAQgKAAgHgEgAgLAAQgEAGAAALIAAABQAAALAFAFQAEAFAGAAQAIAAAFgFQAEgGAAgKIAAgBQAAgLgEgGQgEgEgIAAQgHAAgFAEg");
	this.shape_21.setTransform(-57.925,11.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgEgGABQgFgBgEAEQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgEQAGgFAKAAQANAAAHAIQAIAHAAARIAAA1g");
	this.shape_22.setTransform(-67.825,12.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgbAnQgHgDgDgHQgEgHAAgKIAAg2IAdAAIAAAxQAAAHADAEQACADAHAAQAFAAAEgEQAEgEAAgIIAAgvIAdAAIAABTIgdAAIAAgNQgDAGgHAEQgFAFgLAAQgIAAgGgEg");
	this.shape_23.setTransform(-77.825,13.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgRA9IAAg/IgKAAIAAgUIAKAAIAAgHQAAgPAJgIQAIgIAPAAIAHABIAGABIAAAVIgEgBIgEAAQgFAAgCADQgCACAAAEIAAAHIARAAIAAAUIgRAAIAAA/g");
	this.shape_24.setTransform(-85.925,11.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AggAyQgKgIgCgPIAcAAQABAFAEADQADAEAIgBQAIAAAEgEQAFgGAAgHIAAgNIgHAIQgDADgFACQgEADgGAAQgLgBgHgFQgJgEgEgJQgFgIAAgNIAAgBQAAgMAFgJQAEgKAJgFQAHgEALgBQAIABAHAEQAGADAEAGIAAgLIAcAAIAABLQAAATgMAKQgMAKgVgBQgVABgLgJgAgKgfQgFAFAAAJIAAABQAAAJAFAFQAEAEAHAAQAIAAADgEQAFgFAAgJIAAgBQAAgJgEgFQgEgFgIAAQgIAAgDAFg");
	this.shape_25.setTransform(40.9,-5.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgDgGAAQgFAAgEADQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgFQAGgEAKAAQANAAAHAIQAIAIAAAPIAAA2g");
	this.shape_26.setTransform(31.025,-7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_27.setTransform(23.675,-8.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AggAyQgLgIgBgPIAdAAQAAAFADADQAEAEAIgBQAIAAAEgEQAEgGABgHIAAgNIgGAIQgEADgFACQgEADgGAAQgLgBgHgFQgJgEgEgJQgFgIAAgNIAAgBQAAgMAFgJQAEgKAJgFQAHgEALgBQAIABAGAEQAHADAEAGIAAgLIAcAAIAABLQAAATgMAKQgMAKgVgBQgWABgKgJgAgLgfQgDAFgBAJIAAABQABAJADAFQAFAEAHAAQAHAAAEgEQAFgFAAgJIAAgBQAAgJgEgFQgFgFgHAAQgHAAgFAFg");
	this.shape_28.setTransform(15.95,-5.45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgDgGAAQgFAAgEADQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgFQAGgEAKAAQANAAAHAIQAIAIAAAPIAAA2g");
	this.shape_29.setTransform(6.075,-7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJAKgFQALgGAMAAQALAAAKAEQAJAFAGAJQAGALAAAOIAAAHIg6AAQAAAIAFAEQAEAFAIABQAGgBAEgDQADgCABgFIAbAAQgCAOgLAIQgKAIgTAAQgNAAgKgFgAAQgIQgBgIgDgEQgEgEgGAAQgGAAgFAEQgDAEgBAIIAdAAIAAAAg");
	this.shape_30.setTransform(-3.7,-6.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgNA8IAAh3IAbAAIAAB3g");
	this.shape_31.setTransform(-10.825,-8.725);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgNA8IAAh3IAbAAIAAB3g");
	this.shape_32.setTransform(-15.525,-8.725);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgZApQgGgCgEgFQgEgHgBgIQABgPAMgFQALgGAUAAIAIAAIAAgCQABgHgDgDQgCgDgHgBQgEABgDACQgDADAAAEIgbAAQABgKAEgHQAGgGAJgEQAIgDALAAQALAAAJADQAIAEAFAGQAFAIgBALIAAA1IgbAAIAAgKQgDAFgGADQgFAEgKAAQgIAAgGgDgAgHAKQgEACAAAFQAAADADACQACACAFABQAFgBAEgDQAEgDAAgGIAAgEIgIAAQgHAAgEACg");
	this.shape_33.setTransform(-22.75,-6.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AANA8IAAgwQAAgHgDgEQgDgCgGAAQgFAAgEACQgEAEAAAIIAAAvIgdAAIAAh3IAdAAIAAAyQADgHAHgEQAGgFAKAAQANAAAHAIQAIAIAAAPIAAA2g");
	this.shape_34.setTransform(-32.125,-8.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgUAnQgKgFgGgJQgGgJAAgPIAAgBQAAgNAGgKQAGgKAKgFQAKgFALAAQALAAAJADQAJAEAGAIQAGAHABANIgbAAQgBgHgEgCQgCgDgHgBQgGABgFAEQgDAGAAAKIAAABQAAALADAGQAEAFAIAAQAGAAADgEQAFgDAAgHIAaAAQgBAKgEAJQgFAHgJAEQgJAFgOAAQgMAAgJgFg");
	this.shape_35.setTransform(-41.8,-6.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgJAsQgHgGAAgQIAAgjIgLAAIAAgUIALAAIAAgRIAbAAIAAARIARAAIAAAUIgRAAIAAAhQAAAFACABQADADAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNABgIgIg");
	this.shape_36.setTransform(-52.875,-7.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgaAlQgLgIAAgNIAbAAQAAAEADACQACADAFAAQAGAAACgCQACgCAAgDQAAgDgDgCQgEgCgHgBQgLgBgIgDQgGgDgEgEQgDgGAAgJQAAgJAFgGQAFgGAIgDQAIgDAKAAQAOAAALAGQAJAHACAOIgaAAQgBgEgCgCQgDgCgEAAQgEAAgDABQgCADAAADQgBADAEABQADABAHACQALABAIACQAHADAFAFQADAFAAAJQAAAPgKAHQgKAHgRAAQgRAAgKgHg");
	this.shape_37.setTransform(-60,-6.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgWAnQgLgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAKgGAMAAQANAAAKAGQALAEAGAKQAGAKAAANIAAABQAAANgGAKQgGAKgLAEQgKAGgNAAQgMAAgKgFgAgLgQQgEAFAAALIAAABQAAALAEAFQAEAGAHgBQAIABAEgGQAFgFAAgLIAAgBQAAgKgEgGQgFgGgIAAQgHAAgEAGg");
	this.shape_38.setTransform(-69.125,-6.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAmArIAAgxQAAgGgDgDQgDgDgFAAQgGAAgDADQgEAEAAAGIAAAwIgbAAIAAgxQAAgGgDgDQgDgDgFAAQgGAAgDADQgEAEAAAGIAAAwIgcAAIAAhTIAcAAIAAANQAEgGAGgFQAHgEAKAAQAIAAAFADQAFAEADAHQAGgHAHgEQAHgDAIAAQAIAAAGADQAGAEAEAHQADAHAAAKIAAA2g");
	this.shape_39.setTransform(-81.525,-7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgbArIAAhTIAcAAIAAAQQAEgJAGgEQAHgFAKAAIAAAbQgNAAgHAFQgHADAAAKIAAAog");
	this.shape_40.setTransform(16.875,-26.85);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgNA9IAAhTIAbAAIAABTgAgKgjQgFgEAAgGQAAgHAFgDQAEgEAGgBQAHABAEAEQAEADABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_41.setTransform(10.925,-28.65);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgKQgGgJAAgOIAAgBQAAgMAGgLQAGgJAKgGQALgFAMAAQALAAAJAEQAKAFAGAKQAGAKAAAOIAAAHIg6AAQABAIAEAFQAEAEAHAAQAHAAAEgDQADgCABgFIAbAAQgCAPgLAHQgLAIgSAAQgNAAgKgFgAAQgIQAAgIgEgEQgEgEgGAAQgHAAgDAEQgFAEgBAIIAeAAIAAAAg");
	this.shape_42.setTransform(3.8,-26.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AANA8IAAgwQAAgHgDgEQgDgCgGAAQgFAAgEACQgEAEAAAIIAAAvIgdAAIAAh3IAdAAIAAAyQADgHAHgEQAGgFAKAAQANAAAHAIQAIAIAAAPIAAA2g");
	this.shape_43.setTransform(-5.975,-28.625);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgJAsQgHgGAAgPIAAgkIgLAAIAAgUIALAAIAAgRIAbAAIAAARIARAAIAAAUIgRAAIAAAhQAAAEACACQADACAEABIAEAAIAEgCIAAAWIgHABIgJABQgNABgIgIg");
	this.shape_44.setTransform(-14.225,-27.55);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgKQgGgJAAgOIAAgBQAAgMAGgLQAGgJAKgGQALgFAMAAQALAAAJAEQAKAFAGAKQAGAKAAAOIAAAHIg6AAQAAAIAFAFQAEAEAIAAQAGAAAEgDQADgCABgFIAbAAQgCAPgLAHQgLAIgSAAQgNAAgKgFgAAQgIQAAgIgEgEQgEgEgGAAQgHAAgDAEQgFAEgBAIIAeAAIAAAAg");
	this.shape_45.setTransform(-25.1,-26.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgFgJQgGgKAAgOIAAgBQAAgNAGgKQAGgKAKgFQAKgFAMAAQAKAAAJADQAJADAGAIQAGAIAAANIgbAAQAAgHgDgCQgEgEgFAAQgIABgDAFQgFAFAAAKIAAABQAAALAFAGQAEAFAHAAQAGAAADgDQAEgEACgHIAZAAQAAAKgFAJQgFAHgJAEQgKAFgNAAQgMAAgKgFg");
	this.shape_46.setTransform(-34.55,-26.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgZApQgGgCgFgGQgDgFgBgJQABgPALgFQAMgGAUAAIAIAAIAAgCQAAgHgCgDQgCgDgHgBQgEABgDACQgDADAAAEIgbAAQABgKAEgHQAGgHAJgDQAIgDALAAQALAAAJADQAIADAFAHQAEAIAAALIAAA1IgbAAIAAgKQgDAFgGADQgFAEgKAAQgHAAgHgDgAgHAKQgEACAAAFQAAADACACQADACAFAAQAFAAAEgDQAEgDAAgGIAAgEIgIAAQgHAAgEACg");
	this.shape_47.setTransform(-44.1,-26.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgRA9IAAg/IgKAAIAAgUIAKAAIAAgHQAAgPAJgIQAIgIAPAAIAHABIAGABIAAAVIgEgBIgEAAQgFAAgCADQgCACAAAEIAAAHIARAAIAAAUIgRAAIAAA/g");
	this.shape_48.setTransform(-51.475,-28.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgbAlQgKgIAAgOIAaAAQABAFACACQADADAFAAQAFAAADgCQACgCAAgDQAAgDgDgCQgEgCgHAAQgMgCgGgDQgIgDgCgFQgEgFAAgIQAAgKAFgGQAFgGAIgDQAIgDAKAAQAOAAAKAGQAKAGACAPIgaAAQgBgEgDgCQgCgCgEAAQgFAAgCABQgCACgBAEQABADADABQADABAHABQAMACAHADQAIADADAEQAEAFAAAJQAAAPgKAHQgKAHgSAAQgQAAgLgHg");
	this.shape_49.setTransform(-61.85,-26.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgsA5IAAhxIAsAAQAWAAAMAKQALAKAAASIAAABQAAARgMAJQgLAKgWAAIgLAAIAAAmgAgLgDIAJAAQAHAAAEgDQAFgEAAgHIAAgBQAAgHgFgDQgEgEgGAAIgKAAg");
	this.shape_50.setTransform(-70.825,-28.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgeA0QgNgIgHgNQgHgNAAgSIAAAAQAAgRAIgNQAHgNAOgIQAOgHAQAAQANAAAMAEQAMAFAIAJQAHAJABAPIghAAQAAgIgGgEQgFgFgJAAQgLABgHAIQgHAJAAAPIAAABQAAAJACAIQADAHAGAEQAGAFAJAAQAIAAAFgCQAEgDADgDQACgEAAgFIgVAAIAAgWIA2AAIAAANQAAAPgHALQgFAMgNAGQgMAHgTAAQgSAAgOgHg");
	this.shape_51.setTransform(-82.7,-28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91,-42.8,182,85.6);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAJgGAMAAQAMAAAKAFQAJAEAGAJQAFALABAOIAAAHIg6AAQAAAIAFAEQAEAFAIABQAGgBAEgDQADgDABgDIAbAAQgCAOgLAHQgLAIgTAAQgMAAgKgFgAAQgIQgBgIgDgEQgDgEgIAAQgFAAgFAEQgDAEgBAIIAdAAIAAAAg");
	this.shape.setTransform(25.45,13);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUAnQgLgFgFgJQgGgJAAgPIAAgBQAAgNAGgKQAGgJAKgGQAKgFALAAQALAAAJADQAJAEAGAIQAFAHACANIgcAAQAAgHgDgCQgEgDgFAAQgHAAgFAEQgDAGAAAKIAAABQAAALADAGQAFAFAHAAQAGAAAEgEQADgDABgHIAaAAQgBAKgEAJQgFAIgJADQgJAFgOAAQgLAAgKgFg");
	this.shape_1.setTransform(16,13);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbAqIAAhSIAcAAIAAARQAEgKAGgEQAHgFAKABIAAAbQgNgBgHAEQgHAEAAAKIAAAng");
	this.shape_2.setTransform(8.175,12.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAJgGAMAAQAMAAAKAFQAJAEAGAJQAFALABAOIAAAHIg6AAQAAAIAFAEQAEAFAIABQAGgBAEgDQADgDABgDIAbAAQgCAOgLAHQgLAIgTAAQgMAAgKgFgAAQgIQgBgIgDgEQgDgEgIAAQgFAAgFAEQgDAEgBAIIAdAAIAAAAg");
	this.shape_3.setTransform(-0.2,13);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_4.setTransform(-7.325,11.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgRA9IAAg/IgKAAIAAgUIAKAAIAAgHQAAgPAJgIQAIgIAPAAIAHABIAGABIAAAVIgEgBIgEAAQgFAAgCADQgCACAAAEIAAAHIARAAIAAAUIgRAAIAAA/g");
	this.shape_5.setTransform(-12.825,11.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAkQgLgHAAgNIAaAAQABAEADACQACADAFAAQAGAAACgCQACgCABgDQgBgDgDgCQgEgCgHgBQgLgBgIgDQgGgDgEgEQgDgGAAgJQAAgJAFgGQAFgGAIgDQAIgDAKAAQAPAAAJAGQAKAGACAPIgaAAQgBgEgDgCQgCgCgEAAQgEAAgDABQgCACAAAEQAAADADABQADACAHABQAMABAHACQAHADAFAFQADAFAAAJQAAAPgKAHQgKAHgRAAQgSAAgJgIg");
	this.shape_6.setTransform(-23.2,13);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_7.setTransform(-29.625,11.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNA8IAAh3IAbAAIAAB3g");
	this.shape_8.setTransform(-37.475,11.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAqQgGgDgEgFQgEgHgBgIQABgPAMgFQALgGAUgBIAIAAIAAgBQABgHgDgDQgCgDgHgBQgFABgDACQgCADAAAEIgbAAQAAgKAFgGQAGgHAJgEQAJgDAKAAQAMAAAIADQAJAEAEAHQAFAGgBAMIAAA1IgbAAIAAgKQgDAFgGADQgFAEgKAAQgIAAgGgCgAgHAJQgEADAAAFQAAAEADABQACADAFAAQAFAAAEgEQAEgDAAgGIAAgEIgIAAQgHAAgEABg");
	this.shape_9.setTransform(-44.7,13);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJAtQgHgIAAgPIAAgjIgLAAIAAgUIALAAIAAgRIAbAAIAAARIARAAIAAAUIgRAAIAAAhQAAAEACADQADACAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNAAgIgGg");
	this.shape_10.setTransform(-52.375,12.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_11.setTransform(-57.675,11.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgsA5IAAhvIAcAAIAAANQAEgGAHgEQAGgFAIAAQALAAAHAFQAIAFAGAJQAEAKAAAPIAAABQAAANgEAKQgGAJgIAFQgHAFgLAAQgJAAgFgEQgHgEgEgHIAAApgAgMgdQgEAFAAAMIAAABQAAAKAEAFQAFAFAHAAQAHAAAFgFQAEgFAAgKIAAgBQAAgMgEgFQgFgGgHAAQgHAAgFAGg");
	this.shape_12.setTransform(-65,14.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgZAqQgHgDgDgFQgEgHgBgIQABgPAMgFQALgGAUgBIAIAAIAAgBQABgHgDgDQgCgDgHgBQgFABgDACQgCADAAAEIgbAAQAAgKAFgGQAGgHAIgEQAKgDAKAAQALAAAJADQAJAEAEAHQAFAGgBAMIAAA1IgbAAIAAgKQgDAFgGADQgFAEgKAAQgHAAgHgCgAgHAJQgEADAAAFQAAAEADABQACADAFAAQAFAAAEgEQAEgDAAgGIAAgEIgIAAQgHAAgEABg");
	this.shape_13.setTransform(-75.2,13);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAnQgJgFgGgJQgGgJAAgPIAAgBQAAgNAGgKQAGgJAKgGQAKgFALAAQALAAAJADQAJAEAGAIQAFAHACANIgbAAQgBgHgEgCQgCgDgHAAQgGAAgEAEQgFAGAAAKIAAABQAAALAFAGQADAFAIAAQAGAAADgEQAFgDABgHIAZAAQgBAKgEAJQgFAIgJADQgKAFgNAAQgLAAgLgFg");
	this.shape_14.setTransform(-84.3,13);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbAqIAAhSIAcAAIAAARQAEgKAGgEQAHgFAKABIAAAbQgNgBgHAEQgHAEAAAKIAAAng");
	this.shape_15.setTransform(32.275,-6.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAnQgLgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAKgGAMAAQANAAAKAGQALAEAGAKQAGAKAAANIAAABQAAANgGAKQgGAKgLAEQgKAGgNAAQgMAAgKgFgAgLgQQgEAFAAALIAAABQAAALAEAFQAEAGAHgBQAIABAEgGQAFgFAAgLIAAgBQAAgKgEgGQgFgGgIAAQgHAAgEAGg");
	this.shape_16.setTransform(23.675,-6.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgRA9IAAg/IgKAAIAAgUIAKAAIAAgHQAAgPAJgIQAIgIAPAAIAHABIAGABIAAAVIgEgBIgEAAQgFAAgCADQgCACAAAEIAAAHIARAAIAAAUIgRAAIAAA/g");
	this.shape_17.setTransform(15.875,-8.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANArIAAgwQAAgGgDgEQgDgDgGAAQgFAAgEADQgEAEAAAIIAAAuIgdAAIAAhTIAdAAIAAAOQADgHAHgFQAGgEAKAAQANAAAHAIQAIAIAAAPIAAA2g");
	this.shape_18.setTransform(4.675,-7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgWAnQgLgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAKgGAMAAQANAAAKAGQALAEAGAKQAGAKAAANIAAABQAAANgGAKQgGAKgLAEQgKAGgNAAQgMAAgKgFgAgLgQQgEAFAAALIAAABQAAALAEAFQAEAGAHgBQAIABAEgGQAFgFAAgLIAAgBQAAgKgEgGQgFgGgIAAQgHAAgEAGg");
	this.shape_19.setTransform(-5.325,-6.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_20.setTransform(-12.625,-8.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJAsQgHgGAAgQIAAgjIgLAAIAAgUIALAAIAAgRIAbAAIAAARIARAAIAAAUIgRAAIAAAhQAAAFACABQADADAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNABgIgIg");
	this.shape_21.setTransform(-18.225,-7.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNA8IAAhSIAbAAIAABSgAgKgjQgFgEAAgGQAAgHAFgEQAEgDAGAAQAHAAAEADQAEAEABAHQgBAGgEAEQgEAFgHAAQgGAAgEgFg");
	this.shape_22.setTransform(-23.525,-8.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgJAsQgHgGAAgQIAAgjIgLAAIAAgUIALAAIAAgRIAbAAIAAARIARAAIAAAUIgRAAIAAAhQAAAFACABQADADAEAAIAEAAIAEgBIAAAVIgHABIgJABQgNABgIgIg");
	this.shape_23.setTransform(-29.125,-7.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgVAnQgKgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAJgGAMAAQAMAAAKAEQAJAFAGAJQAFALABAOIAAAHIg6AAQABAIAEAEQAFAFAGABQAIgBADgDQADgCABgFIAbAAQgCAOgLAIQgKAIgUAAQgMAAgKgFgAAQgIQgBgIgDgEQgDgEgIAAQgFAAgFAEQgDAEgCAIIAeAAIAAAAg");
	this.shape_24.setTransform(-36.85,-6.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgsA5IAAhvIAdAAIAAANQADgGAGgFQAHgEAJAAQAKAAAIAFQAHAFAFAJQAFAKAAAPIAAABQAAANgFAKQgFAJgHAFQgIAFgKAAQgKAAgGgEQgHgEgCgHIAAApgAgMgdQgEAGAAALIAAABQAAAKAEAFQAEAFAIAAQAHAAAEgFQAFgFAAgKIAAgBQAAgLgFgGQgEgGgHAAQgIAAgEAGg");
	this.shape_25.setTransform(-46.6,-5.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAmArIAAgxQAAgGgDgDQgDgDgFAAQgGAAgDADQgEAEAAAGIAAAwIgbAAIAAgxQAAgGgDgDQgDgDgFAAQgGAAgDADQgEAEAAAGIAAAwIgcAAIAAhTIAcAAIAAANQAEgGAGgFQAHgEAKAAQAIAAAFADQAFAEADAHQAGgHAHgEQAHgDAIAAQAIAAAGADQAGAEAEAHQADAHAAAKIAAA2g");
	this.shape_26.setTransform(-59.375,-7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAnQgLgFgGgJQgGgKAAgOIAAgBQAAgNAGgKQAGgJALgFQAKgGAMAAQANAAAKAGQALAEAGAKQAGAKAAANIAAABQAAANgGAKQgGAKgLAEQgKAGgNAAQgMAAgKgFgAgLgQQgEAFAAALIAAABQAAALAEAFQAEAGAHgBQAIABAEgGQAFgFAAgLIAAgBQAAgKgEgGQgFgGgIAAQgHAAgEAGg");
	this.shape_27.setTransform(-71.825,-6.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgdA0QgNgIgHgNQgHgNABgSIAAAAQAAgRAIgNQAHgOANgHQANgHAQAAQAPAAALAEQAMAFAHAKQAGAKACAPIgiAAQgBgJgEgFQgFgEgJAAQgKAAgHAIQgFAIgBAQIAAAAQABAQAFAJQAHAHAKABQAKgBAFgEQAGgFABgJIAgAAQAAAPgIAKQgGAKgMAFQgMAFgPAAQgSAAgOgHg");
	this.shape_28.setTransform(-82.85,-8.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91,-22.9,182,45.8);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgWAiQgKgMAAgUQABgMADgKQADgIAFgGQAGgFAGgDQAGgCAGAAQAFAAAGACQAHACADADQAFAEABAGIgOAEQgCgIgDgFQgFgEgGgBQgEABgEAEQgEAEgDAJQgCAKAAANQAEgGAHgCQAFgEAFAAQAIABAHADQAFADAEAGQAEAGgBAJQABAJgEAGQgEAHgHADQgHAFgJAAQgQAAgIgMgAgIgDQgFACgDAEIABAPIAEAMQACAGAEACQAEAEAEAAQAEAAAEgEQAEgDABgFQACgFAAgGQAAgIgDgGQgCgEgEgDQgFgCgFAAIgBAAQgDAAgDABg");
	this.shape.setTransform(5.05,8.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAsIAAgCIAXgZIAIgLQAFgGADgFQADgGAAgHQAAgIgEgEQgFgEgHgBQgEAAgEACQgEACgDADQgEAEgCAFIgBgBQABgGADgFQAEgGAGgDQAGgDAHAAQAMAAAHAGQAGAGABAMQgBAJgFAJQgGAHgJAIIgWATIAbAAIAJgBQAEgBACgDIACgJIACAAIgDAZg");
	this.shape_1.setTransform(-2.4,8.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAnQgIgGgEgKQgEgLAAgMQAAgMAEgKQAEgKAIgGQAIgGAKAAQAMAAAHAGQAIAGAEAKQAEAKAAAMQAAAMgEALQgEAKgIAGQgHAGgMABQgKgBgIgGgAgKgkQgEAFgDAIQgCAIAAALIABAPIAEAPQADAHAEAFQAEADAFABQAFAAAEgFQAEgEADgJQACgIAAgLIgBgOQgBgJgDgGQgDgIgEgEQgEgEgFgBQgFABgEAEg");
	this.shape_2.setTransform(-9.825,8.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdAsIAAgCIAWgZIAIgLQAFgGADgFQADgGAAgHQAAgIgEgEQgFgEgGgBQgFAAgEACQgEACgDADQgDAEgDAFIgBgBQABgGAEgFQADgGAGgDQAGgDAHAAQAMAAAHAGQAGAGAAAMQAAAJgFAJQgGAHgJAIIgWATIAbAAIAJgBQAEgBACgDIACgJIACAAIgDAZg");
	this.shape_3.setTransform(-17.5,8.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHAkQgFgFAAgIIAAgtIgHAAIAAgBIASgRIACAAIAAAPIATAAIAAADIgTAAIAAAsQAAAFACAEQADADAFAAIAFgBIADgCIABAAIgDAFQgCACgDABQgDACgFAAQgHAAgEgFg");
	this.shape_4.setTransform(-26.1,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAiIAAgCIAHgCQACgCAAgEIAAgqQAAgDgCgCQgBgCgEAAIgDAAIAAgCIAVgGIACAAIAAATQADgJAEgFQAFgFAGAAIADABIADABIgBAMIgEgCIgEAAQgEAAgFADQgEADgCAFIAAAiQAAAEACACQADABAGABIAAACg");
	this.shape_5.setTransform(-31.025,9.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgDgHQgEgIgBgKQABgJAEgIQAEgIAGgFQAIgFAIAAQAJAAAIAFQAGAEAEAHQAEAIAAAKQABAJgFAIQgEAIgHAFQgHAEgJABQgJgBgHgEgAgJgbQgEAEgCAGQgCAGAAAIIABALQACAGACAFQACAGAEADQAEADADAAQAFAAAEgEQAEgDACgGQACgGAAgIIgBgLQgBgGgDgFQgDgGgDgDQgEgDgEAAQgFAAgDADg");
	this.shape_6.setTransform(-37.4,9.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAvIAAgCIAHgDQACgBAAgEIAAhEQAAgDgCgBQgBgCgEgBIgDAAIAAgCIAVgFIACAAIAAAOQADgGAFgFQAFgDAGAAQAJAAAGAEQAFAEAEAIQADAHAAAJQAAAMgEAHQgEAIgHAFQgHAEgIAAQgFAAgEgCQgEgDgDgDIAAAWQAAAEADABQADACAFABIAAACgAgFgiQgEADgCAFIAAAZQAAAEACAFQACAEADADQAEADAEABQAFgBAEgEQAEgDACgGQACgGAAgHQAAgHgCgHQgCgGgEgEQgEgFgGAAQgEAAgEADg");
	this.shape_7.setTransform(-45.125,11);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAeQgHgEgDgIQgEgHAAgKQAAgJAEgIQAEgJAHgEQAHgFAJAAQAIAAAGAEQAGAEACAGQADAHAAAIIgrAAIAAABIAAABQAAAIADAGQADAGAFAEQAFADAHAAQAHAAAFgDQAEgDADgFIACABQgCAGgDAEQgEAFgGADQgFADgHAAQgJgBgHgEgAAPgJQAAgFgCgFQgCgFgDgDQgDgDgEAAQgEAAgDADQgDADgCAEQgDAFAAAGIAdAAIAAAAg");
	this.shape_8.setTransform(-52.325,9.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAsIgCgEIgBgDIgWggIgJAAIAAAbQAAAGADABQACACAHAAIAAADIgmAAIAAgDQAGAAADgCQADgBAAgGIAAg/QAAgGgDgBQgDgCgGgBIAAgBIAnAAQAJAAAIACQAHADAEAFQAFAGAAAIQAAAKgGAFQgGAFgKACIAVAeIAGAFQAEACAEAAIAAADgAgQACIAKAAQAKgBAFgEQAGgGAAgJQAAgKgGgFQgFgGgKAAIgKAAg");
	this.shape_9.setTransform(-60.15,8.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbAuIgEgBIAEgMIAFACIAFABQAFAAADgDQAEgDACgGIACgGIgYg2IgEgGQgCgBgDgBIAAgBIAeAAIAAABQgEAAgCACQgCADABADIAQAmIARgmQABgDgBgDQgCgCgEAAIAAgBIATAAIAAABQgDABgCABIgEAGIgaA9QgEAKgFAFQgGAHgIgBIgEAAg");
	this.shape_10.setTransform(58.475,-4.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgIAkQgDgFAAgIIAAgtIgIAAIAAgCIATgQIAAAAIAAAPIATAAIAAADIgTAAIAAAsQABAFACAEQADADAEAAIAGgBIADgCIABAAIgDAFQgCACgEABQgCACgGAAQgGAAgFgFg");
	this.shape_11.setTransform(52.6,-6.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAwIAAgCQAEgBACgBQACgCAAgEIAAgqQAAgDgBgCQgCgCgEAAIgDAAIAAgCIAUgGIADAAIAAA5QAAAEACACIAFACIAAACgAgFgfQgDgDABgEQgBgDADgDQADgCADgBQAEABADACQACADAAADQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_12.setTransform(48.35,-6.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAPAjIgBgPQgFAHgGAEQgEAEgGAAQgJAAgGgGQgEgFAAgKIAAghQAAgDgCgCQgBgCgEAAIgDAAIAAgCIAVgGIACAAIAAAwQAAAFADAEQADADAFAAQADAAAEgCQAFgDAEgFIAAgjQAAgDgCgCQgBgCgDAAIgEAAIAAgCIAWgGIACAAIAAA2QgBADACACQACACADAAIADAAIAAACIgUAGg");
	this.shape_13.setTransform(42.6,-5.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAAAvIAAgCQAHgBACgCQADgBAAgEIAAgdQgBAEgDADQgDAEgEACQgDACgFAAQgIAAgGgEQgGgFgDgHQgDgHAAgIQAAgMAEgJQAEgIAHgEQAHgFAIABQAFAAAFACQAEACADAEIAKgIIACAAIAABSQAAAEACABIAGADIAAACgAgLglQgEAEgCAGQgCAGgBAHQAAAIACAGQACAGAEAEQAEAFAGgBQAEAAAEgDQAFgDABgFIAAgaIgBgJQgCgDgEgDQgDgCgFgBQgFABgDADg");
	this.shape_14.setTransform(35.175,-4.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgjAsIAAgDQAFAAAEgCQACgBAAgGIAAg/QAAgGgCgBQgEgCgFgBIAAgBIBCAAIAEAYIgCAAQgCgKgGgFQgGgFgJgBIgTAAIAAAlIANAAQAEAAADgCQADgBABgCIABgIIACAAIAAAcIgCAAIgBgHQgBgCgDgCQgDgCgEABIgNAAIAAAfQgBAEACACQACACADAAIAOAAQAKAAAGgFQAFgGADgJIACAAIgEAYg");
	this.shape_15.setTransform(26.95,-6.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOAeQgHgEgDgIQgEgHAAgKQAAgJAEgIQAEgJAHgEQAHgFAJAAQAIAAAGAEQAGAEACAGQADAHAAAIIgrAAIAAABIAAABQAAAIADAGQADAGAFAEQAFADAHAAQAHAAAFgDQAEgDADgFIACABQgCAGgDAEQgEAFgGADQgFADgHAAQgJgBgHgEgAAPgJQAAgFgCgFQgCgFgDgDQgDgDgEAAQgEAAgDADQgDADgCAEQgDAFAAAGIAdAAIAAAAg");
	this.shape_16.setTransform(16.475,-5.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgHAkQgFgFAAgIIAAgtIgHAAIAAgCIASgQIACAAIAAAPIATAAIAAADIgTAAIAAAsQAAAFACAEQADADAFAAIAFgBIADgCIABAAIgDAFQgCACgDABQgDACgFAAQgHAAgEgFg");
	this.shape_17.setTransform(10.8,-6.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAJAjIgBgRQgBAFgDAEQgDADgEACQgFADgEAAQgJAAgEgFQgFgEAAgIQAAgGADgFQADgEAHgDQAGgCALgCIAIgCIAAgFQAAgJgDgFQgEgFgGAAQgFAAgDADQgDADgBAFQgBAEACAFIgLADQgEgHADgGQADgGAGgEQAHgDAJgBQALABAHAGQAGAGABALIAAAeQgBADACACQACACAEAAIACAAIAAACIgUAGgAAAgBQgIABgEAEQgEAEgBAHQABAFADADQACAEAGAAQADAAACgDQADgCADgEQACgDAAgGIAAgLg");
	this.shape_18.setTransform(5.3,-5.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAAAiIgZg5QgCgEgCgCQgCgCgDAAIAAgCIAfAAIAAACQgFAAgCACQgCACABAEIAQAnIARgnQABgEgBgCQgCgCgEAAIAAgCIATAAIAAACQgDAAgCACQgCACgCAEIgZA5g");
	this.shape_19.setTransform(-1.9,-5.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgNAwIAAgCQAEgBACgBQACgCAAgEIAAgqQAAgDgCgCQgBgCgEAAIgDAAIAAgCIAUgGIADAAIAAA5QAAAEACACIAGACIAAACgAgFgfQgDgDABgEQgBgDADgDQADgCADgBQADABAEACQACADAAADQAAAEgCADQgEACgDAAQgDAAgDgCg");
	this.shape_20.setTransform(-7.35,-6.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWAiIAAgCIAHgCQACgCAAgEIAAgqQAAgDgCgCQgBgCgEAAIgDAAIAAgCIAVgGIACAAIAAATQADgJAEgFQAFgFAGAAIADABIADABIgBAMIgEgCIgEAAQgEAAgFADQgEADgCAFIAAAiQAAAEACACQADABAGABIAAACg");
	this.shape_21.setTransform(-11.825,-5.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgkAsIAAgDQAHAAACgCQAEgBAAgGIAAg/QAAgGgEgBQgCgCgHgBIAAgBIAmAAQALAAAHACQAIADAEAFQAFAGgBAIQABAIgFAFQgEAFgIACQgHADgLAAIgMAAIAAAbQABAGACABQADACAFAAIAAADgAgKACIAKAAQAKgBAGgEQAFgGABgJQAAgKgHgFQgEgGgLAAIgKAAg");
	this.shape_22.setTransform(-18.55,-6.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNAuIAAgCIAGgCQACgBAAgFIAAhDQAAgDgBgBQgCgCgEAAIgCAAIAAgCIATgGIACAAIAABRQAAAFACABIAGACIAAACg");
	this.shape_23.setTransform(-27.55,-6.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAJAjIgBgRQgBAFgDAEQgDADgEACQgFADgEAAQgJAAgEgFQgFgEAAgIQAAgGADgFQADgEAHgDQAGgCALgCIAIgCIAAgFQAAgJgDgFQgEgFgGAAQgFAAgDADQgEADAAAFQgBAEACAFIgLADQgEgHADgGQADgGAGgEQAHgDAKgBQALABAGAGQAHAGAAALIAAAeQAAADABACQACACADAAIADAAIAAACIgVAGgAAAgBQgIABgEAEQgFAEAAAHQAAAFAEADQACAEAGAAQADAAACgDQADgCADgEQACgDAAgGIAAgLg");
	this.shape_24.setTransform(-32.6,-5.475);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgFAsQgFgBgDgFIgJAJIgCAAIAAhPQAAgDgCgBQgCgCgDAAIgDAAIAAgCIAVgGIACAAIAAAoIAEgIQADgDAEgCQADgCAFAAQAIAAAGAEQAGAEADAIQAEAGAAAJQgBAMgEAIQgEAIgHAFQgHAEgIAAQgFAAgEgDgAgCgMIgGAEIgDAGIAAAYQAAAFACAFQABAEAEADQADADAFABQAFgBAEgEQADgDADgGQACgHAAgHIgBgKQgBgFgDgEQgCgFgDgCQgEgDgEAAIgFACg");
	this.shape_25.setTransform(-40.275,-6.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgDgHQgFgIAAgKQAAgJAFgIQADgIAIgFQAHgFAJAAQAIAAAHAFQAHAEAFAHQADAIAAAKQAAAJgEAIQgEAIgHAFQgHAEgJABQgJgBgHgEgAgKgbQgDAEgCAGQgCAGAAAIIACALQAAAGADAFQACAGAEADQAEADAEAAQAEAAAEgEQAEgDABgGQACgGABgIIgCgLQgBgGgCgFQgDgGgDgDQgEgDgEAAQgFAAgEADg");
	this.shape_26.setTransform(-47.6,-5.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgNAuIAAgCIAGgCQACgBAAgFIAAhDQAAgDgBgBQgCgCgEAAIgCAAIAAgCIATgGIACAAIAABRQAAAFACABIAGACIAAACg");
	this.shape_27.setTransform(-53.2,-6.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgXAnQgKgFgGgKQgFgKAAgMQAAgNAFgLQAGgKAKgGQAKgGANAAQAIAAAHACQAHADAFAEQAFAEABAGIgMAEQgDgJgFgFQgHgFgHgBQgJAAgFAGQgHAFgDAIQgEAKAAAMQAAAKAFAKQAEAKAHAGQAHAGAJgBIAJgBQAEgBADgDIAAgXQAAgGgDgCQgCgDgIAAIAAgCIAnAAIAAACQgGAAgDADQgDADAAAFIAAAQQgDAFgFAEQgGADgGACQgHACgHABQgNAAgJgHg");
	this.shape_28.setTransform(-59.85,-6.55);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#C20000").s().p("AqaCnIAAlNIU1AAIAAFNg");
	this.shape_29.setTransform(-0.275,1.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67,-18.3,134.1,36.7);


// stage content:
(lib.v11PE2026FTABMTargeting300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// EYEBROW
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(97,107.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({y:84.05,alpha:1},10).wait(100));

	// TITLE_W_EYEBROW_copy
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(118.95,150.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(97).to({_off:false},0).to({y:125.2,alpha:1},9).wait(17));

	// TITLE_W_EYEBROW
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.setTransform(118.95,179);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).to({y:145.1,alpha:1},13).to({startPosition:0},44).to({y:131.05,alpha:0,mode:"single"},9).wait(28));

	// CTA
	this.instance_3 = new lib.Tween5("synched",0);
	this.instance_3.setTransform(88.6,245.7);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween6("synched",0);
	this.instance_4.setTransform(88.6,209.7);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(108).to({_off:false},0).to({_off:true,y:209.7,alpha:1},11,cjs.Ease.cubicInOut).wait(4));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(108).to({_off:false},11,cjs.Ease.cubicInOut).to({startPosition:0},3,cjs.Ease.cubicInOut).wait(1));

	// LOGO
	this.Logo__300x250_ = new lib.StackedWhiteRGB();
	this.Logo__300x250_.name = "Logo__300x250_";
	this.Logo__300x250_.setTransform(69.95,38.75,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.Logo__300x250_).wait(123));

	// RED_BAR
	this.instance_5 = new lib.Tween7("synched",0);
	this.instance_5.setTransform(-157.85,242.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({_off:false},0).to({x:150},10).wait(112));

	// SHADOW
	this.instance_6 = new lib.Rectangle_2();
	this.instance_6.setTransform(117.5,117.5,1,1,0,0,0,117.5,117.5);
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(123));

	// BACKGROUND_FOREGROUND
	this.instance_7 = new lib.Tween9("synched",0);
	this.instance_7.setTransform(205,124);

	this.instance_8 = new lib.Tween10("synched",0);
	this.instance_8.setTransform(239.5,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7}]}).to({state:[{t:this.instance_8}]},122).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true,x:239.5},122).wait(1));

	// BACKGROUND_MOUNTAINS
	this.instance_9 = new lib.Tween11("synched",0);
	this.instance_9.setTransform(236.65,128.5,1.2978,1.2977,0,0,0,-0.3,-0.4);

	this.instance_10 = new lib.Tween12("synched",0);
	this.instance_10.setTransform(239,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).to({state:[{t:this.instance_10}]},122).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:239,y:124},122).wait(1));

	// BACKGROUND_SKY
	this.instance_11 = new lib.Tween13("synched",0);
	this.instance_11.setTransform(240.9,124);

	this.instance_12 = new lib.Tween14("synched",0);
	this.instance_12.setTransform(239.5,124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11}]}).to({state:[{t:this.instance_12}]},122).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true,x:239.5},122).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/1FMAx/AAAMAAAAqLMgx/AAAg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape_1.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(123));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-157.9,84,707.8,215);
// library properties:
lib.properties = {
	id: 'CF2E21AC0BD3F64D9646184FB7F6A19C',
	width: 300,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1.png", id:"v1_1_PE2026_FT_ABMTargeting_300x250_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['CF2E21AC0BD3F64D9646184FB7F6A19C'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;