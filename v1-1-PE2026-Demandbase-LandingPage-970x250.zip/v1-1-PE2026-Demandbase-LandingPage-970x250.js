(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1", frames: [[0,0,1181,251],[0,253,1181,251],[0,506,1180,251]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._970x250foreground = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._970x250mountain = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._970x250sky = function() {
	this.initialize(ss["v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Rectangle_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.8)","rgba(0,0,0,0.239)","rgba(0,0,0,0)"],[0,0.878,1],-310.9,0,311,0).s().p("EgwlAUOMAAAgobMBhKAAAMAAAAobg");
	this.shape.setTransform(310.95,129.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_1, new cjs.Rectangle(0,0,621.9,258.9), null);


(lib.Tween36 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250sky();
	this.instance.setTransform(-592.35,-126,1.004,1.004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-592.3,-126,1184.6999999999998,252);


(lib.Tween35 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250sky();
	this.instance.setTransform(-592.35,-126,1.004,1.004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-592.3,-126,1184.6999999999998,252);


(lib.Tween34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250mountain();
	this.instance.setTransform(-597.55,-127,1.0119,1.0119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-597.5,-127,1195.1,254);


(lib.Tween33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250mountain();
	this.instance.setTransform(-597.55,-127,1.0119,1.0119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-597.5,-127,1195.1,254);


(lib.Tween32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250foreground();
	this.instance.setTransform(-597.55,-127,1.0119,1.0119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-597.5,-127,1195.1,254);


(lib.Tween31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x250foreground();
	this.instance.setTransform(-597.55,-127,1.0119,1.0119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-597.5,-127,1195.1,254);


(lib.Tween30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("AhjTiMAAAgnDIDHAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-125,20,250);


(lib.Tween29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C20000").s().p("AhjTiMAAAgnDIDHAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-125,20,250);


(lib.Tween28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah/CAQg2g1AAhLQAAhKA2g1QA1g1BKAAQAOAAAPACIgQAUIgNAAQg+AAgsAsQgtArAAA+QAAA9AtArQAsAsA+AAQBAAAAsgsQAtgrAAg9QAAgvgbgmQgbgmgrgQIgGgZQA6ARAlAvQAlAxAAA8QAABLg1A1Qg2A1hLAAQhKAAg1g1gAg8gTIBbh3IAhCTg");
	this.shape.setTransform(41.825,-0.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAWAoIgIgQIgdAAIgIAQIgOAAIAlhPIAmBPgAAKALIgKgWIgJAWIATAAg");
	this.shape_1.setTransform(-7.45,14.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSgGIAAAtIgOAAIAAhPIAzAvIAAguIAOAAIAABQg");
	this.shape_2.setTransform(1.7,14.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAjQgHgGAAgKQAAgNAQgJQgJgKAAgIQAAgIAHgGQAGgFALgBQAIAAAHAGQAGAFAAAIQAAANgSAJIAOAOIAIgMIAMAAIgOAUIAPARIgPAAIgHgIQgJAKgNAAQgLABgHgHgAgLAEQgEACgDAEQgEAFAAAEQAAAMAPAAQAHAAAGgHIgQgVgAgPgVQAAAGAJAIQAMgHAAgIQAAgJgJAAQgMAAAAAKg");
	this.shape_3.setTransform(-56.475,14.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBnIAAjOIAyAAQAlAAAUAOQAUAOAAAaQAAAPgHALQgIAMgNAFQAoAMAAAmQAAAdgVAPQgUAPgnAAgAgeBJIARAAQArgBAAgbQAAgRgLgGQgLgHgVAAIgRAAgAgegPIAIAAQAWAAAJgGQAKgHAAgPQAAgPgKgHQgKgHgWABIgGAAg");
	this.shape_4.setTransform(-52.35,-5.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA5BpIgTgsIhPAAIgTAsIgoAAIBkjRIBlDRgAAYAcIgYg6IgZA6IAxAAg");
	this.shape_5.setTransform(-32.3,-5.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTBnIAAjOIAnAAIAADOg");
	this.shape_6.setTransform(-15.175,-5.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgwgSIAAB5IgnAAIAAjSICJB+IAAh6IAmAAIAADTg");
	this.shape_7.setTransform(4.55,-5.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYgCIgKApIgOAAIAThPIAdA0IAcg0IAVBPIgPAAIgKgpIgYArg");
	this.shape_8.setTransform(-24.625,14.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAnIAAhOIATAAQAgAAAAAZQAAAMgKAGQgIAGgOAAIgEAAIAAAdgAgKgBIAEAAQAQAAAAgNQAAgNgQABIgEAAg");
	this.shape_9.setTransform(-14.575,14.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAnIAAggIgdguIARAAIASAgIAUggIARAAIgdAuIAAAgg");
	this.shape_10.setTransform(10.45,14.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAeQgMgMAAgSQAAgQANgMQALgMARAAQAUAAALAPIABABIgMAJIAAgBQgGgLgOAAQgKAAgIAIQgHAIAAALQgBAMAIAJQAHAIALAAQANAAAHgMIAAgBIAMAJIgBABQgKAPgVAAQgSAAgLgLg");
	this.shape_11.setTransform(-44.85,14.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAeQgMgMABgSQgBgRAMgLQANgMAQgBQASAAAMAMQAMAMgBARQABASgMALQgNAMgRAAQgQABgNgMgAgSgSQgIAIAAAKQAAANAIAHQAHAJALAAQALgBAHgIQAIgIAAgMQAAgMgHgHQgIgIgLAAQgLAAgHAJg");
	this.shape_12.setTransform(-35.3,14.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agpg5IBTA5IhTA5g");
	this.shape.setTransform(87.5,1.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_1.setTransform(66.125,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVBAIgegxIgNAAIAAAxIgcAAIAAh/IAtAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAhA2gAgWgEIARAAQAKAAAFgFQAGgEgBgKIAAAAQABgKgGgEQgFgEgKAAIgRAAg");
	this.shape_2.setTransform(54.65,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_3.setTransform(39.875,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_4.setTransform(26.525,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_5.setTransform(14.625,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQALAAAFgFQAGgEAAgKIAAAAQAAgKgGgEQgFgEgLAAIgQAAg");
	this.shape_6.setTransform(2.55,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_7.setTransform(-14.675,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_8.setTransform(-28.1,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-41.225,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_10.setTransform(-57.675,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_11.setTransform(-68.875,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgHgPgBgTIAAgBQAAgTAJgPQAIgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgHgGgMABQgKAAgIAFQgIAFgEAKQgEAJgBANIAAABQAAANAFAJQADAKAIAFQAIAGALAAQALAAAHgEQAHgEADgGQADgGABgHIgeAAIAAgVIA6AAIAAANQAAARgHANQgHANgNAHQgOAHgTAAQgVAAgOgIg");
	this.shape_12.setTransform(-82.5,1.6727);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.7,-14.2,183.5,28.4);


(lib.Tween26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agpg5IBTA5IhTA5g");
	this.shape.setTransform(87.5,1.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_1.setTransform(66.125,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVBAIgegxIgNAAIAAAxIgcAAIAAh/IAtAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAhA2gAgWgEIARAAQAKAAAFgFQAGgEgBgKIAAAAQABgKgGgEQgFgEgKAAIgRAAg");
	this.shape_2.setTransform(54.65,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_3.setTransform(39.875,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_4.setTransform(26.525,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_5.setTransform(14.625,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQALAAAFgFQAGgEAAgKIAAAAQAAgKgGgEQgFgEgLAAIgQAAg");
	this.shape_6.setTransform(2.55,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_7.setTransform(-14.675,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_8.setTransform(-28.1,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-41.225,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_10.setTransform(-57.675,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_11.setTransform(-68.875,1.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgHgPgBgTIAAgBQAAgTAJgPQAIgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgHgGgMABQgKAAgIAFQgIAFgEAKQgEAJgBANIAAABQAAANAFAJQADAKAIAFQAIAGALAAQALAAAHgEQAHgEADgGQADgGABgHIgeAAIAAgVIA6AAIAAANQAAARgHANQgHANgNAHQgOAHgTAAQgVAAgOgIg");
	this.shape_12.setTransform(-82.5,1.6727);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.7,-14.2,183.5,28.4);


(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyBhQgVgNgKgYQgJgXAAggIAAgFQAAgiANgZQAMgYAWgNQAWgOAaAAQAlAAAUAQQAVAQAEAgIg5AAQgBgJgFgEQgFgFgLgBQgRABgKAOQgJAPgBAcQAHgMAMgGQAKgHAUgBQAUAAAQAJQAQAHAJAPQAKAPAAAXQAAAWgKARQgLARgTAJQgUAJgbAAQghABgVgOgAgRAOQgIAIAAAOQAAAOAIAIQAIAJAMAAQANAAAIgJQAHgIAAgOQAAgOgHgJQgIgHgNgBQgMAAgIAJg");
	this.shape.setTransform(204.7488,2.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhVBtIAAgJIBLhPQAPgRAJgOQAKgOAAgOQAAgLgGgGQgFgGgMgBQgKAAgHAIQgHAIgCATIg4AAQACgoAWgUQAXgVAmAAQAaAAATAJQARAJAJAPQAKAPAAAUQgBAWgLASQgLARgSARIgeAdIBIAAIAAAug");
	this.shape_1.setTransform(185.075,2.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BiQgWgMgMgYQgMgXAAgjIAAgIQAAghANgYQANgYAWgMQAWgNAcAAQAdAAAWAMQAWAMANAXQANAYAAAiIAAAHQAAAjgMAYQgNAYgWANQgWAMgeAAQgeAAgWgMgAgbgxQgKAPABAeIAAAIQgBAeAKAOQAJAPATAAQATAAAJgPQAJgPgBgeIAAgHQABgegJgPQgKgOgTAAQgSAAgJAOg");
	this.shape_2.setTransform(165.225,2.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVBtIAAgJIBLhPQAPgRAJgOQAKgOAAgOQAAgLgGgGQgFgGgMgBQgKAAgHAIQgHAIgCATIg4AAQACgoAWgUQAXgVAmAAQAaAAATAJQARAJAJAPQAKAPAAAUQgBAWgLASQgLARgSARIgeAdIBIAAIAAAug");
	this.shape_3.setTransform(144.825,2.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSBUQgOgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAHAAIAJgBIAHgCIAAApIgNADQgHABgKAAQgaABgOgNg");
	this.shape_4.setTransform(124,4.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_5.setTransform(112.125,5.6485);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrBJQgTgJgLgSQgLgSgBgaIAAgCQABgZALgSQALgSATgKQAUgKAXAAQAZAAATAJQATAKALASQAMASAAAZIAAACQAAAZgMATQgLASgTAKQgTAJgZAAQgXAAgUgJgAgWgfQgIAKAAAUIAAACQAAAUAIALQAIALAOAAQAPgBAIgKQAIgLAAgUIAAgBQAAgUgIgLQgHgKgQAAQgOAAgIAKg");
	this.shape_6.setTransform(95.975,5.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhUBrIAAjRIA2AAIAAAYQAHgMAMgIQAMgIARAAQASAAAPAJQAPAJAKASQAIASABAbIAAADQgBAagIASQgKASgPAJQgOAJgUAAQgRAAgMgIQgMgHgGgMIAABMgAgXg3QgIAKAAAUIAAADQAAAUAIAJQAIAKAPAAQAOAAAIgLQAIgJAAgTIAAgDQgBgUgHgKQgJgKgNAAQgPAAgIAKg");
	this.shape_7.setTransform(77.4,8.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_8.setTransform(58.375,5.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAbBrIgqhNIgPAAIAABNIg9AAIAAjVIBUAAQAqAAAWARQAWARAAAiIAAABQAAAXgLAOQgKAMgRAGIAzBZgAgegIIAUAAQAOAAAJgHQAHgGAAgOIAAgBQAAgNgIgFQgIgGgOAAIgUAAg");
	this.shape_9.setTransform(40.5,2.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgwBpIAahFIg/iMIA6AAIAgBUIAehUIAzAAIhVDRg");
	this.shape_10.setTransform(14.55,8.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_11.setTransform(-0.35,4.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_12.setTransform(-10.3,2.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgzBKQgMgGgHgNQgHgNAAgUIAAhlIA2AAIAABcQAAAOAFAGQAFAHAMAAQALAAAHgHQAHgIABgPIAAhZIA1AAIAACcIg1AAIAAgYQgHAMgMAIQgLAHgTAAQgQAAgLgGg");
	this.shape_13.setTransform(-24.175,5.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAfBrIAAhNQgGAMgNAIQgMAIgRAAQgTAAgOgJQgPgJgJgSQgJgRAAgbIAAgCQAAgbAJgSQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAgWIA1AAIAADRgAgVg3QgIAKAAAUIAAADQABAUAIAJQAIAKANAAQAOAAAJgKQAIgJAAgVIAAgCQAAgUgIgKQgIgKgPAAQgOAAgIAKg");
	this.shape_14.setTransform(-43.475,8.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhMBrIAAjVICUAAIAAAvIhWAAIAAAlIBEAAIAAArIhEAAIAAAnIBaAAIAAAvg");
	this.shape_15.setTransform(-61.35,2.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_16.setTransform(-85.925,5.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAfAAIAAAkIgfAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_17.setTransform(-100.95,4.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgwBOQgNgFgGgLQgIgKAAgRQAAgbAWgLQAWgMAmAAIAQAAIAAgEQAAgLgFgHQgEgGgNgBQgJABgFAFQgFAFgBAIIgyAAQABgTAKgMQAKgNAQgGQAQgGAVAAQAWAAAQAGQAPAGAJANQAJANAAAVIAABlIg0AAIAAgTQgGAJgLAHQgKAGgTAAQgOAAgMgEgAgPASQgHAEAAAJQAAAHAEAEQAFAEAKAAQAKAAAIgGQAHgGABgKIAAgKIgPAAQgPAAgIAEg");
	this.shape_18.setTransform(-115.5,5.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgcBOIg6ibIA5AAIAgBkIAghkIA0AAIg6Cbg");
	this.shape_19.setTransform(-132.025,5.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_20.setTransform(-145.3,2.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_21.setTransform(-155.775,5.6485);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhTBrIAAjVIBRAAQAsAAAVATQAVASAAAiIAAACQAAAhgWARQgVASgoAAIgXAAIAABIgAgWgGIASAAQAOAAAIgHQAHgHABgNIAAgBQgBgOgHgGQgIgGgOAAIgSAAg");
	this.shape_22.setTransform(-171.7,2.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_23.setTransform(-192.425,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgxBOQgLgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgLABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQARAGAIANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_24.setTransform(-205.9,5.725);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgMBrQgMgHgGgNIAAAYIg2AAIAAjhIA2AAIAABdQAHgMAMgIQAMgIARAAQATAAAOAJQAQAJAIASQAJARAAAbIAAADQAAAbgJASQgIASgQAJQgPAJgSAAQgSAAgMgIgAgXABQgJAKAAAUIAAACQAAAVAJAKQAIAKAPAAQAOAAAIgLQAHgKAAgTIAAgDQABgUgJgKQgIgJgNAAQgPAAgIAJg");
	this.shape_25.setTransform(-223.45,2.475);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgrBJQgTgJgLgSQgLgSgBgaIAAgCQABgZALgSQALgSATgKQAUgKAXAAQAZAAATAJQATAKALASQAMASAAAZIAAACQAAAZgMATQgLASgTAKQgTAJgZAAQgXAAgUgJgAgWgfQgIAKAAAUIAAACQAAAUAIALQAIALAOAAQAPgBAIgKQAIgLAAgUIAAgBQAAgUgIgLQgHgKgQAAQgOAAgIAKg");
	this.shape_26.setTransform(-242.825,5.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-256.525,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag5BhQgZgOgNgZQgNgYAAghIAAgBQAAghAPgZQAOgYAagOQAZgNAfgBQAaAAAWAIQAWAJAOARQAOASACAbIg9AAQgCgPgJgHQgKgIgRAAQgWAAgNAQQgNARAAAcIAAACQAAASAFAOQAFAOALAIQALAIARAAQAPAAAJgEQAKgFAEgHQAEgIABgIIgoAAIAAgqIBlAAIAAAZQAAAcgMAVQgMAWgYAMQgXANgjAAQgjAAgZgOg");
	this.shape_28.setTransform(-272.725,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-22.5,573.1,45.1);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyBhQgVgNgKgYQgJgXAAggIAAgFQAAgiANgZQAMgYAWgNQAWgOAaAAQAlAAAUAQQAVAQAEAgIg5AAQgBgJgFgEQgFgFgLgBQgRABgKAOQgJAPgBAcQAHgMAMgGQAKgHAUgBQAUAAAQAJQAQAHAJAPQAKAPAAAXQAAAWgKARQgLARgTAJQgUAJgbAAQghABgVgOgAgRAOQgIAIAAAOQAAAOAIAIQAIAJAMAAQANAAAIgJQAHgIAAgOQAAgOgHgJQgIgHgNgBQgMAAgIAJg");
	this.shape.setTransform(204.7488,2.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhVBtIAAgJIBLhPQAPgRAJgOQAKgOAAgOQAAgLgGgGQgFgGgMgBQgKAAgHAIQgHAIgCATIg4AAQACgoAWgUQAXgVAmAAQAaAAATAJQARAJAJAPQAKAPAAAUQgBAWgLASQgLARgSARIgeAdIBIAAIAAAug");
	this.shape_1.setTransform(185.075,2.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BiQgWgMgMgYQgMgXAAgjIAAgIQAAghANgYQANgYAWgMQAWgNAcAAQAdAAAWAMQAWAMANAXQANAYAAAiIAAAHQAAAjgMAYQgNAYgWANQgWAMgeAAQgeAAgWgMgAgbgxQgKAPABAeIAAAIQgBAeAKAOQAJAPATAAQATAAAJgPQAJgPgBgeIAAgHQABgegJgPQgKgOgTAAQgSAAgJAOg");
	this.shape_2.setTransform(165.225,2.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVBtIAAgJIBLhPQAPgRAJgOQAKgOAAgOQAAgLgGgGQgFgGgMgBQgKAAgHAIQgHAIgCATIg4AAQACgoAWgUQAXgVAmAAQAaAAATAJQARAJAJAPQAKAPAAAUQgBAWgLASQgLARgSARIgeAdIBIAAIAAAug");
	this.shape_3.setTransform(144.825,2.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSBUQgOgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAHAAIAJgBIAHgCIAAApIgNADQgHABgKAAQgaABgOgNg");
	this.shape_4.setTransform(124,4.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_5.setTransform(112.125,5.6485);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrBJQgTgJgLgSQgLgSgBgaIAAgCQABgZALgSQALgSATgKQAUgKAXAAQAZAAATAJQATAKALASQAMASAAAZIAAACQAAAZgMATQgLASgTAKQgTAJgZAAQgXAAgUgJgAgWgfQgIAKAAAUIAAACQAAAUAIALQAIALAOAAQAPgBAIgKQAIgLAAgUIAAgBQAAgUgIgLQgHgKgQAAQgOAAgIAKg");
	this.shape_6.setTransform(95.975,5.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhUBrIAAjRIA2AAIAAAYQAHgMAMgIQAMgIARAAQASAAAPAJQAPAJAKASQAIASABAbIAAADQgBAagIASQgKASgPAJQgOAJgUAAQgRAAgMgIQgMgHgGgMIAABMgAgXg3QgIAKAAAUIAAADQAAAUAIAJQAIAKAPAAQAOAAAIgLQAIgJAAgTIAAgDQgBgUgHgKQgJgKgNAAQgPAAgIAKg");
	this.shape_7.setTransform(77.4,8.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_8.setTransform(58.375,5.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAbBrIgqhNIgPAAIAABNIg9AAIAAjVIBUAAQAqAAAWARQAWARAAAiIAAABQAAAXgLAOQgKAMgRAGIAzBZgAgegIIAUAAQAOAAAJgHQAHgGAAgOIAAgBQAAgNgIgFQgIgGgOAAIgUAAg");
	this.shape_9.setTransform(40.5,2.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgwBpIAahFIg/iMIA6AAIAgBUIAehUIAzAAIhVDRg");
	this.shape_10.setTransform(14.55,8.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAeAAIAAAkIgeAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_11.setTransform(-0.35,4.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_12.setTransform(-10.3,2.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgzBKQgMgGgHgNQgHgNAAgUIAAhlIA2AAIAABcQAAAOAFAGQAFAHAMAAQALAAAHgHQAHgIABgPIAAhZIA1AAIAACcIg1AAIAAgYQgHAMgMAIQgLAHgTAAQgQAAgLgGg");
	this.shape_13.setTransform(-24.175,5.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAfBrIAAhNQgGAMgNAIQgMAIgRAAQgTAAgOgJQgPgJgJgSQgJgRAAgbIAAgCQAAgbAJgSQAJgSAPgKQAPgJASAAQASAAALAHQAMAHAHAMIAAgWIA1AAIAADRgAgVg3QgIAKAAAUIAAADQABAUAIAJQAIAKANAAQAOAAAJgKQAIgJAAgVIAAgCQAAgUgIgKQgIgKgPAAQgOAAgIAKg");
	this.shape_14.setTransform(-43.475,8.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhMBrIAAjVICUAAIAAAvIhWAAIAAAlIBEAAIAAArIhEAAIAAAnIBaAAIAAAvg");
	this.shape_15.setTransform(-61.35,2.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgoBJQgTgJgLgSQgLgSAAgaIAAgCQAAgYALgTQALgSAUgKQATgKAXAAQAVAAASAIQASAJALASQALARAAAdIAAANIhtAAQABAQAJAIQAIAIAOAAQANAAAGgFQAHgFABgIIAyAAQgDAbgUAOQgUAOgkAAQgYAAgTgJgAAegQQgBgPgGgHQgHgIgNAAQgMAAgHAIQgIAHgCAPIA4AAIAAAAg");
	this.shape_16.setTransform(-85.925,5.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgRBUQgPgNAAgcIAAhGIgTAAIAAgkIATAAIAAggIA1AAIAAAgIAfAAIAAAkIgfAAIAABAQAAAJAEAEQAEAEAIAAIAIgBIAHgCIAAApIgNADQgIABgJAAQgZABgOgNg");
	this.shape_17.setTransform(-100.95,4.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgwBOQgNgFgGgLQgIgKAAgRQAAgbAWgLQAWgMAmAAIAQAAIAAgEQAAgLgFgHQgEgGgNgBQgJABgFAFQgFAFgBAIIgyAAQABgTAKgMQAKgNAQgGQAQgGAVAAQAWAAAQAGQAPAGAJANQAJANAAAVIAABlIg0AAIAAgTQgGAJgLAHQgKAGgTAAQgOAAgMgEgAgPASQgHAEAAAJQAAAHAEAEQAFAEAKAAQAKAAAIgGQAHgGABgKIAAgKIgPAAQgPAAgIAEg");
	this.shape_18.setTransform(-115.5,5.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgcBOIg6ibIA5AAIAgBkIAghkIA0AAIg6Cbg");
	this.shape_19.setTransform(-132.025,5.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaByIAAicIA0AAIAACcgAgUhBQgJgHABgNQgBgMAJgIQAIgHAMgBQAMABAJAHQAIAIAAAMQAAANgIAHQgJAIgMAAQgMAAgIgIg");
	this.shape_20.setTransform(-145.3,2.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgzBQIAAicIA0AAIAAAfQAIgSAMgIQANgIASABIAAAyQgZgBgNAIQgNAIAAASIAABLg");
	this.shape_21.setTransform(-155.775,5.6485);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhTBrIAAjVIBRAAQAsAAAVATQAVASAAAiIAAACQAAAhgWARQgVASgoAAIgXAAIAABIgAgWgGIASAAQAOAAAIgHQAHgHABgNIAAgBQgBgOgHgGQgIgGgOAAIgSAAg");
	this.shape_22.setTransform(-171.7,2.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_23.setTransform(-192.425,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgxBOQgLgFgIgLQgHgKAAgRQAAgbAWgLQAWgMAmAAIAPAAIAAgEQAAgLgDgHQgFgGgMgBQgLABgEAFQgFAFAAAIIgzAAQABgTAKgMQAJgNARgGQAQgGAVAAQAVAAAQAGQARAGAIANQAIANABAVIAABlIg1AAIAAgTQgFAJgLAHQgLAGgSAAQgOAAgNgEgAgPASQgHAEAAAJQAAAHAFAEQAEAEAJAAQAMAAAGgGQAIgGAAgKIAAgKIgNAAQgQAAgIAEg");
	this.shape_24.setTransform(-205.9,5.725);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgMBrQgMgHgGgNIAAAYIg2AAIAAjhIA2AAIAABdQAHgMAMgIQAMgIARAAQATAAAOAJQAQAJAIASQAJARAAAbIAAADQAAAbgJASQgIASgQAJQgPAJgSAAQgSAAgMgIgAgXABQgJAKAAAUIAAACQAAAVAJAKQAIAKAPAAQAOAAAIgLQAHgKAAgTIAAgDQABgUgJgKQgIgJgNAAQgPAAgIAJg");
	this.shape_25.setTransform(-223.45,2.475);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgrBJQgTgJgLgSQgLgSgBgaIAAgCQABgZALgSQALgSATgKQAUgKAXAAQAZAAATAJQATAKALASQAMASAAAZIAAACQAAAZgMATQgLASgTAKQgTAJgZAAQgXAAgUgJgAgWgfQgIAKAAAUIAAACQAAAUAIALQAIALAOAAQAPgBAIgKQAIgLAAgUIAAgBQAAgUgIgLQgHgKgQAAQgOAAgIAKg");
	this.shape_26.setTransform(-242.825,5.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgaBxIAAjhIA1AAIAADhg");
	this.shape_27.setTransform(-256.525,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag5BhQgZgOgNgZQgNgYAAghIAAgBQAAghAPgZQAOgYAagOQAZgNAfgBQAaAAAWAIQAWAJAOARQAOASACAbIg9AAQgCgPgJgHQgKgIgRAAQgWAAgNAQQgNARAAAcIAAACQAAASAFAOQAFAOALAIQALAIARAAQAPAAAJgEQAKgFAEgHQAEgIABgIIgoAAIAAgqIBlAAIAAAZQAAAcgMAVQgMAWgYAMQgXANgjAAQgjAAgZgOg");
	this.shape_28.setTransform(-272.725,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-22.5,573.1,45.1);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAVBQIgCgoQgCAMgIAJQgHAJgKAFQgKAFgMAAQgSAAgLgLQgLgKgBgRQAAgPAIgLQAHgKAPgGQAQgHAYgFIAUgDIAAgLQAAgVgIgLQgJgMgOAAQgNAAgHAGQgHAIgCAKQgCALAFAKIgaAJQgIgRAGgOQAGgOAQgJQAPgJAWAAQAaAAAPAOQAQAPAAAaIAABGQAAAIAEAEQAEADAIAAIAGABIAAAFIgvANgAAAgDQgUADgKAKQgKAJAAAPQABAMAHAIQAGAIAMgBQAIAAAGgEQAIgGAGgJQAFgIAAgMIAAgdg");
	this.shape.setTransform(137.875,-13.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BOIAAgEQAJgCAGgEQAGgDAAgKIAAhiQgBgHgEgEQgDgEgIgBIgHAAIAAgEIAxgOIAEAAIAAArQAHgUALgMQALgLAOAAIAGABIAGACIgBAdIgIgEQgFgBgFAAQgKAAgKAGQgKAHgGAMIAABQQAAAKAGADQAGAEAPACIAAAEg");
	this.shape_1.setTransform(123.45,-13.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AghBFQgQgKgIgRQgIgRAAgVQAAgYAJgTQAJgTAQgKQAQgLAWAAQATAAANAJQANAIAHAPQAHAPAAATIhlAAIAAACIAAADQgBATAHAPQAHAOANAIQALAIARAAQAQgBALgHQAKgHAGgKIAEABQgDAOgIAKQgJALgNAHQgMAGgRAAQgVAAgQgLgAAigVQAAgMgEgLQgEgMgHgHQgHgHgKAAQgJAAgIAGQgIAHgFALQgEALgCAOIBEAAIAAAAg");
	this.shape_2.setTransform(109.325,-13.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAsBOIgrhnIgqBnIgEAAIg4iGQgEgHgEgFQgEgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAlBbIAchIIgIgTQgDgIgEgEQgFgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAkBbIAkhbQADgHgEgEQgDgFgJAAIAAgFIApAAIAAAFQgHAAgEAEQgEAEgEAIIg3CGg");
	this.shape_3.setTransform(82.175,-12.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghBFQgQgKgIgRQgIgRAAgVQAAgYAJgTQAJgTAQgKQAQgLAWAAQATAAANAJQANAIAHAPQAHAPAAATIhlAAIAAACIAAADQgBATAHAPQAHAOANAIQALAIARAAQAQgBALgHQAKgHAGgKIAEABQgDAOgIAKQgJALgNAHQgMAGgRAAQgVAAgQgLgAAigVQAAgMgEgLQgEgMgHgHQgHgHgKAAQgJAAgIAGQgIAHgFALQgEALgCAOIBEAAIAAAAg");
	this.shape_4.setTransform(62.025,-13.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAQBOIAAgEQAHgCAFgEQAFgDABgKIAAhTQAAgNgHgIQgHgHgMAAQgJAAgJAFQgJAFgKALIAABaQAAAKAFADQAFAEAJACIAAAEIhFAAIAAgEQAJgCAFgEQAFgDAAgKIAAhiQAAgHgEgEQgDgEgJgBIgGAAIAAgEIAwgOIAFAAIAAAiQALgQANgJQAMgJAPAAQAVAAAKANQALAMAAAWIAABVQAAAKAGADQAEAEAJACIAAAEg");
	this.shape_5.setTransform(45.4,-13.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAVBQIgCgoQgCAMgIAJQgHAJgKAFQgKAFgMAAQgSAAgLgLQgLgKgBgRQAAgPAIgLQAHgKAPgGQAQgHAYgFIAUgDIAAgLQAAgVgIgLQgJgMgOAAQgNAAgHAGQgHAIgCAKQgCALAFAKIgaAJQgIgRAGgOQAGgOAQgJQAPgJAWAAQAaAAAPAOQAQAPAAAaIAABGQAAAIAEAEQAEADAIAAIAGABIAAAFIgvANgAAAgDQgUADgKAKQgKAJAAAPQABAMAHAIQAGAIAMgBQAIAAAGgEQAIgGAGgJQAFgIAAgMIAAgdg");
	this.shape_6.setTransform(22.025,-13.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAQBOIAAgEQAHgCAFgEQAGgDAAgKIAAhTQgBgNgGgIQgHgHgMAAQgJAAgJAFQgKAFgJALIAABaQAAAKAFADQAFAEAJACIAAAEIhFAAIAAgEQAJgCAFgEQAFgDAAgKIAAhiQAAgHgEgEQgEgEgHgBIgHAAIAAgEIAwgOIAFAAIAAAiQAMgQAMgJQAMgJAPAAQAVAAAKANQALAMAAAWIAABVQAAAKAGADQAEAEAJACIAAAEg");
	this.shape_7.setTransform(-2.2,-13.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfBuIAAgEQAIgBAFgFQAFgDAAgJIAAhiQAAgIgEgEQgDgEgIgBIgHAAIAAgEIAwgOIAEAAIAACFQAAAJAFADQAFAFAJABIAAAEgAgNhJQgGgHgBgJQABgIAGgGQAGgGAIAAQAKAAAFAGQAGAGAAAIQAAAJgGAHQgFAFgKABQgIgBgGgFg");
	this.shape_8.setTransform(-15.675,-16.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcBtIAAgkQgHARgMAJQgLAKgQAAQgTgBgOgKQgOgKgGgRQgIgRAAgUQAAgcAJgSQAKgTAQgKQAPgKASAAQAMAAAKAGQAKAEAGAJIAAgpQAAgJgDgDQgFgEgIAAIgFAAIAAgFIAwgNIAEAAIAAC1QAAAJAEADQAEADAIABIAGABIAAAEIgvAOgAgcgfQgJAIgFAPQgFAMAAASQAAAQAEAQQAEAPAKAKQAIAKAPABQALgBAJgHQAJgHAEgLIAAg5QAAgMgDgLQgFgKgIgHQgIgHgLAAQgMAAgIAJg");
	this.shape_9.setTransform(-35.15,-15.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag0BOIAAgEQAJgCAGgEQAFgDAAgKIAAhiQAAgHgDgEQgEgEgIgBIgGAAIAAgEIAwgOIAEAAIAAArQAGgUAMgMQAMgLANAAIAGABIAHACIgCAdIgIgEQgEgBgFAAQgLAAgLAGQgKAHgFAMIAABQQAAAKAFADQAHAEAQACIAAAEg");
	this.shape_10.setTransform(-50.3,-13.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAVBQIgCgoQgCAMgIAJQgHAJgKAFQgKAFgMAAQgSAAgLgLQgLgKgBgRQAAgPAIgLQAHgKAPgGQAQgHAYgFIAUgDIAAgLQAAgVgIgLQgJgMgOAAQgNAAgHAGQgHAIgCAKQgCALAFAKIgaAJQgIgRAGgOQAGgOAQgJQAPgJAWAAQAaAAAPAOQAQAPAAAaIAABGQAAAIAEAEQAEADAIAAIAGABIAAAFIgvANgAAAgDQgUADgKAKQgKAJAAAPQABAMAHAIQAGAIAMgBQAIAAAGgEQAIgGAGgJQAFgIAAgMIAAgdg");
	this.shape_11.setTransform(-63.875,-13.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAsBOIgrhnIgqBnIgEAAIg4iGQgEgHgEgFQgEgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAlBbIAchIIgIgTQgDgIgEgEQgFgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAkBbIAkhbQADgHgEgEQgDgFgJAAIAAgFIApAAIAAAFQgHAAgEAEQgEAEgEAIIg3CGg");
	this.shape_12.setTransform(-84.725,-12.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag0BOIAAgEQAJgCAGgEQAFgDAAgKIAAhiQAAgHgDgEQgEgEgIgBIgGAAIAAgEIAwgOIAEAAIAAArQAGgUAMgMQAMgLANAAIAGABIAHACIgCAdIgIgEQgEgBgFAAQgLAAgLAGQgKAHgFAMIAABQQAAAKAFADQAHAEAQACIAAAEg");
	this.shape_13.setTransform(-102.95,-13.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgmBGQgQgJgJgSQgJgRAAgXQAAgXAKgTQAJgTARgKQAQgLAVAAQAVAAAQAKQAQAKAJARQAJARABAXQgBAYgJASQgJATgRAKQgQALgWAAQgVAAgQgKgAgXg+QgIAHgEAOQgFAOAAASQAAANADAPQACAOAGAMQAFAMAJAHQAIAHALABQALgBAJgHQAIgIAEgOQAFgOAAgSQAAgNgDgOQgDgPgFgMQgGgMgIgHQgIgHgLAAQgMAAgIAIg");
	this.shape_14.setTransform(-117.725,-13.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag4BtIAAgEQAJgCAGgEQAFgDABgKIAAh3IgaAAIAAgIIAaAAIAAgKQAAgTAIgMQAIgNANgGQAMgGAQAAQANgBALAEQAKAFAGAJIgYAQQgCgKgFgIQgGgHgHAAQgIAAgGAGQgEAFgDAKQgCAJAAANIAAAPIApAAIAAAIIgpAAIAAB3QgBAKAHADQAGAEAPACIAAAEg");
	this.shape_15.setTransform(-130.2,-16.3528);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag3BjQgSgJAAgPQAAgLAEgGQAFgIAGgEQAIgEAHgCQgIgEgEgGQgEgGAAgIQABgJAFgHQAFgHALgGQgMgGgHgLQgHgLAAgPQAAgPAIgMQAHgLAOgHQAOgIATAAQAOABAMAEIAvAAIAAAJIgfAAQAJAHAFAJQAFALABAMQgBAPgHAMQgIAMgOAGQgOAHgSAAIgRgBQgIgDgIgDQgDADgDAFQgCADAAAEQABAFAFAFQAGAEAKABIAvAEQAVABANAJQANAKAAASQAAAPgLALQgKAKgSAHQgSAFgYAAQgeAAgSgKgAgsAzQgEAFgBAIQABAMAGAJQAHAHAMAFQAMAFAOAAQAPAAALgEQAMgEAGgGQAHgGAAgJQAAgJgHgGQgHgHgSgCIgqgEIgJgBIgIgCQgEADgDAGgAgYhZQgHALgBARQABAVAIAOQAJANAOABQANgBAIgKQAHgKABgTQAAgOgEgKQgFgLgHgGQgHgHgJAAQgNABgIAKg");
	this.shape_16.setTransform(-152.15,-10.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAPBOIAAgEQAJgCAEgEQAGgDAAgKIAAhTQgBgNgGgIQgHgHgMAAQgJAAgJAFQgJAFgKALIAABaQAAAKAFADQAFAEAIACIAAAEIhEAAIAAgEQAJgCAFgEQAFgDAAgKIAAhiQAAgHgEgEQgEgEgHgBIgHAAIAAgEIAwgOIAFAAIAAAiQAMgQAMgJQALgJAQAAQAVAAAKANQALAMAAAWIAABVQABAKAEADQAFAEAJACIAAAEg");
	this.shape_17.setTransform(-168.95,-13.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgfBuIAAgEQAIgBAFgFQAFgDAAgJIAAhiQAAgIgEgEQgDgEgIgBIgHAAIAAgEIAwgOIAEAAIAACFQAAAJAFADQAFAFAJABIAAAEgAgNhJQgGgHgBgJQABgIAGgGQAGgGAIAAQAKAAAFAGQAGAGAAAIQAAAJgGAHQgFAFgKABQgIgBgGgFg");
	this.shape_18.setTransform(-182.425,-16.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag0BOIAAgEQAKgCAFgEQAGgDgBgKIAAhiQAAgHgDgEQgEgEgIgBIgGAAIAAgEIAwgOIAEAAIAAArQAHgUALgMQALgLAOAAIAGABIAHACIgCAdIgIgEQgFgBgEAAQgMAAgKAGQgJAHgGAMIAABQQAAAKAFADQAIAEAPACIAAAEg");
	this.shape_19.setTransform(-192.75,-13.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AghBFQgQgKgIgRQgIgRAAgVQAAgYAJgTQAJgTAQgKQAQgLAWAAQATAAANAJQANAIAHAPQAHAPAAATIhlAAIAAACIAAADQgBATAHAPQAHAOANAIQALAIARAAQAQgBALgHQAKgHAGgKIAEABQgDAOgIAKQgJALgNAHQgMAGgRAAQgVAAgQgLgAAigVQAAgMgEgLQgEgMgHgHQgHgHgKAAQgJAAgIAGQgIAHgFALQgEALgCAOIBEAAIAAAAg");
	this.shape_20.setTransform(-206.875,-13.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAsBOIgrhnIgqBnIgEAAIg4iGQgEgHgEgFQgEgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAlBbIAchIIgIgTQgDgIgEgEQgFgEgIAAIAAgFIBEAAIAAAFQgKAAgEAEQgEAFADAHIAkBbIAkhbQADgHgEgEQgDgFgJAAIAAgFIApAAIAAAFQgHAAgEAEQgEAEgEAIIg3CGg");
	this.shape_21.setTransform(-227.075,-12.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgmBGQgQgJgJgSQgJgRAAgXQAAgXAKgTQAJgTARgKQAQgLAVAAQAVAAAQAKQAQAKAJARQAJARABAXQgBAYgJASQgJATgRAKQgQALgWAAQgVAAgQgKgAgXg+QgIAHgEAOQgFAOAAASQAAANADAPQACAOAGAMQAFAMAJAHQAIAHALABQALgBAJgHQAIgIAEgOQAFgOAAgSQAAgNgDgOQgDgPgFgMQgGgMgIgHQgIgHgLAAQgMAAgIAIg");
	this.shape_22.setTransform(-247.875,-13.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhTBkIAAgEQAOgBAGgEQAHgFAAgMIAAiTQAAgMgHgFQgGgEgOgBIAAgEIBXAAQAYAAASAGQASAGAKANQAKAMAAATQAAATgKAMQgKAMgSAGQgSAGgYAAIgcAAIAAA+QAAAMAHAFQAGAEANABIAAAEgAgYAEIAYAAQAYgBAMgLQANgNAAgWQAAgVgNgNQgMgNgYgBIgYAAg");
	this.shape_23.setTransform(-265.625,-15.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-277.1,-40,554.2,43.9);


// stage content:
(lib.v11PE2026DemandbaseLandingPage970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TITLE_W_EYEB_Frame_2
	this.instance = new lib.Tween22("synched",0);
	this.instance.setTransform(317.1,248.15);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).to({x:315.1,y:173.4,alpha:1},15,cjs.Ease.cubicInOut).wait(52));

	// TITLE_W_EYEBROW
	this.instance_1 = new lib.Tween24("synched",0);
	this.instance_1.setTransform(324.5,172.65);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween25("synched",0);
	this.instance_2.setTransform(324.5,111.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},29).to({state:[{t:this.instance_2}]},16).wait(75));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},0).to({_off:true,y:111.1,alpha:1},16,cjs.Ease.cubicInOut).wait(75));

	// CTA
	this.instance_3 = new lib.Tween26("synched",0);
	this.instance_3.setTransform(129.65,228.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween27("synched",0);
	this.instance_4.setTransform(129.65,199.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},74).to({state:[{t:this.instance_4}]},17).wait(29));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(74).to({_off:false},0).to({_off:true,y:199.85,alpha:1},17,cjs.Ease.cubicInOut).wait(29));

	// LOGO
	this.instance_5 = new lib.Tween28("synched",0);
	this.instance_5.setTransform(100,58.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},119,cjs.Ease.cubicInOut).wait(1));

	// RED_BAR
	this.instance_6 = new lib.Tween29("synched",0);
	this.instance_6.setTransform(960,392.1);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween30("synched",0);
	this.instance_7.setTransform(959.95,125);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).to({_off:true,x:959.95,y:125},16,cjs.Ease.cubicInOut).wait(101));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(3).to({_off:false},16,cjs.Ease.cubicInOut).to({startPosition:0},100,cjs.Ease.cubicInOut).wait(1));

	// SHADOW_copy
	this.instance_8 = new lib.Rectangle_1();
	this.instance_8.setTransform(307.5,126.1,1,1,0,0,0,310.9,129.4);
	this.instance_8.alpha = 0.3984;
	this.instance_8.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(120));

	// SHADOW
	this.instance_9 = new lib.Rectangle_1();
	this.instance_9.setTransform(307.5,126.1,1,1,0,0,0,310.9,129.4);
	this.instance_9.alpha = 0.8281;
	this.instance_9.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(120));

	// FOREGROUND
	this.instance_10 = new lib.Tween31("synched",0);
	this.instance_10.setTransform(519.4,124.9,1,1.0001,0,0,0,0.4,0.4);

	this.instance_11 = new lib.Tween32("synched",0);
	this.instance_11.setTransform(586.55,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},119).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true,regX:0,regY:0,scaleY:1,x:586.55,y:125},119).wait(1));

	// MOUNT
	this.instance_12 = new lib.Tween33("synched",0);
	this.instance_12.setTransform(596.7,144.4,1,1.0001,0,0,0,0.5,0.4);

	this.instance_13 = new lib.Tween34("synched",0);
	this.instance_13.setTransform(596.55,126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},119).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true,regX:0,regY:0,scaleY:1,x:596.55,y:126},119).wait(1));

	// SKY
	this.instance_14 = new lib.Tween35("synched",0);
	this.instance_14.setTransform(562.5,124.9,1,1.0001,0,0,0,0.5,0.4);

	this.instance_15 = new lib.Tween36("synched",0);
	this.instance_15.setTransform(591.35,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_15}]},119).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true,regX:0,regY:0,scaleY:1,x:591.35,y:125},119).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EhNVgVPMCarAAAMAAAAqfMiarAAAg");
	this.shape.setTransform(485,126);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhNVAVQMAAAgqfMCarAAAMAAAAqfg");
	this.shape_1.setTransform(485,126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(120));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(406.5,122.7,787.5999999999999,394.40000000000003);
// library properties:
lib.properties = {
	id: '71C08567C200AE4B8E3016DB226092CD',
	width: 970,
	height: 252,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1.png", id:"v1_1_PE2026_Demandbase_LandingPage_970x250_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['71C08567C200AE4B8E3016DB226092CD'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;