(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ConsumerProducts_Demandbase_300x600_atlas_1", frames: [[0,0,625,1250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.v1ConcumerProductsPadiDemandbasestatics_300600 = function() {
	this.initialize(ss["ConsumerProducts_Demandbase_300x600_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.v1ConcumerProductsPadiDemandbasestatics_300600();
	this.instance.setTransform(-153,-306,0.4896,0.4896);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-153,-306,306,612);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("A0TV4MAAAgrvMAonAAAMAAAArvg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-140,260,280);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCCGIAAAuIgOAAIAAhRIA0AxIAAgvIAOAAIAABRgAkPCJIgJArIgOAAIAThRIAdA2IAdg2IAVBRIgQAAIgJgrIgZAtgAl+CrQgMgMABgSQgBgSAMgMQANgMAQAAQATAAAMALQALAMAAATQAAARgMAMQgMAMgSAAQgRAAgMgLgAlzB5QgIAIAAAMQAAAMAIAIQAIAIAKAAQAMAAAHgJQAIgIAAgLQAAgNgHgIQgIgIgMAAQgKAAgIAJgApPCwQgIgHAAgJQAAgOARgJQgKgKABgIQAAgJAGgGQAGgFALAAQAKAAAGAFQAGAFABAIQAAANgTAJIANAQIAIgMIAOAAIgPAUIAQARIgQAAIgHgIQgKAKgMAAQgMAAgGgGgApLCfQAAAMAPAAQAKAAAEgHIgRgUIAAAAQgMAGAAAJgApEB3QAAAGAJAHQAOgIAAgGQAAgKgLAAQgMAAAAALgAnZCqQgLgLAAgTQAAgRAMgMQAMgMARAAQATAAANAPIABABIgMAJIAAAAQgIgMgNAAQgLAAgIAIQgHAIAAAMQAAANAHAIQAHAIAMAAQAOAAAHgMIAAgBIAMAKIgBAAQgMAQgUAAQgSAAgMgMgAEiB/Qg2g1ABhKQgBhLA2g1QA1g1BLAAQARAAAMACIgPAUIgOgBQg/AAgtAsQgsAsgBA+QABA9AsArQAtAsA/AAQBAAAAsgsQAtgrAAg9QABgvgcgmQgagmgsgQIgFgZQA5AQAkAwQAmAxAAA9QAABKg2A1Qg1A1hLAAQhLAAg1g1gABhC0IAAghIgdguIARAAIATAgIAUggIARAAIgdAuIAAAhgAgzC0IgIgRIgeAAIgIARIgPAAIAmhRIAnBRgAhUCWIAUAAIgKgWgAiqC0IAAhPIASAAQAhAAAAAZQAAAMgKAGQgIAHgPAAIgEAAIAAAdgAicCKIAEABQARAAABgNQgBgNgRAAIgEAAgAgEhIIAAB5IglAAIAAjSICIB+IAAh7IAmAAIAADUgAiqAxIAAjPIAnAAIAADPgAkJAxIgTgsIhQAAIgTAsIgoAAIBljSIBlDSgAlcgcIAyAAIgYg8gApQAxIAAjPIAxAAQBPAAAAA2QAAAPgJALQgHAMgMAFQASAGAKANQAMANgBATQABAcgVAPQgVAQgoAAgAoqARIASAAQAsAAAAgbQAAgQgMgGQgKgGgWAAIgSAAgAoqhGIAJAAQAVAAAKgGQALgHAAgPQAAgPgLgHQgKgGgWAAIgIAAgAFlgUIBdh3IAgCTg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-18.2,120,36.5);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape.setTransform(68.475,1.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQALAAAFgFQAGgEAAgKIAAAAQAAgKgGgEQgFgEgLAAIgQAAg");
	this.shape_1.setTransform(57,1.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA6QgPgJgIgPQgIgOAAgTIAAgBQAAgTAJgPQAIgOAPgJQAPgIASAAQAUAAAPAIQAOAIAJAOQAIAPAAAUIAAAAQAAATgIAPQgIAPgPAJQgPAIgUAAQgTAAgPgIgAgZgfQgJALgBAUIAAABQAAANAFAJQAFAKAIAFQAIAFAKAAQAKAAAIgFQAIgFAFgKQAEgKAAgNIAAAAQAAgNgEgJQgFgKgIgFQgIgFgLAAQgQAAgJALg");
	this.shape_2.setTransform(42.225,1.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBAIAAh/IAtAAQAWAAANAKQAMAKABAVIAAAAQAAAOgGAIQgGAJgLAEQgLAEgOAAIgQAAIAAAvgAgRgCIAPAAQAKAAAFgFQAGgFAAgJIAAgBQAAgKgGgFQgGgEgJAAIgPAAg");
	this.shape_3.setTransform(28.875,1.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_4.setTransform(16.975,1.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBAIgdgxIgNAAIAAAxIgdAAIAAh/IAuAAQAOAAAMAEQALAEAGAJQAGAIAAAOIAAAAQAAAKgEAHQgDAHgGADQgGAEgHADIAiA2gAgWgEIAQAAQAKAAAGgFQAGgEAAgKIAAAAQAAgKgGgEQgGgEgKAAIgQAAg");
	this.shape_5.setTransform(4.9,1.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_6.setTransform(-12.325,1.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBAIAAg1IgyAAIAAA1IgdAAIAAh/IAdAAIAAA0IAyAAIAAg0IAeAAIAAB/g");
	this.shape_7.setTransform(-25.75,1.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_8.setTransform(-38.875,1.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBAIAAhpIgiAAIAAgWIBhAAIAAAWIgiAAIAABpg");
	this.shape_9.setTransform(-55.325,1.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBAIAAh/IBTAAIAAAWIg2AAIAAAeIArAAIAAAVIgrAAIAAAgIA4AAIAAAWg");
	this.shape_10.setTransform(-66.525,1.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggA6QgOgJgIgOQgIgPAAgTIAAgBQAAgTAJgPQAIgPAPgIQAOgIATAAQAOgBAMAFQANAFAIAKQAJAKABAQIgdAAQgCgMgHgFQgIgGgLABQgKAAgIAFQgIAFgEAKQgFAJAAANIAAABQAAANAFAJQADAKAIAFQAIAGALAAQALAAAHgEQAGgEAEgGQADgGABgHIgdAAIAAgVIA5AAIAAANQAAARgHANQgHANgNAHQgOAHgTAAQgVAAgOgIg");
	this.shape_11.setTransform(-80.15,1.6727);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Agog2IBQA2IhQA3g");
	this.shape_12.setTransform(85.3,0.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.3,-14.2,178.7,28.4);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaBOQgMgEgIgJQgIgIgCgOIAWgHQABANAFAIQAFAJAIAFQAIAEAJAAQAPAAAJgLQAIgLAAgTQAAgUgKgNQgLgLgSAAQgLAAgJADQgJAEgHAEIgDgBIAOhRIBPAAIAAATIhLAAIgJA3QAHgIAKgEQAKgFAMAAQAPABAMAGQAMAHAHAKQAHAMAAAPQAAAQgHAMQgHANgNAHQgNAHgSAAQgNAAgMgEg");
	this.shape.setTransform(84.425,16.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag2BSIAAgEIAogsIASgVQAIgLAHgMQAFgMAAgNQAAgOgIgJQgJgIgNAAQgIAAgIADQgIADgGAHQgGAGgDAKIgDgBQACgMAHgJQAGgKALgGQALgGAOAAQAUAAANAMQALALABAVQAAARgKAQQgKAOgSARIgpAkIAzAAQALAAAFgCQAGgCAEgFQADgFACgKIAEAAIgHArg");
	this.shape_1.setTransform(71.65,15.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AghBIQgOgLgHgTQgHgTAAgXQAAgWAHgTQAHgTAOgLQAOgLATgBQAUABAOALQAOALAHATQAHATAAAWQAAAXgHATQgHATgOALQgOAMgUAAQgTAAgOgMgAgVhDQgIAIgFAQQgEAPAAAUQAAAMACAPQACAPAFANQAFAOAIAIQAJAIALAAQAKAAAIgJQAIgIAFgPQAEgQAAgUQAAgLgCgPQgCgPgFgNQgFgOgIgIQgJgJgLAAQgKAAgIAJg");
	this.shape_2.setTransform(58.125,15.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2BSIAAgEIApgsIARgVQAJgLAFgMQAGgMABgNQgBgOgIgJQgIgIgOAAQgIAAgIADQgHADgHAHQgGAGgDAKIgCgBQACgMAGgJQAHgKAKgGQALgGANAAQAVAAAMAMQAMALAAAVQABARgKAQQgKAOgSARIgpAkIAzAAQAKAAAGgCQAGgCADgFQAEgFADgKIADAAIgHArg");
	this.shape_3.setTransform(44.25,15.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgnA+IAAgDQAHgBAFgEQAFgDAAgHIAAhPQAAgHgDgCQgDgDgGAAIgGAAIAAgEIAjgKIADAAIAAAhQAFgQAJgJQAJgHAKgBIAFAAIAFACIgBAUIgGgDIgHgBQgIAAgIAGQgIAFgFAMIAABAQAAAHAFADQAFAEAMABIAAADg");
	this.shape_4.setTransform(27.975,17.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdA4QgMgIgHgOQgHgNAAgSQAAgTAHgPQAHgPANgIQANgIAQgBQAQABANAHQAMAIAHAOQAHANAAATQAAASgHAPQgHAPgNAIQgNAIgQABQgRgBgMgHgAgTgxQgHAGgEALQgEALAAAPQAAAJACALQACALAEAKQAFAKAHAGQAHAGAKAAQAKAAAHgHQAHgGAEgLQAEgMAAgPQAAgJgCgLQgCgLgFgJQgEgKgHgGQgIgGgJAAQgKAAgHAHg");
	this.shape_5.setTransform(16.525,17.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBXIAAgEQAIgBAEgDQAFgDAAgHIAAhfIgUAAIAAgHIAVAAIAAgJQAAgOAGgKQAFgKAKgFQAIgFAMAAQAKAAAHADQAIADAEAGIgQAMQgBgHgFgFQgEgFgGAAQgKABgEAIQgFAIAAAQIAAANIAhAAIAAAHIghAAIAABfQAAAHAFADQAGADAMABIAAAEg");
	this.shape_6.setTransform(6.775,15.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSA8QgJgDgHgHQgHgGgEgIIASgIQACANAJAIQAJAIAKAAQAMAAAHgGQAHgGAAgKQAAgLgIgFQgHgGgKgEIgUgHQgKgDgHgHQgIgHAAgNQAAgQALgJQAMgJASgBQAKAAAJADQAJADAGAFQAGAGADAHIgQAIQgEgLgHgHQgIgHgJAAQgLAAgGAGQgGAFgBAJQABAJAHAGQAHAFAKADIAUAIQALAEAHAGQAHAIABANQAAALgGAJQgFAIgKAFQgKAEgNABQgKgBgKgDg");
	this.shape_7.setTransform(-9.675,17.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZA3QgMgIgHgNQgGgOAAgRQAAgTAHgPQAHgPANgIQANgIAQgBQAOABAKAGQALAHAFAMQAFAMAAAPIhRAAIAAACIAAADQgBAPAGAMQAFAMALAGQAJAGAOABQANgBAIgGQAJgGAFgIIACABQgCALgHAIQgGAIgKAFQgKAEgMABQgRgBgMgIgAAegRQgBgKgDgJQgDgJgGgFQgGgGgJAAQgIAAgGAFQgHAFgEAJQgEAJgCALIA7AAIAAAAg");
	this.shape_8.setTransform(-21.475,17.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgYBXIAAgEQAHgBAFgDQAEgCAAgIIAAhPQAAgHgCgDQgDgDgHAAIgGAAIAAgEIAigJIADAAIAABpQAAAIAFACQAFADAGABIAAAEgAgJg9QgEgEAAgGQAAgHAEgEQAFgEAFAAQAHAAADAEQAFAEAAAHQAAAGgFAEQgDAEgHAAQgFAAgFgEg");
	this.shape_9.setTransform(-31,15.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgqBPQgOgHgBgNQABgIADgGQAEgFAFgEQAFgEAGgCQgHgDgCgFQgDgFAAgEQAAgIAEgFQAEgGAIgFQgJgFgFgIQgGgJAAgLQAAgNAGgJQAGgKALgFQALgFAPAAQAKAAAKADIAlAAIAAAHIgZAAQAHAFAEAJQAEAHAAALQAAALgGAKQgGAJgLAGQgLAEgNAAIgOgBQgGgBgGgDIgGAGIgBAGQgBAFAFAEQAEAEAJABIAkADQARAAAKAIQALAGAAAPQAAAMgIAIQgIAJgPAFQgOAEgSAAQgYAAgNgIgAgkAnQgDAFAAAHQAAAKAFAGQAGAHAJADQAJAEALAAQAMAAAKgDQAKgDAGgGQAFgEAAgIQABgIgGgFQgGgFgPgCIgjgDIgGgBIgGgBIgHAHgAgVhHQgGAJgBANQABASAHAKQAIAKAMABQAMAAAHgJQAHgIAAgOQAAgLgEgJQgDgIgHgGQgGgEgIAAQgMAAgHAIg");
	this.shape_10.setTransform(-40.775,20.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZA3QgMgIgHgNQgGgOAAgRQAAgTAHgPQAHgPANgIQANgIAQgBQAOABAKAGQALAHAFAMQAFAMAAAPIhRAAIAAACIAAADQgBAPAGAMQAFAMALAGQAJAGAOABQANgBAIgGQAJgGAFgIIACABQgCALgHAIQgGAIgKAFQgKAEgMABQgRgBgMgIgAAegRQgBgKgDgJQgDgJgGgFQgGgGgJAAQgIAAgGAFQgHAFgEAJQgEAJgCALIA7AAIAAAAg");
	this.shape_11.setTransform(-53.375,17.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNBCQgHgIAAgQIAAhUIgOAAIAAgDIAegcIAEAAIAAAZIAiAAIAAAGIgiAAIAABUQAAAKADAFQAFAGAJAAQAGAAAEgCIAGgEIACABIgFAHQgEAEgFADQgGACgIAAQgMAAgIgIg");
	this.shape_12.setTransform(-63.525,16.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AASBAIgBghQgCAKgGAHQgGAHgHAFQgIAEgKAAQgOAAgJgJQgJgIAAgOQAAgRANgKQANgJAbgFIASgEIAAgIQAAgRgHgJQgIgKgMAAQgKAAgGAGQgGAFgCAJQgBAIAEAJIgSAGQgGgNAEgLQAFgLAMgHQAMgHAQgBQAUABALALQAMALAAAVIAAA5QAAAGADADQADADAHAAIAFABIAAADIgiAKgAAAgCQgRADgIAHQgIAIAAAMQAAAKAGAGQAGAHAJAAQAHAAAGgFQAHgEAEgIQAFgHAAgKIAAgWg");
	this.shape_13.setTransform(-73.4009,17.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgnA+IAAgDQAHgBAFgEQAFgDAAgHIAAhPQAAgHgDgCQgDgDgGAAIgGAAIAAgEIAjgKIADAAIAAAhQAFgQAJgJQAJgHAKgBIAFAAIAFACIgBAUIgGgDIgHgBQgIAAgIAGQgIAFgFAMIAABAQAAAHAFADQAFAEAMABIAAADg");
	this.shape_14.setTransform(-84.675,17.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgNBCQgHgIAAgQIAAhUIgOAAIAAgDIAegcIAEAAIAAAZIAiAAIAAAGIgiAAIAABUQAAAKADAFQAFAGAJAAQAGAAAEgCIAGgEIACABIgFAHQgEAEgFADQgGACgIAAQgMAAgIgIg");
	this.shape_15.setTransform(-93.475,16.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgSA8QgJgDgHgHQgHgGgEgIIASgIQACANAJAIQAJAIAKAAQAMAAAHgGQAHgGAAgKQAAgLgIgFQgHgGgKgEIgUgHQgKgDgHgHQgIgHAAgNQAAgQALgJQAMgJASgBQAKAAAJADQAJADAGAFQAGAGADAHIgQAIQgEgLgHgHQgIgHgJAAQgLAAgGAGQgGAFgBAJQABAJAHAGQAHAFAKADIAUAIQALAEAHAGQAHAIABANQAAALgGAJQgFAIgKAFQgKAEgNABQgKgBgKgDg");
	this.shape_16.setTransform(-103.175,17.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgzBOQgMgFgGgKQgHgKAAgNQAAgRALgMQAJgLASgFIgKgMQgEgHgDgHQgDgHAAgIQAAgRALgJQALgKAVgBQAMAAAIAFQAJAEAGAIQAEAHAAAKQAAALgJALQgJAKgTAHIAtAyQAFgKAEgNQADgMAAgPIATACQgEAPgHAOQgHAOgJAKIAPARQAIAIAGADQAGAEAGAAIAAADIgnAAIgQgSQgKALgMAFQgKAGgOAAQgQAAgLgGgAgxANQgFAJAAALQAAAMAFAJQAEAIAIAFQAJAGAMAAQAJAAAIgEQAJgEAHgIIgzg6QgJAFgGAJgAgfhGQgGAHAAAKQAAAMAGAJQAGAJAIAIQALgGAFgIQAGgJAAgLQAAgLgGgIQgGgIgKAAQgJAAgFAGg");
	this.shape_17.setTransform(28.25,-11.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSA8QgJgDgHgHQgHgGgEgIIASgIQACANAJAIQAJAIAKAAQAMAAAHgGQAHgGAAgKQAAgLgIgFQgHgGgKgEIgUgHQgKgDgHgHQgIgHAAgNQAAgQALgJQAMgJASgBQAKAAAJADQAJADAGAFQAGAGADAHIgQAIQgEgLgHgHQgIgHgJAAQgLAAgGAGQgGAFgBAJQABAJAHAGQAHAFAKADIAUAIQALAEAHAGQAHAIABANQAAALgGAJQgFAIgKAFQgKAEgNABQgKgBgKgDg");
	this.shape_18.setTransform(8.425,-9.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAZBXIgBgeQgFANgLAJQgJAHgMABQgPgBgLgHQgLgJgFgNQgHgNAAgRQAAgWAIgOQAIgQAMgHQANgIAOAAQAJABAIAEQAJAEAFAGIAAgjQAAgGgDgDQgDgDgHAAIgFAAIAAgEIAjgKIADAAIAACTQAAAGADADQADADAGAAIAGAAIAAAEIgiAKgAgZgZQgHAHgEALQgEAKAAAPQAAAJACAKQACAKAEAIQAEAIAHAFQAHAEAIAAQAKAAAIgGQAIgGAEgLIAAgtQAAgIgEgIQgDgJgHgFQgHgFgKgBQgKAAgIAHg");
	this.shape_19.setTransform(-3.45,-12.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AANA+IAAgDQAHgBAFgEQAEgCAAgIIAAhDQAAgLgGgGQgFgHgLAAQgIAAgIAEQgHAFgKAKIAABIQABAIAEACQAEAEAHABIAAADIg0AAIAAgDQAHgBAEgEQAGgCAAgIIAAhPQAAgHgEgCQgDgDgGAAIgGAAIAAgEIAjgKIADAAIAAAbQAKgNAKgHQAJgHANAAQAPABAJAIQAJAKAAASIAABEQAAAIAFACQAEAEAHABIAAADg");
	this.shape_20.setTransform(-17.6,-10.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgZA3QgMgIgHgNQgGgOAAgRQAAgTAHgPQAHgPANgIQANgIAQgBQAOABAKAGQALAHAFAMQAFAMAAAPIhRAAIAAACIAAADQgBAPAGAMQAFAMALAGQAJAGAOABQANgBAIgGQAJgGAFgIIACABQgCALgHAIQgGAIgKAFQgKAEgMABQgRgBgMgIgAAegRQgBgKgDgJQgDgJgGgFQgGgGgJAAQgIAAgGAFQgHAFgEAJQgEAJgCALIA7AAIAAAAg");
	this.shape_21.setTransform(-31.025,-9.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgnA+IAAgDQAHgBAFgEQAFgDAAgHIAAhPQAAgHgDgCQgDgDgGAAIgGAAIAAgEIAjgKIADAAIAAAhQAFgQAJgJQAJgHAKgBIAFAAIAFACIgBAUIgGgDIgHgBQgIAAgIAGQgIAFgFAMIAABAQAAAHAFADQAFAEAMABIAAADg");
	this.shape_22.setTransform(-41.725,-10.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNBCQgHgIAAgQIAAhUIgOAAIAAgDIAegcIAEAAIAAAZIAiAAIAAAGIgiAAIAABUQAAAKADAFQAFAGAJAAQAGAAAEgCIAGgEIACABIgFAHQgEAEgFADQgGACgIAAQgMAAgIgIg");
	this.shape_23.setTransform(-50.525,-10.975);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgrBJQgRgLgLgRQgJgTgBgWQABgZAJgUQAKgTATgLQASgLAYgBQAPAAAMAFQAOAEAIAIQAJAIADALIgVAGQgFgQgLgJQgMgKgPAAQgPAAgNAJQgMAKgHAQQgHARAAAWQAAAVAJASQAHASAOALQAPAKARABQAJAAAJgDQAJgDAHgGIAAgqQgBgKgFgFQgEgFgOAAIAAgDIBCAAIAAADQgLAAgFAGQgFAFAAAJIAAAgQgFAIgKAGQgJAHgMAEQgMAEgOAAQgYAAgRgLg");
	this.shape_24.setTransform(-68.95,-11.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AhABQIAAgDQAHAAAFgCQAFgCACgDQACgEAAgHIAAh1QAAgKgFgEQgFgDgLgBIAAgDIBDAAQASAAAOAFQAOAFAIAKQAIAJAAAQQAAAPgIAKQgIAJgOAFQgOAEgSAAIgYAAIAAAyQAAAHADAEQACADAFACQAEACAHAAIAAADgAgVADIAVAAQAUAAALgKQALgKAAgRQAAgRgLgLQgLgKgUAAIgVAAg");
	this.shape_25.setTransform(-85.375,-11.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AggBJQgRgKgKgSQgJgSgBgXQAAgZAKgTQAJgUASgLQARgLAYgBQAVAAAQAKQAQAJAEARIgVAGQgDgQgMgKQgKgJgPAAQgOAAgMAJQgMAJgGAQQgHAQAAAVQAAAVAIAQQAIAQAOAJQANAJASAAQATAAAOgKQANgJAGgRIADABQgGAZgRAOQgRAOgZAAQgUAAgRgLg");
	this.shape_26.setTransform(-100.7,-11.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110.7,-31.9,221.5,63.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgVASgKQARgJAfAAIAMAAIAAgCQAAgKgDgFQgEgGgKABQgHgBgEAFQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHALQAHAKAAARIAABQIgqAAIAAgOQgEAHgJAEQgIAGgPAAQgMAAgJgEgAgLAOQgGADAAAIQAAAFADADQAEAEAIAAQAIAAAGgFQAGgFAAgIIAAgHIgLAAQgMAAgGACg");
	this.shape.setTransform(72.175,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgpBAIAAh9IAqAAIAAAZQAGgOAKgGQAKgHAPAAIAAApQgUgBgKAHQgKAGgBAOIAAA8g");
	this.shape_1.setTransform(60.725,18.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgOAAgVIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAOAAAXIAAALIhXAAQABAMAGAHQAHAGALABQAKAAAFgFQAGgEABgHIAoAAQgDAWgQAMQgQALgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLgBQgJABgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_2.setTransform(48.125,19);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYBWIAAirIAxAAIAACrg");
	this.shape_3.setTransform(31.975,16.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAjBWIgJggIg5AAIgJAgIguAAIA3irIA/AAIA2CrgAAQAUIgShBIgTBBIAlAAg");
	this.shape_4.setTransform(18.75,16.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUBAIAAhIQAAgKgFgGQgEgEgJAAQgJAAgGAFQgFAGgBAMIAABFIgrAAIAAh8IArAAIAAAUQAFgKALgGQAJgHAQAAQASAAALALQALAMABAYIAABQg");
	this.shape_5.setTransform(-2.425,18.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgOAAgVIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAOAAAXIAAALIhXAAQABAMAGAHQAHAGALABQAKAAAFgFQAGgEABgHIAoAAQgDAWgQAMQgQALgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLgBQgJABgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_6.setTransform(-17.125,19);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgwBLQgQgMgDgWIArAAQABAHAGAFQAFAEALABQANgBAHgHQAGgHAAgMIAAgTQgDAGgGAFQgFAFgIAEQgHADgJAAQgPAAgMgHQgMgHgHgNQgHgNAAgTIAAgCQAAgTAHgNQAHgOAMgHQAMgIAPAAQAOAAAJAGQAKAGAFAJIAAgRIArAAIAAByQAAAcgSAOQgSAPghAAQggAAgPgNgAgQgvQgGAIAAANIAAACQAAANAGAIQAHAGAKAAQAMAAAGgGQAHgIAAgNIAAgCQAAgNgGgIQgHgHgMgBQgLABgGAHg");
	this.shape_7.setTransform(-32.375,21.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AggA6QgPgHgJgOQgJgOAAgVIAAgCQAAgTAJgPQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAOAAAXIAAALIhXAAQABAMAGAHQAHAGALABQAKAAAFgFQAGgEABgHIAoAAQgDAWgQAMQgQALgdAAQgSAAgQgIgAAYgNQAAgLgGgHQgFgFgLgBQgJABgGAFQgGAHgCALIAtAAIAAAAg");
	this.shape_8.setTransform(-51.625,19);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAUBaIAAhJQAAgKgFgGQgEgEgJAAQgJAAgGAFQgFAGgBAMIAABGIgrAAIAAizIArAAIAABLQAFgKALgHQAJgGAQgBQASAAALAMQALAMABAXIAABRg");
	this.shape_9.setTransform(-66.275,16.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOBDQgLgLAAgWIAAg3IgQAAIAAgdIAQAAIAAgaIApAAIAAAaIAZAAIAAAdIgZAAIAAAzQABAHADADQADADAGAAIAHgBIAFgBIAAAhIgKACQgGABgHAAQgVAAgLgKg");
	this.shape_10.setTransform(-78.65,17.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAUBAIAAhIQAAgKgFgGQgEgEgJAAQgJAAgGAFQgFAGgBAMIAABFIgrAAIAAh8IArAAIAAAUQAFgKALgGQAJgHAQAAQASAAALALQALAMABAYIAABQg");
	this.shape_11.setTransform(-95.375,18.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVBbIAAh8IAqAAIAAB8gAgQg0QgGgGgBgJQABgKAGgHQAGgFAKgBQAKABAHAFQAHAHgBAKQABAJgHAGQgHAHgKgBQgKABgGgHg");
	this.shape_12.setTransform(-106.45,16.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgPAAgUIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLABQgJgBgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_13.setTransform(100.475,-9.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AggA7QgOgIgIgOQgKgOABgVIAAgCQgBgUAKgPQAIgOAPgIQAQgIARAAQAQAAANAFQAOAFAJALQAIAMACATIgoAAQgCgJgEgFQgFgFgKAAQgKABgGAHQgHAJABAPIAAABQAAARAFAIQAHAJALAAQAKAAAFgGQAGgFABgKIAmAAQAAAQgHAMQgIALgNAHQgOAGgVAAQgSAAgPgHg");
	this.shape_14.setTransform(86.35,-9.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAUBBIAAhJQAAgKgFgFQgEgGgJAAQgJAAgGAHQgFAFgBAMIAABGIgrAAIAAh9IArAAIAAAUQAFgKALgHQAJgGAQgBQASAAALAMQALAMABAYIAABRg");
	this.shape_15.setTransform(71.825,-10);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgWASgIQARgKAfAAIAMAAIAAgDQAAgJgDgFQgEgFgKgBQgHABgEAEQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHAKQAHALAAAQIAABRIgqAAIAAgPQgEAHgJAGQgIAEgPABQgMAAgJgEgAgLAPQgGADAAAHQAAAGADADQAEADAIAAQAIAAAGgFQAGgFAAgIIAAgIIgLAAQgMAAgGAEg");
	this.shape_16.setTransform(57.075,-9.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWA/Iguh9IAtAAIAaBQIAZhQIApAAIgtB9g");
	this.shape_17.setTransform(43.325,-9.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgPAAgUIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLABQgJgBgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_18.setTransform(29.025,-9.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUBaIAAizIApAAIAACzg");
	this.shape_19.setTransform(18.325,-12.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgPAAgUIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLABQgJgBgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_20.setTransform(7.625,-9.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgpBAIAAh9IAqAAIAAAZQAGgOAKgGQAKgHAPAAIAAApQgUgBgKAHQgKAGgBAOIAAA8g");
	this.shape_21.setTransform(-4.375,-9.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AA4BBIAAhLQAAgJgDgEQgFgGgIAAQgIABgFAFQgFAGgBAJIAABJIgpAAIAAhLQAAgJgFgEQgDgGgIAAQgJABgFAFQgFAGAAAJIAABJIgrAAIAAh9IArAAIAAATQAFgJAJgHQAKgGAPgBQAMABAIAFQAJAFAEALQAIgMALgEQALgGALAAQANABAJAFQAJAFAFALQAGAJgBAQIAABSg");
	this.shape_22.setTransform(-25.7,-10);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgUBbIAAh9IApAAIAAB9gAgQg0QgHgGAAgKQAAgJAHgGQAGgHAKAAQAKAAAHAHQAHAGAAAJQAAAKgHAGQgHAGgKABQgKgBgGgGg");
	this.shape_23.setTransform(-40.45,-12.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgmA+QgKgEgGgIQgGgJAAgNQAAgWASgIQARgKAfAAIAMAAIAAgDQAAgJgDgFQgEgFgKgBQgHABgEAEQgEAEgBAGIgoAAQABgPAIgKQAIgKANgFQANgFAQAAQARAAANAFQANAFAHAKQAHALAAAQIAABRIgqAAIAAgPQgEAHgJAGQgIAEgPABQgMAAgJgEgAgLAPQgGADAAAHQAAAGADADQAEADAIAAQAIAAAGgFQAGgFAAgIIAAgIIgLAAQgMAAgGAEg");
	this.shape_24.setTransform(-51.225,-9.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgUBaIAAizIApAAIAACzg");
	this.shape_25.setTransform(-61.375,-12.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgfA7QgPgIgJgOQgJgOAAgVIAAgCQAAgUAJgPQAKgOAPgIQAPgIARAAQAQAAAOAFQANAFAIALQAKAMABATIgoAAQgCgJgFgFQgFgFgIAAQgLABgGAHQgGAJAAAPIAAABQgBARAHAIQAGAJALAAQAJAAAGgGQAGgFABgKIAmAAQAAAQgHAMQgIALgOAHQgNAGgVAAQgRAAgPgHg");
	this.shape_26.setTransform(-71.85,-9.85);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AggA7QgPgIgJgOQgJgPAAgUIAAgCQAAgUAJgOQAJgPAQgIQAPgIASAAQASAAAOAHQAOAGAJAPQAJAPAAAWIAAAKIhXAAQABANAGAGQAHAIALgBQAKAAAFgEQAGgEABgHIAoAAQgDAWgQALQgQAMgdAAQgSAAgQgHgAAYgNQAAgMgGgFQgFgHgLABQgJgBgGAHQgGAFgCAMIAtAAIAAAAg");
	this.shape_27.setTransform(-86.075,-9.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAWBWIgig+IgLAAIAAA+IgyAAIAAirIBEAAQAhAAARAOQATANgBAcIAAABQABASgJALQgJAKgNAFIAoBHgAgXgHIAPAAQAMAAAGgFQAGgFAAgLIAAAAQAAgLgHgEQgFgFgMAAIgPAAg");
	this.shape_28.setTransform(-101,-12.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-32.8,224,65.69999999999999);


// stage content:
(lib.ConsumerProductsDemandbase300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// General_Headline
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(150,175.95);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({y:130.2,alpha:1},15,cjs.Ease.cubicInOut).wait(86));

	// General_Subheadline
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(149.25,235.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(45).to({_off:false},0).to({y:194.9,alpha:1},15,cjs.Ease.cubicInOut).wait(61));

	// CTA
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(126.85,309.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(70).to({_off:false},0).to({y:271.85,alpha:1},15,cjs.Ease.cubicInOut).wait(36));

	// Bain_Logo
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(100,57.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(121));

	// Red_Box
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(150,20.05,1,2.2007,0,0,0,0,-140.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regY:-140,scaleY:1,y:20.3},19,cjs.Ease.cubicInOut).wait(102));

	// Background
	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(150,298,1.2578,1.2578);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:1,scaleY:1},120).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(107.6,213.2,234.9,469.7);
// library properties:
lib.properties = {
	id: '5E9DDCE03093D349996F90F2E2FE7B48',
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"ConsumerProducts_Demandbase_300x600_atlas_1.jpg", id:"ConsumerProducts_Demandbase_300x600_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5E9DDCE03093D349996F90F2E2FE7B48'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;